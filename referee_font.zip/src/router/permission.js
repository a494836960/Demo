import {per} from '@/const/permission';

export default function (IGNORE) {
    return {
        title: '权限管理',
        name: 'permissionManage',
        icon: 'icon-auth',
        children: [{
            title: '角色管理',
            path: '/permission/role',
            name: 'role',
            component: 'permission/role',
            permission: per.permission_role_manage,
            isMenu: true
        }, {
            title: '资源管理',
            path: '/permission/resources',
            name: 'resource',
            component: 'permission/resources',
            permission: per.permission_resource_manage,
            isMenu: true
        }]
    }
}
