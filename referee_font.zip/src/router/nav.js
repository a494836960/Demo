/*
* 路由菜单配置
* */

/**
 * 路由控制和菜单控制
 * 1、路由会把所有 有component字段 并且有权限的组件加入到路由，
 * 2、路由控制全部使用绝对布局，不分层级
 * 3、菜单会按层级渲染所有的isMenu : true 的节点
 *
 * */
import global from './global';
import personal from './personal'
import personInfo from './personInfo'
import system from './system'
import unit from './unit'
import game from './game'
import referee from './referee'
import cultivate from './cultivate'
import permission from './permission'
import statistics from './statistics'
import user from './user'
import news from './news'


export const IGNORE = "ignore"; //忽略权限
export const menuList = [
    ...personInfo(IGNORE),
    unit(IGNORE),
    referee(IGNORE),
    game(IGNORE),
   //cultivate(IGNORE),
    user(IGNORE),
    permission(IGNORE),
    system(IGNORE),
    statistics(IGNORE),
    personal(IGNORE),
    //news(IGNORE),
]
export const globalList = [global(IGNORE)];
