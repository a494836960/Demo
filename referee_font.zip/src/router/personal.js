import {per} from '@/const/permission';

export default function (IGNORE) {
    return {
        title: '个人账户',
        name: 'userManage',
        icon: 'icon-user',
        children: [{
            title: '基本信息',
            path: '/user-set',
            name: 'user-set',
            component: 'personal/user',
            permission: per.account_base_info,
            isMenu: false
        }, {
            title: '修改密码',
            path: '/password',
            name: 'password',
            component: 'personal/password',
            permission: per.account_password_update,
            isMenu: false
        }]
    }
}
