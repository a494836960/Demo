//外部的页面

export default function (IGNORE) {
    return {
        title: 'global',
        name: 'global',
        children: [{
            title: '登录',
            path: '/login',
            name: 'login',
            component: 'global/login',
            permission: IGNORE
        }, {
            title: '赛事申报员登录',
            path: '/login/gameApplyLogin',
            name: 'gameApplyLogin',
            component: 'global/login/gameApplyLogin',
            permission: IGNORE
        }, {
            title: '忘记密码',
            path: '/forget',
            name: 'forget',
            component: 'global/forget',
            permission: IGNORE
        }, {
            title: '注册',
            path: '/register',
            name: 'register',
            component: 'global/register',
            permission: IGNORE
        },]
    }
}
