import {per} from '@/const/permission';

export default function (IGNORE) {
    return {
        title: '用户管理',
        name: 'user',
        icon: 'icon-user',
        children: [{
            title: '个人用户',
            path: '/user/personal',
            name: 'user-personal',
            component: 'user/personal',
            permission: per.system_user_personal,
            isMenu: true
        }, {
            title: '单位用户',
            path: '/user/unit',
            name: 'user-unit',
            component: 'user/unit',
            permission: per.system_user_unit,
            isMenu: true
        }, {
            title: '选派录入用户',
            path: '/user/record',
            name: 'user-record',
            component: 'user/record',
            permission: per.system_user_record,
            isMenu: true
        },]
    }
}
