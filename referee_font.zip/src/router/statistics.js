import {per} from '@/const/permission';

export default function (IGNORE) {
    return {
        title: '报表统计',
        name: 'statistics',
        icon: 'icon-tongji',
        children: [{
            title: '裁判等级',
            path: '/statistics/level',
            name: 'statisticsLevel',
            component: 'statistics/referee_level',
            permission: per.statistics_level,
            isMenu: true
        }, {
            title: '裁判特长',
            path: '/statistics/speciality',
            name: 'statisticsSpeciality',
            component: 'statistics/referee_speciality',
            permission: per.statistics_speciality,
            isMenu: true
        }]
    }
}
