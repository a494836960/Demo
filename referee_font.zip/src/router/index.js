/*
* 路由配置
* */

import Vue from 'vue';
import Router from 'vue-router'
import {menuList, IGNORE, globalList} from './nav';
import store from '@/store';
import {ROLE} from '@/const/index';

const _import = require('./import-' + process.env.NODE_ENV)
Vue.use(Router);

const globalRoutes = {
    path: '/global', name: 'global', component: require('@/layout/web/Index').default, children: [],
}

const mainRoutes = {
    path: '/home',
    name: 'home',
    component: require('@/layout/admin/Index').default,
    children: [],
    meta: '首页'
};

const vueRouter = new Router({
    mode: 'hash',
    scrollBehavior: () => {
        y: 0
    },
    isAddDynamicMenuRoutes: false, // 是否已经添加动态(菜单)路由
    base: __dirname,
    routes: [globalRoutes, mainRoutes]
});
getGlobalRoutes(globalList);
getMainRoutes(menuList);

//获取 全局 路由
function getGlobalRoutes(menuList = [], permission = {}) {
    let routes = parseRouter(menuList, permission = {});
    globalRoutes.name = "dynamicRouter1";
    globalRoutes.children = routes;
    vueRouter.addRoutes([
        globalRoutes,
    ])
}

//获取admin路由
function getMainRoutes(menuList = []) {
    let routes = parseRouter(menuList)
    mainRoutes.name = "dynamicRouter";
    mainRoutes.children = routes;
    vueRouter.addRoutes([
        mainRoutes,
        {path: '*', redirect: {name: 'login'}}
    ])
}

function parseRouter(menuList = []) {
    let routes = [];
    menuList.map(item => {
        item.children && item.children.map(child => {
             // 不在这里做 router 权限校验， 直接在 before 里面校验权限
                routes.push({
                    name: child.name,
                    meta: {
                        title: child.title,
                        permission: child.permission
                    },
                    component: _import(child.component),
                    path: child.path
                })
        })
    })
    return routes;
}

vueRouter.beforeEach((to, from, next) => {
    if(to.name === 'login' && store.state.user.userType === ROLE.APPLY){ // 如果是申报员进入登录界面直接进入 applyLogin
        next({path:'/login/gameApplyLogin'});
        return;
    }
    
    if (vueRouter.options.isAddDynamicMenuRoutes || fnCurrentRouteType(to, globalRoutes.children) === 'global') {
        next()
    } else {
        if (!store.getters.permissions[to.meta.permission] && to.meta.permission !== IGNORE) { //没有token
            next({path: '/login'})
        } else {
            vueRouter.options.isAddDynamicMenuRoutes = true;
            next({...to, replace: true})
        }
    }
})

vueRouter.afterEach(to => {
    store.dispatch('page/open', to)
})


function fnCurrentRouteType(route, globalRoutes = []) {
    let temp = []
    for (var i = 0; i < globalRoutes.length; i++) {
        if (route.path === globalRoutes[i].path) {
            return 'global'
        } else if (globalRoutes[i].children && globalRoutes[i].children.length >= 1) {
            temp = temp.concat(globalRoutes[i].children)
        }
    }
    return temp.length >= 1 ? fnCurrentRouteType(route, temp) : 'main'
}


export default vueRouter;
