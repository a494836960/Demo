import {per} from '@/const/permission';

export default function (IGNORE) {
    return {
        title: '新闻通知',
        name: 'news',
        icon: 'icon-game',
        children: [{
            title: '新闻列表',
            path: '/news/page',
            name: 'news-page',
            component: 'news/list',
            permission: 'test', // IGNORE
            isMenu: true
        },{
            title: '新闻详情',
            path: '/news/detail/:id?',
            name: 'new-detail',
            component: 'news/list/EditNews.vue',
            permission: IGNORE,
            isMenu: false
        }]
    }
}
