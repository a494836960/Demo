import {per} from '@/const/permission';
export default function (IGNORE) {
    return {
        title: '推荐管理',
        name: 'recommendManage',
        icon: 'icon-recommend',
        children: []
    }
}
