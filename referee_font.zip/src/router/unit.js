import {per} from '@/const/permission';

export default function (IGNORE) {
    return {
        title: '单位管理',
        name: 'unit',
        icon: 'icon-unit',
        children: []
    }
}
