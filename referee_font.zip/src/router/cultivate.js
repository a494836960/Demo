import {per} from '@/const/permission';
export default function (IGNORE) {
    return {
        title: '培训管理',
        name: 'cultivate',
        icon: 'icon-peixun',
        children: [{
            title: '培训报名',
            path: '/cultivate/page',
            name: 'cultivate-page',
            component: 'cultivate/list',
            permission: per.cultivate_manage,
            isMenu: true
        }, {
            title: '培训单位',
            path: '/cultivate/unit',
            name: 'cultivate-unit',
            component: 'cultivate/unit',
            permission: per.cultivate_unit_manage,
            isMenu: true
        }, {
            title: '培训名单',
            path: '/cultivate/referee',
            name: 'cultivate-referee',
            component: 'cultivate/referee',
            permission: per.cultivate_referee_manage,
            isMenu: true
        }]
    }
}
