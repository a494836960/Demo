import {per} from '@/const/permission';

export default function (IGNORE) {
    return {
        title: '裁判管理',
        name: 'referee',
        icon: 'icon-referee',
        children: [{
            title: '国家级裁判管理',
            path: '/referee/page',
            name: 'internation-referee-page',
            component: 'referee/list',
            permission: per.referee_manage,
            isMenu: true
        },{
            title: '一二级裁判管理',
            path: '/referee/normal/page',
            name: 'normal-referee-page',
            component: 'referee/list/normal.vue',
            permission: per.referee_rookie_manage,
            isMenu: true
        },{
            title: '推荐列表',
            path: '/referee/recommend',
            name: 'recommend',
            component: 'referee/recommend',
            permission: per.referee_recommend_manage,
            isMenu: false
        }, {
            title: '裁判详情',
            path: '/referee/detail/:id',
            name: 'referee-detail',
            component: 'referee/detail',
            permission: IGNORE,
        }]
    }
}
