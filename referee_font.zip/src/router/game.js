import {per} from '@/const/permission';

export default function (IGNORE) {
    return {
        title: '赛事选派',
        name: 'game',
        icon: 'icon-game',
        children: [{
            title: '赛事列表',
            path: '/game/page',
            name: 'game-page',
            component: 'game/list',
            permission: per.game_list_manage,
            isMenu: true
        }, {
            title: '赛事选派',
            path: '/game/dispatch',
            name: 'game-dispatch',
            component: 'game/dispatch',
            permission: per.game_dispatch_manage,
            isMenu: true
        }, {
            title: '录入选派',
            path: '/game/record',
            name: 'game-record',
            component: 'game/record',
            permission: per.game_record_manage,
            isMenu: true
        }, {
            title: '赛事选派',
            path: '/game/center/:id',
            name: 'game-center',
            component: 'game/dispatch/select',
            permission: IGNORE,
            isMenu: false
        }, {
            title: '录入选派',
            path: '/game/record/:id',
            name: 'game-record-detail',
            component: 'game/record/RecordSelect',
            permission: IGNORE,
            isMenu: false
        }]
    }
}
