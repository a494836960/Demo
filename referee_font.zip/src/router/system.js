import {per} from '@/const/permission';

export default function (IGNORE) {
    return {
        title: '系统设置',
        name: 'system',
        icon: 'icon-system',
        children: [{
            title: '单位列表',
            path: '/unit/page',
            name: 'unit-page',
            component: 'unit/list',
            permission: per.unit_manage,
            isMenu: true
        },{
            title: '岗位管理',
            path: '/system/position',
            name: 'system-position',
            component: 'system/position',
            permission: per.system_position_manage,
            isMenu: true
        }, {
            title: '系统设置',
            path: '/system/setting',
            name: 'system-setting',
            component: 'system/setting',
            permission: per.system_setting,
            isMenu: true
        }]
    }
}
