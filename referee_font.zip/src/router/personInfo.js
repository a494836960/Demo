import {per} from '@/const/permission';

export default function(IGNORE) {
  return [
    {
      title: '个人账户',
      name: 'userManage',
      icon: 'icon-shouye',
      children: [
        {
          title: '个人信息',
          path: '/personal/home',
          name: 'personalHome',
          component: 'personal/home',
          permission: per.referee_info,
          isMenu: true
        },
        {
          title: '裁判个人信息',
          path: '/referee/edit',
          name: 'referee-edit',
          component: 'referee/edit/index',
          permission: IGNORE,
          isMenu: false
        }
        // {
        //     title: '查看详情',
        //     path: '/personal/detail',
        //     name: 'personal-detail',
        //     component: 'personal/detail',
        //     permission: IGNORE,
        //     isMenu: false
        // }
      ]
    },
    // {
    //   title: '培训报名',
    //   name: 'personalInfo-cultivate',
    //   icon: 'icon-shouye',
    //   children: [
    //     {
    //       title: '培训报名',
    //       path: '/personal/cultivate',
    //       name: 'personal-cultivate',
    //       component: 'personal/cultivate',
    //       permission: per.personal_cultivate,
    //       isMenu: true
    //     }
    //   ]
    // },
    // {
    //   title: '执裁经历',
    //   name: 'experience',
    //   icon: 'icon-shouye',
    //   children: [
    //     {
    //       title: '执裁经历',
    //       path: '/personal/experience',
    //       name: 'personal-experience',
    //       component: 'personal/experience',
    //       permission: per.personal_experience,
    //       isMenu: true
    //     }
    //   ]
    // }
  ];
}
