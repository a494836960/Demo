import Vue from 'vue';
import moment from 'moment';

/*
* time 时间 默认接受时间戳，如果不是时间戳 format必填
* format 描述这个time 的格式
* */
Vue.filter('dateFormat', function (time, format, toFormat) {
  if(typeof time === "string" && !format){
    time = Number(time);
  }
  return new moment(time,format||undefined).format(toFormat||'YYYY-MM-DD HH:mm:ss');
})


Vue.filter('pluralize', function (time, label) {
  if (time === 1) {
    return time + label
  }
  return time + label + 's'
})
