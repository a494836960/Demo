// 配置编译环境和线上环境之间的切换

const env = process.env;
let baseUrl = '';
let imgUrl = '';
let loadUrl = '';
if (env.NODE_ENV == 'development' || env.VUE_APP_ENV=='test') {
    imgUrl = 'http://119.23.41.66:31548/api/resource/respource?path=';
    baseUrl = '';
    loadUrl = 'http://119.23.41.66:31548'
} else if (env.NODE_ENV == 'production') {
    imgUrl = '/api/resource/respource?path=';
    baseUrl = '';
    loadUrl = ''
}

export {
    baseUrl,
    imgUrl,
    loadUrl,
    env
}
