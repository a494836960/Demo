import {getStore, setStore, clearStore} from '@/common/store'
import {login, fetchUserInfo, fetchUserPermission} from '@/api/user'
import {fetchUnitDetail} from '@/api/unit'
import {validatenull} from "@/common/validate";
import {menuList, IGNORE} from '@/router/nav';
import {deepClone} from "@/common/util";

function initMenu(permission) {
    let children = [];
    let menu = deepClone(menuList);
    menu && menu.map(item => {
        children = [];
        item.children && item.children.map((child, index) => {
            if (child.isMenu && (child.permission == IGNORE || permission[child.permission])) {
                children.push(child);
            }
        })
        item.children = children;
    })
    menu = menu.filter(item => {
        return item.children.length !== 0;
    })
    return menu;
}

const user = {
    state: {
        userInfo: getStore({
            name: 'userInfo'
        }) || {},
        roles: '',
        menu: getStore({
            name: 'menu'
        }) || [],
        menuAll: [],
        access_token: getStore({
            name: 'access_token'
        }) || '',
        userType: getStore({
            name: 'userType',
        }),
    },
    actions: {
        // 根据用户名登录
        LoginByUsername({commit, dispatch}, params) {
            return new Promise((resolve, reject) => {
                login(params).then(res => {
                    let data = res.data;
                    let userInfo = {
                        token: data.access_token,
                        id: data.id,
                        unionId: data.unionID,
                        username: data.username,
                        role: data.authorities,
                        jti: data.jti
                    }
                    commit('SET_USER_INFO', userInfo);

                    dispatch('getUserPermission').then(() => {
                        dispatch('getUserInfo').then(() => {
                            resolve();
                        });
                    });
                }).catch(error => {
                    reject(error)
                })
            })
        },

        getUserInfo({commit, state, dispatch}, params) {
            return fetchUserInfo().then(res => {
                let info = state.userInfo;
                info.unitType = res.data.data.remark;
                info.unitName = res.data.data.unitName;
                info.unitId = res.data.data.unitId || '';
                info.refereeId = res.data.data.refereeId || '';
                if (!validatenull(info.unitId)) {
                    dispatch('getUnitInfo');
                }
                commit('SET_USER_INFO', info);

                return res;
            })
        },

        //获取单位信息
        getUnitInfo({commit, state}, params) {
            if (validatenull(state.userInfo.unitId)) {
                return;
            }
            fetchUnitDetail(state.userInfo.unitId).then(res => {
                let info = state.userInfo;
                info.recommendNumLimit = res.data.data.recommendNumLimit || 0;
                info.surplusRecommendNum = res.data.data.surplusRecommendNum || 0;
                commit('SET_USER_INFO', info);
            });
        },

        //获取用户权限
        getUserPermission({commit, state}, params) {
            return fetchUserPermission().then(res => {
                let info = state.userInfo;
                let obj = {};
                res.data.data && res.data.data.map(item => {
                    obj[item] = true;
                })
                info.permission = obj;
                state.menu = initMenu(obj);
                commit('SET_USER_INFO', info);
            })
        },

        // 登出
        LogOut({commit, dispatch}) {
            dispatch('clearData');
        },

        clearData({commit, dispatch}) {
            clearStore({type: 'session'});
        },
    },
    mutations: {
        SET_USER_TYPE(state, userType) {
            state.userType = userType;
            setStore({
                name: 'userType',
                content: userType,
                type: 'session'
            })
        },
        SET_USER_INFO(state, userInfo) {
            state.userInfo = Object.assign({}, state.userInfo, userInfo);
            setStore({
                name: 'userInfo',
                content: userInfo,
                type: 'session'
            })
        },
    }
}

export default user
