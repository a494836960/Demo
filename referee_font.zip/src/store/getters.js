import {ROLE} from '@/const/index';

const getters = {
  access_token: (state) => state.user.userInfo.token,
  refresh_token: (state) => state.user.refresh_token,
  roles: (state) => {
    return state.user.userInfo.role;
  },
  permissions: (state) => {
    return state.user.userInfo.permission || {};
  },
  userInfo: (state) => {
    return state.user.userInfo;
  },
  getSetting: (state) => {
    sessionStorage.levelType = location.href.indexOf('to.athletics.org.cn');
    let setting = {};
    if (state.user.userType === ROLE.APPLY) {
      setting = {
        title: '赛事申报系统',
      };
    } else {
      setting = {
        title:
          sessionStorage.levelType > -1
            ? '一级、二级裁判员管理'
            : '国家级裁判员管理',
      };
    }

    return setting;
  },
};
export default getters;
