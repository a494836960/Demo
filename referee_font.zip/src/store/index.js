import Vue from 'vue'
import Vuex from 'vuex'
import user from './modules/user'
import common from './modules/common'
import page from './modules/page'
import db from './modules/db'
import getters from './getters'
// 引入 axios

Vue.use(Vuex)

const state = {
  sidebarOpened: localStorage.getItem('sidebarStatus') ? !!+localStorage.getItem('sidebarStatus') : true
}


const mutations = {
  TOGGLE_SIDEBAR: state => {
    state.sidebarOpened = !state.sidebarOpened;
    if (state.sidebarOpened) {
      localStorage.setItem('sidebarStatus', 1);
    } else {
      localStorage.setItem('sidebarStatus', 0);
    }
  }
}

const actions = {
  toggleSideBar({ commit }) {
    commit('TOGGLE_SIDEBAR');
  }
}

const store = new Vuex.Store({
  state,
  mutations,
  actions,
  modules: {
    user,
    common,
    page,
    db
  },
  getters
})

export default store
