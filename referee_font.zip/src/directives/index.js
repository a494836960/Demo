import Vue from 'vue';
import store from '@/store';
import { MessageBox } from 'element-ui';

Vue.directive('auth', {
  inserted: function (el, binding) {
    if (binding.arg === 'show' && !store.getters.permissions[binding.value]) { //展示，但是不给与操作权限 v-auth:show
      el.addEventListener('click', function (e) {
        e.stopPropagation();
        MessageBox.alert('没有操作权限，请联系管理员!', '没有权限',{type: 'warning'});
        return false;
      },true)
    } else if (el.parentNode && !store.getters.permissions[binding.value]) {
      el.parentNode.removeChild(el)
    }
  }
});
