<template>
    <el-dialog
            :title="type==='edit'?'编辑单位': type==='add' ? '新增单位' : '单位详情'"
            :close-on-click-modal="isClickModalClose"
            :visible.sync="isShow"
            :width="'850px'"
            @close="closeModal"
    >
        <el-form :ref="formName" :model="modalData" :rules="ruleValidate" label-width="120px">
            <el-row :gutter="20">
                <el-col :span="12">
                    <el-form-item label="单位全称：" prop="cnName">
                        <el-input v-model="modalData.cnName" placeholder="请输入单位全称" :maxLength="32"
                                  :disabled="type==='detail'"></el-input>
                    </el-form-item>
                </el-col>

                <el-col :span="12">
                    <el-form-item label="联系人手机号：" prop="mobile">
                        <el-input v-model="modalData.mobile" placeholder="请输入联系人手机号" :maxLength="11"
                                  :disabled="type==='detail'"></el-input>
                    </el-form-item>
                </el-col>

                <el-col :span="12">
                    <el-form-item label="单位简称：" prop="shortName">
                        <el-input v-model="modalData.shortName" placeholder="请输入联系人手机号" :maxLength="20"
                                  :disabled="type==='detail'"></el-input>
                    </el-form-item>
                </el-col>

                <el-col :span="12">
                    <el-form-item label="联系人姓名：" prop="contactName">
                        <el-input v-model="modalData.contactName" placeholder="请输入联系人姓名" :maxLength="50" :disabled="type==='detail'"></el-input>
                    </el-form-item>
                </el-col>

                <el-col :span="12">
                    <el-form-item label="单位联系电话：" prop="telPhone">
                        <el-input v-model="modalData.telPhone" placeholder="请输入单位联系电话" :maxLength="50"
                                  :disabled="type==='detail'"></el-input>
                    </el-form-item>
                </el-col>

                <el-col :span="12">
                    <el-form-item label="联系人邮箱：" prop="email">
                        <el-input v-model="modalData.email" placeholder="请输入联系人邮箱" :maxLength="50"
                                  :disabled="type==='detail'"></el-input>
                    </el-form-item>
                </el-col>
                <el-col :span="12">

                    <el-form-item label="单位备用电话：" prop="bakTelPhone">
                        <el-input v-model="modalData.bakTelPhone" placeholder="请输入单位备用电话" :maxLength="50"
                                  :disabled="type==='detail'"></el-input>
                    </el-form-item>
                </el-col>

                <el-col :span="12">
                    <el-form-item label="单位所在地：">
                        <el-cascader
                                :disabled="type==='detail'"
                                v-model="unitArea"
                                :options="areasList"
                                :props="{value: 'name',label: 'name'}"
                                @change="handleChange"></el-cascader>
                    </el-form-item>
                </el-col>

                <el-col :span="12">
                    <el-form-item label="单位注册编号：" prop="registerNo">
                        <el-input v-model="modalData.registerNo" placeholder="请输入单位注册编号" :maxLength="50"
                                  :disabled="type==='detail'"></el-input>
                    </el-form-item>
                </el-col>

                <el-col :span="12">
                    <el-form-item label="单位联系地址：" prop="address">
                        <el-input v-model="modalData.address" placeholder="请输入单位联系地址" :maxLength="50"
                                  :disabled="type==='detail'"></el-input>
                    </el-form-item>
                </el-col>

                <el-col :span="12">
                    <el-form-item label="单位英文名：" prop="enName">
                        <el-input v-model="modalData.enName" placeholder="请输入单位英文名" :maxLength="50"
                                  :disabled="type==='detail'"></el-input>
                    </el-form-item>
                </el-col>

                <el-col :span="12">
                    <el-form-item label="邮编：" prop="passpot">
                        <el-input v-model="modalData.passpot" placeholder="请输入邮编" :maxLength="50"
                                  :disabled="type==='detail'"></el-input>
                    </el-form-item>
                </el-col>
                <el-col :span="12">

                    <el-form-item label="限制推荐人数：" prop="recommendNumLimit">
                        <el-input v-model="modalData.recommendNumLimit" placeholder="请输入限制推荐人数"
                                  :disabled="type==='detail'"
                                  :maxLength="50"></el-input>
                    </el-form-item>
                </el-col>

                <el-col :span="12">
                    <el-form-item label="logo：" prop="photo">
                        <UploadImg
                                :disabled="type==='detail'"
                                :action="modalData.id? `/admin/unit/uploadLogo/${modalData.id}`:'/admin/referee/add/temp'"
                                :defaultUrl="modalData.photo?imgUrl+modalData.photo : ''"
                                @success="changePhoto"></UploadImg>
                    </el-form-item>
                </el-col>
            </el-row>
        </el-form>

        <div slot="footer">
            <el-button @click="closeModal">
                取消
            </el-button>

            <el-button @click="submit" type="primary">
                确定
            </el-button>
        </div>
    </el-dialog>
</template>

<script>
    import modalMixin from '@/mixins/modalMixin';
    import {areas} from '@/common/area.js'

    export default {
        mixins: [modalMixin],
        props: ['modalData', 'type'],
        data() {
            return {
                imgUrl: this.imgUrl,
                areasList: areas.provinces,
                unitArea: [],
                formName: 'form',
                ruleValidate: {
                    cnName: [
                        {
                            required: true,
                            type: 'string',
                            message: '单位名称不能为空！',
                            trigger: 'blur'
                        }
                    ],
                    mobile: [
                        {
                            required: true,
                            message: '联系人手机号不能为空！',
                            trigger: 'blur'
                        }
                    ],
                    shortName: [
                        {
                            required: true,
                            message: '单位简称不能为空！',
                            trigger: 'blur'
                        }
                    ], contactName: [
                        {
                            required: true,
                            message: '联系人姓名不能为空！',
                            trigger: 'blur'
                        }
                    ],
                }
            };
        },
        methods: {
            handleChange() {

            },
            changePhoto(res) {
                if (this.validatenull(this.modalData.id)) {
                    this.modalData.photo = res;
                } else {
                    this.modalData.photo = res.photo;
                }
            },

            submit() {
                if (this.type === 'detail') {
                    this.closeModal();
                    return;
                }
                this.validateForm().then(res => {
                    this.$emit('submit', this.modalData);
                })
            },
        },

    }
</script>
