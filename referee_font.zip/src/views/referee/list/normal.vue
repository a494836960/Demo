<template>
  <div>
    <el-row :gutter="20" class="search-box">
      <el-col :span="4" v-if="userInfo.unitType === 'ALL'">
        <el-select
          v-model="listQuery.unitId"
          placeholder="注册所属省市"
          clearable
          filterable
          @change="getList(1)"
        >
          <el-option
            v-for="(item, index) in unitList"
            :key="index"
            :value="item.id"
            :label="item.cnName"
          ></el-option>
        </el-select>
      </el-col>

      <el-col :span="4">
        <el-select
          v-model="listQuery.specialityCode"
          placeholder="特长"
          clearable
          filterable
          @change="getList(1)"
        >
          <el-option
            v-for="(item, index) in specialityList"
            :key="index"
            :value="item.code"
            :label="item.name"
          ></el-option>
        </el-select>
      </el-col>

      <el-col :span="4">
        <el-select
          v-model="listQuery.languageLevel"
          placeholder="外语等级"
          clearable
          filterable
          @change="getList(1)"
        >
          <el-option
            v-for="(item, index) in LANGUAGE_LEVEL"
            :key="index"
            :value="item.value"
            :label="item.name"
          ></el-option>
        </el-select>
      </el-col>

      <el-col :span="4" v-if="isShowFilter">
        <el-select
          v-model="listQuery.language"
          placeholder="外语语种"
          clearable
          filterable
          @change="getList(1)"
        >
          <el-option
            v-for="(item, index) in LANGUAGE_TYPE"
            :key="index"
            :value="item.value"
            :label="item.name"
          ></el-option>
        </el-select>
      </el-col>

      <el-col :span="4" v-if="isShowFilter">
        <el-select
          v-model="listQuery.recommendStatus"
          placeholder="注册类型"
          clearable
          filterable
          @change="getList(1)"
        >
          <el-option :value="0" label="新注册"></el-option>
          <el-option :value="1" label="确认注册"></el-option>
        </el-select>
      </el-col>

      <el-col :span="4" v-if="isShowFilter">
        <el-select
          v-model="listQuery.unitCheckStatus"
          placeholder="单位审核"
          clearable
          filterable
          @change="getList(1)"
        >
          <el-option :value="0" label="单位未审核"></el-option>
          <el-option :value="1" label="单位已审核"></el-option>
        </el-select>
      </el-col>

      <el-col :span="4" v-if="isShowFilter">
        <el-select
          v-model="listQuery.centerCheckStatus"
          placeholder="田协审核"
          clearable
          filterable
          @change="getList(1)"
        >
          <el-option :value="0" label="田协未审核"></el-option>
          <el-option :value="1" label="田协已审核"></el-option>
        </el-select>
      </el-col>

      <el-col :span="4" v-if="isShowFilter">
        <el-select
          v-model="listQuery.isRecommend"
          placeholder="单位推荐"
          clearable
          filterable
          @change="getList(1)"
        >
          <el-option :value="0" label="未推荐"></el-option>
          <el-option :value="1" label="已推荐"></el-option>
        </el-select>
      </el-col>

      <el-col :span="4" v-if="isShowFilter">
        <el-input placeholder="姓名" v-model="listQuery.cnName" @change="getList(1)"></el-input>
      </el-col>

      <el-col :span="4" v-if="isShowFilter">
        <el-input placeholder="身份证" v-model="listQuery.idcard" @change="getList(1)"></el-input>
      </el-col>

      <el-col :span="4" v-if="isShowFilter">
        <el-input placeholder="手机号" v-model="listQuery.mobile" @change="getList(1)"></el-input>
      </el-col>

      <el-col :span="4">
        <el-button type="primary" @click="getList(1)">查询</el-button>
      </el-col>
    </el-row>

    <div>
      <el-button type="primary" @click="showAddReferee" v-auth="per.referee_rookie_add"
        >新增</el-button
      >

      <el-button
        v-auth="per.referee_rookie_audit_unit"
        @click="batchReview(1, 'unit')"
        type="primary"
        >通过单位审核</el-button
      >

      <el-button
        v-auth="per.referee_rookie_audit_unit"
        type="danger"
        @click="batchReview(0, 'unit')"
        >取消单位审核</el-button
      >
    </div>

    <div class="text-r switch-icon">
      <i class="iconfont icon-card-list" v-if="showType === 'table'" @click="switchType"></i>
      <i class="iconfont icon-table-list" v-else @click="switchType"></i>
    </div>
    <!-- table 展示 -->
    <el-table
      v-show="showType === 'table'"
      border
      height="600px"
      :data="dataSource"
      class="page-top-space"
      row-class-name="table-row"
      @selection-change="changeSelect"
    >
      <el-table-column type="selection"> </el-table-column>

      <el-table-column type="index" label="序号"> </el-table-column>

      <el-table-column v-if="userInfo.unitType === 'ALL'" prop="unitName" label="注册所属省市">
      </el-table-column>

      <el-table-column prop="cnName" label="姓名"> </el-table-column>

      <el-table-column prop="sex" label="性别">
        <template slot-scope="scope">
          <MyBadge :list="GENDER" :target="scope.row.sex"></MyBadge>
        </template>
      </el-table-column>

      <el-table-column prop="birthday" label="出生日期" min-width="100px">
        <template slot-scope="scope">
          <span>{{ scope.row.birthday | dateFormat(null, 'YYYY-MM-DD') }}</span>
        </template>
      </el-table-column>

      <el-table-column prop="level" width="140px" label="等级">
        <template slot-scope="scope">
          <span><MyBadge :list="LEVEL_TYPE" :target="scope.row.level"></MyBadge></span>
          <span v-if="scope.row.prejudgeda"
            >（{{ scope.row.prejudgeda | dateFormat(null, 'YYYY-MM') }}）</span
          >
        </template>
      </el-table-column>

      <!-- <el-table-column prop="inaugurationUnit" label="就职单位" min-width="120px">
      </el-table-column> -->

      <el-table-column prop="language" label="外语"> </el-table-column>

      <el-table-column prop="specialityName" label="特长" min-width="120px">
        <template slot-scope="scope">
          <span>{{ scope.row.specialityName && scope.row.specialityName.join(' ') }}</span>
        </template>
      </el-table-column>

      <el-table-column prop="designationNum" width="100px" label="年度选派次数"> </el-table-column>

      <el-table-column prop="centerCheckStatus" width="150px" label="主管单位审核">
        <template slot-scope="scope">
          <span v-if="scope.row.unitCheckStatus == 0" class="text-danger">
            未审核
          </span>
          <span v-else class="text-success">
            已审核
          </span>
        </template>
      </el-table-column>

      <el-table-column fixed="right" label="操作" width="180px">
        <template slot-scope="scope">
          <span
            class="option option-primary"
            @click="showEditReferee(scope.row)"
            v-auth="per.referee_rookie_update"
            >编辑</span
          >
          <span class="option option-primary" @click="goDetailReferee(scope.row.id)">详情</span>
        </template>
      </el-table-column>
    </el-table>

    <!-- card 展示 -->
    <el-row v-show="showType === 'card'" :gutter="20" class="page-top-space">
      <el-col :lg="8" :md="12" :xl="6" v-for="(item, index) in dataSource" :key="index">
        <el-card style="overflow: hidden; margin-bottom: 10px;height: 370px;">
          <div slot="header" class="clearfix">
            <span>{{ item.cnName }}</span>
            <div class="float-r">
              <el-button type="text" @click="showEditReferee(item)">编辑</el-button>
              <el-button type="text" @click="loadTemplate(item)">下载登记表</el-button>
              <el-button type="text" @click="goDetailReferee(item.id)">详情</el-button>
            </div>
          </div>
          <img :src="imgUrl + item.photo" alt="头像" class="card-img" />
          <p class="card-con">
            性别：<span style="margin-left: 10px;">{{ item.sex == 0 ? '男' : '女' }}</span>
          </p>
          <p class="card-con">手机号：{{ item.mobile }}</p>
          <p class="card-con">身份证：{{ item.idcard }}</p>

          <p class="card-con">
            裁判等级： <span><MyBadge :list="LEVEL_TYPE" :target="item.level"></MyBadge></span>
            <span v-if="item.prejudgeda"
              >（{{ item.prejudgeda | dateFormat(null, 'YYYY-MM') }}）</span
            >
          </p>
          <p class="card-con">选派次数：{{ item.designationNum }}</p>
          <p class="card-con">
            中国田协：
            <span v-if="item.centerCheckStatus == 0" class="text-danger">
              未审核
            </span>
            <span v-else class="text-success">
              已审核
            </span>
          </p>
          <p class="card-con">
            主管单位：
            <span v-if="item.unitCheckStatus == 0" class="text-danger">
              未审核
            </span>
            <span v-else class="text-success">
              已审核
            </span>
          </p>
          <p class="card-con">特长：{{ item.specialityName && item.specialityName.join(' ') }}</p>
          <p class="card-con">就职单位：{{ item.inaugurationUnit }}</p>
          <p class="card-con">
            执裁经历：{{
              item.experience &&
                (item.experience.length > 50
                  ? item.experience.substring(0, 50) + '......'
                  : item.experience)
            }}
          </p>
        </el-card>
      </el-col>
    </el-row>

    <el-pagination
      class="page-top-space"
      background
      :total="total"
      :page-size="listQuery.pageSize"
      :current-page.sync="listQuery.pageNo"
      @current-change="getList"
    >
    </el-pagination>

    <EditModal
      :ref="MODAL_KEY.EDIT_MODAL"
      :modal-data="modalData"
      :type="modalType"
      :specialityList="specialityList"
      :unitList="unitList"
      :levelList="levelList"
      @submit="doSubmit"
    ></EditModal>

    <ResetModal :ref="MODAL_KEY.RESET_MODAL" @submit="doReset"></ResetModal>
  </div>
</template>

<script>
import {
  fetchRefereeList,
  addReferee,
  updateReferee,
  centerAudit,
  unitAudit,
  RecommendReferee,
  fetchRecommendTemplate,
  importRecommend,
  exportRecommend,
  resetPwd,
  exportRegistryForm,
} from '@/api/referee';
import EditModal from './component/EditModal';
import ResetModal from './component/ResetModal';
import {
  LANGUAGE_LEVEL,
  LANGUAGE_TYPE,
  RECOMMEND_TYPE,
  GENDER,
  LEVEL_TYPE,
  ROLE,
} from '@/const/index';
import {fetchSpeciality, fetchRefereeLevel} from '@/api/common';
import {fetchUnitAll} from '@/api/unit';
import {apiDownLoadFile, exportAnchorFile} from '@/common/util';
import {getStore, setStore} from '@/common/store';

export default {
  components: {EditModal, ResetModal},
  data() {
    let userInfo = this.$store.getters.userInfo;
    return {
      isShowFilter: true,
      showType: 'table',
      ROLE_CODE: ROLE,
      userInfo: this.$store.getters.userInfo,
      role: '',
      LEVEL_TYPE: LEVEL_TYPE,
      LANGUAGE_LEVEL: LANGUAGE_LEVEL,
      LANGUAGE_TYPE: LANGUAGE_TYPE,
      RECOMMEND_TYPE: RECOMMEND_TYPE,
      GENDER: GENDER,
      MODAL_KEY: {
        UPLOAD_EXCEL: 'UPLOAD_EXCEL',
        EDIT_MODAL: 'EDIT_MODAL',
        RESET_MODAL: 'RESET_MODAL',
      },
      listQuery: {
        pageNo: 1,
        pageSize: 12,
        unitId: userInfo.unitType === 'ALL' ? '' : userInfo.unitId,
        levels: [4, 5],
      },
      total: 0,
      dataSource: [],
      modalData: {},
      modalType: '',
      specialityList: [],
      unitList: [],
      specialityMap: {},
      levelList: [],
      ids: [],
    };
  },
  methods: {
    switchType() {
      this.showType = this.showType === 'table' ? 'card' : 'table';
      setStore({name: 'showType', content: this.showType, type: 'session'});
    },
    changeSelect(selection) {
      this.ids = [];
      selection.map((item) => {
        this.ids.push(item.id);
      });
    },
    showAddReferee() {
      this.modalData = {};
      this.modalType = 'add';
      this.$refs[this.MODAL_KEY.EDIT_MODAL].showModal();
    },

    showEditReferee(data) {
      this.modalData = {
        area: [data.province, data.city],
        ...data,
      };

      this.modalType = 'edit';
      this.$refs[this.MODAL_KEY.EDIT_MODAL].showModal();
    },

    goDetailReferee(id) {
      this.$router.push(`/referee/detail/${id}`);
    },

    loadTemplate(row) {
      //下载模板
      exportRegistryForm(row.id).then((res) => {
        apiDownLoadFile(
          res.data,
          'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
          row.cnName + '培训登记表'
        );
      });
    },

    doSubmit(data) {
      let result = addReferee;
      if (!this.validatenull(data.id)) {
        result = updateReferee;
      }

      result(data).then((res) => {
        this.$message.success('操作成功');
        this.getList();
        this.$refs[this.MODAL_KEY.EDIT_MODAL].closeModal();
      });
    },

    getList(current) {
      if (!this.validatenull(current)) {
        this.listQuery.pageNo = current;
      }
      fetchRefereeList(this.listQuery).then((res) => {
        this.dataSource = res.data.data.results;
        this.dataSource.map((item) => {
          // 特长
          if (!this.validatenull(item.speciality)) {
            item.specialityName = '';
            item.speciality = item.speciality.replace(/\s/g, '');
            item.speciality = item.speciality.replace(/[\[\]\s]/g, '').split(',');
            item.specialityName = item.speciality.map((item) => {
              return this.specialityMap[item];
            });
          }
        });
        this.total = res.data.data.total_record;
      });
    },

    getSpeciality() {
      fetchSpeciality().then((res) => {
        this.specialityList = res.data.data;
        res.data.data &&
          res.data.data.map((item) => {
            this.specialityMap[item.code] = item.name;
          });

        this.getList();
      });
    },

    //获取单位列表
    getUnit() {
      fetchUnitAll().then((res) => {
        this.unitList = res.data.data;
      });
    },

    // 获取裁判等级列表
    getRefereeLevelList() {
      fetchRefereeLevel().then((res) => {
        this.levelList = res.data.data;
      });
    },

    // 审核
    batchReview(type, unit) {
      if (this.validatenull(this.ids)) {
        this.$message.error('请选择数据进行操作');
        return;
      }
      let result;
      let params = [];
      this.ids.map((item) => {
        params.push({id: item, state: type});
      });

      if (unit === 'unit') {
        result = unitAudit;
      } else {
        result = centerAudit;
      }
      this.$confirm('是否要操作审核', '提示', {type: 'warning'}).then((res) => {
        result(params).then((res) => {
          this.$message.success('操作成功');
          this.getList();
        });
      });
    },

    //推荐
    onRecommendRefer(type) {
      if (this.validatenull(this.ids)) {
        this.$message.error('请选择数据进行操作');
        return;
      }
      let params = [];
      this.ids.map((item) => {
        params.push({id: item, state: type});
      });

      this.$confirm('是否要操作推荐', '提示', {type: 'warning'}).then((res) => {
        RecommendReferee(params).then((res) => {
          this.$message.success('操作成功');
          this.getList();
          this.$store.dispatch('getUnitInfo');
        });
      });
    },

    //下载推荐模板
    onRecomDownTemp() {
      exportAnchorFile(this.baseUrl + fetchRecommendTemplate());
    },

    onRecommendDown() {
      if (this.validatenull(this.listQuery.unitId)) {
        this.$message.error('请选择单位进行导出');
        return;
      }
      exportRecommend({unitId: this.listQuery.unitId}).then((res) => {
        apiDownLoadFile(
          res.data,
          'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
          '单位推荐表'
        );
      });
    },

    //导入推荐裁判
    uploadData(param) {
      this.$refs[this.MODAL_KEY.UPLOAD_EXCEL].showLoading();
      importRecommend(param)
        .then((res) => {
          this.$message({
            message: '上传成功！',
            type: 'success',
          });
          this.getList();
          this.$refs[this.MODAL_KEY.UPLOAD_EXCEL].closeLoading();
        })
        .catch(() => {
          this.$refs[this.MODAL_KEY.UPLOAD_EXCEL].closeLoading();
        });
    },

    resetRefereePwd() {
      if (this.validatenull(this.ids)) {
        this.$message.error('请选择要重置密码的数据');
        return;
      }
      this.$refs[this.MODAL_KEY.RESET_MODAL].showModal();
    },

    doReset(data) {
      data.ids = this.ids;
      resetPwd(data).then((res) => {
        this.$message.success('密码重置成功');
        this.$refs[this.MODAL_KEY.RESET_MODAL].closeModal();
      });
    },
  },

  mounted() {
    // 判断当前页面是展示国家级裁判还是一二级裁判
    let isInternation = this.$router.history.current.meta.title.indexOf('国家级') > -1;
    this.listQuery.levels = isInternation ? '4,5' : '1,2,3';
    this.getSpeciality();
    this.getUnit();
    this.getRefereeLevelList();
    this.showType = getStore({name: 'showType'}) || 'table';
  },
};
</script>

<style lang="less">
.move-icon {
  display: none;
  font-size: 16px;
  margin: 0 10px;
  background: #73d4f6;
  border-radius: 50%;
  color: #fff;
  cursor: pointer;
}

.table-row {
  &:hover {
    .move-icon {
      display: inline-block;
    }
  }
}

.switch-icon {
  .iconfont {
    color: #73d4f6;
    font-size: 24px;
    cursor: pointer;
  }
}

.card-img {
  width: 90px;
  height: 120px;
  float: left;
}

.card-con {
  float: left;
  margin-left: 10px;
  margin-top: 5px;
  min-width: 40%;
}
</style>
