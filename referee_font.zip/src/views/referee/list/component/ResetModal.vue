<template>
    <el-dialog
            title="重置密码"
            :close-on-click-modal="isClickModalClose"
            :visible.sync="isShow"
            :width="defaultWidth"
            @close="closeModal"
    >
        <el-form :ref="formName" :model="modalData" :rules="ruleValidate" label-width="100px">
            <el-form-item prop="code" label="验证码：">
                <el-row>
                    <el-col :span="10">
                        <el-input type="text" size="large" v-model="modalData.code"
                                  placeholder="请输入验证码">
                        </el-input>
                    </el-col>

                    <el-col :span="10" :offset="2">
                        <div @click="refreshCode" style="cursor: pointer;">
                            <VerifyCode :pageid="modalData.pageid"></VerifyCode>
                        </div>
                    </el-col>
                </el-row>
            </el-form-item>
        </el-form>

        <div slot="footer">
            <el-button @click="closeModal">
                取消
            </el-button>

            <el-button @click="submit" type="primary">
                确定
            </el-button>
        </div>
    </el-dialog>
</template>

<script>
    import modalMixin from '@/mixins/modalMixin';
    import {generateUid} from '@/common/util';

    export default {
        mixins: [modalMixin],
        props: [],
        data() {
            return {
                code: '/api/login/code?pageid=',
                formName: 'form',
                modalData: {
                    code: '',
                },
                ruleValidate: {
                    code: [
                        {
                            required: true,
                            message: '验证码不能为空！',
                            trigger: 'blur'
                        }
                    ],
                }
            };
        },
        methods: {
            showModal() {
                this.refreshCode();
                this.isShow = true;
            },

            refreshCode() {
                this.modalData.code = '';
                this.modalData.pageid = generateUid();
            },
            submit() {
                this.validateForm().then(res => {
                    this.$emit('submit', this.modalData);
                })
            },
        },
    }
</script>
