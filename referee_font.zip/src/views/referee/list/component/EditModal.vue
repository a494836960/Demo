<template>
  <el-dialog
    :title="type === 'edit' ? '编辑裁判' : '新增裁判'"
    :close-on-click-modal="isClickModalClose"
    :visible.sync="isShow"
    width="70%"
    @close="closeModal"
  >
    <el-form :ref="formName" :model="modalData" :rules="ruleValidate" label-width="115px">
      <el-divider content-position="left">基本信息</el-divider>
      <el-row :gutter="40">
        <el-col :span="9">
          <el-form-item label="注册归属省市：" prop="unitId">
            <el-select v-model="modalData.unitId" placeholder="请选择注册归属省市" filterable>
              <el-option
                v-for="(item, index) in unitList"
                :value="item.id"
                :label="item.cnName"
                :key="index"
              ></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="性别：" prop="sex">
            <el-radio-group v-model="modalData.sex">
              <el-radio :label="0">男</el-radio>
              <el-radio :label="1">女</el-radio>
            </el-radio-group>
          </el-form-item>

          <el-form-item label="出生日期：" prop="birthday">
            <el-date-picker
              style="width:100%;"
              v-model="modalData.birthday"
              value-format="timestamp"
              type="date"
              placeholder="选择日期"
            >
            </el-date-picker>
          </el-form-item>

          <el-form-item label="民族：" prop="ethnicity">
            <el-select v-model="modalData.ethnicity" placeholder="请选择民族">
              <el-option
                v-for="(item, index) in ethnicityList"
                :value="item"
                :label="item"
                :key="index"
              ></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="籍贯：" prop="area">
            <el-cascader
              v-model="modalData.area"
              :options="areasList"
              :props="{value: 'name', label: 'name'}"
            ></el-cascader>
          </el-form-item>

          <el-form-item label="户籍地址：" prop="contactAddress">
            <el-input
              v-model="modalData.contactAddress"
              placeholder="请输入户籍地址"
              :maxLength="32"
            ></el-input>
          </el-form-item>

          <el-form-item label="手机号：" prop="mobile">
            <el-input
              v-model="modalData.mobile"
              placeholder="请输入手机号"
              :maxLength="11"
            ></el-input>
          </el-form-item>

          <el-form-item label="QQ：" prop="qq">
            <el-input v-model="modalData.qq" placeholder="请输入QQ" :maxLength="32"></el-input>
          </el-form-item>

          <el-form-item label="健康状况：" prop="health">
            <el-input
              type="textarea"
              v-model="modalData.health"
              placeholder="良好、一般、较差、如有疾病如实填写"
              :maxLength="20"
            ></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="9">
          <el-form-item label="姓名(中文)：" prop="cnName">
            <el-input
              v-model="modalData.cnName"
              placeholder="请输入姓名"
              :maxLength="32"
            ></el-input>
          </el-form-item>

          <el-row :gutter="20">
            <el-col :span="12">
              <el-form-item label="姓名(拼音)：" prop="enSurname">
                <el-input
                  v-model="modalData.enSurname"
                  placeholder="请输入姓"
                  :maxLength="32"
                ></el-input>
              </el-form-item>
            </el-col>

            <el-col :span="12">
              <el-form-item prop="enName" label-width="0">
                <el-input
                  v-model="modalData.enName"
                  placeholder="请输入名"
                  :maxLength="32"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>

          <el-form-item label="身份证：" prop="idcard">
            <el-input
              v-model="modalData.idcard"
              placeholder="请输入身份证"
              :maxLength="32"
            ></el-input>
          </el-form-item>

          <el-form-item label="政治面貌：" prop="political">
            <el-select v-model="modalData.political" placeholder="请输入政治面貌">
              <el-option
                v-for="(item, index) in politicalList"
                :value="item"
                :label="item"
                :key="index"
              ></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="身高：" prop="height">
            <el-input v-model="modalData.height" placeholder="请输入身高" :maxLength="32">
              <span slot="suffix">cm</span>
            </el-input>
          </el-form-item>

          <el-form-item label="体重：" prop="weight">
            <el-input v-model="modalData.weight" placeholder="请输入体重" :maxLength="32">
              <span slot="suffix">kg</span>
            </el-input>
          </el-form-item>

          <el-form-item label="服装尺码：" prop="clothSize">
            <el-select v-model="modalData.clothSize">
              <el-option
                v-for="(item, index) in CLOTHES_SIZE_LIST"
                :value="item.value"
                :label="item.name"
                :key="index"
              ></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="鞋码：" prop="shoeSize">
            <el-select v-model="modalData.shoeSize">
              <el-option
                v-for="(item, index) in SHOES_SIZE_LIST"
                :value="item.value"
                :label="item.name"
                :key="index"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>

        <el-col :span="6">
          <el-form-item label-width="0" prop="photo">
            <UploadImg
              action="/admin/referee/add/temp"
              :defaultUrl="modalData.photo ? imgUrl + modalData.photo : ''"
              @success="changePhoto"
            ></UploadImg>
          </el-form-item>
          <div class="img-tips">
            <p>上传头像<span style="margin-left: 20px;">宽高比例3：4</span></p>
            <dl>
              <dt>相片格式要求：</dt>
              <dd>近期（半年内）彩色正面照片，能清晰辨认容貌，未经加工润色，无污点，无损坏；</dd>
              <dd>背景为白色，衣服颜色必须和背景颜色有明显差别；</dd>
              <dd>除宗教或医疗等特殊原因外，拍照时不允许带帽子、头巾、发带、墨镜等；</dd>
              <dd>相片文件格式为jpeg，大小不大于40K-300KB。</dd>
            </dl>
          </div>
        </el-col>
      </el-row>

      <el-divider content-position="left">工作情况</el-divider>
      <el-row :gutter="20">
        <el-col :span="8">
          <el-form-item label="工作单位：" prop="inaugurationUnit">
            <el-input
              v-model="modalData.inaugurationUnit"
              placeholder="请输入工作单位"
              :maxLength="32"
            ></el-input>
          </el-form-item>
        </el-col>

        <el-col :span="8">
          <el-form-item label="单位电话：" prop="inaugurationUnitTel">
            <el-input
              v-model="modalData.inaugurationUnitTel"
              placeholder="请输入单位电话"
              :maxLength="32"
            ></el-input>
          </el-form-item>
        </el-col>

        <el-col :span="8">
          <el-form-item label="个人邮箱：" prop="inaugurationUnitEmail">
            <el-input
              v-model="modalData.inaugurationUnitEmail"
              placeholder="请输入个人邮箱"
              :maxLength="32"
            ></el-input>
          </el-form-item>
        </el-col>

        <el-col :span="8">
          <el-form-item label="联系地址：" prop="inaugurationUnitAddres">
            <el-input
              v-model="modalData.inaugurationUnitAddres"
              placeholder="请输入联系地址"
              :maxLength="32"
            ></el-input>
          </el-form-item>
        </el-col>

        <el-col :span="8">
          <el-form-item label="邮政编码：" prop="inaugurationUnitPasspot">
            <el-input
              v-model="modalData.inaugurationUnitPasspot"
              placeholder="请输入邮政编码"
              :maxLength="32"
            ></el-input>
          </el-form-item>
        </el-col>
      </el-row>

      <el-divider content-position="left">教育背景</el-divider>
      <el-row :gutter="20">
        <el-col :span="8">
          <el-form-item label="学历：" prop="education">
            <el-select v-model="modalData.education" placeholder="请选择学历">
              <el-option
                v-for="(item, index) in educationList"
                :value="item.value"
                :label="item.name"
                :key="index"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>

        <el-col :span="8">
          <el-form-item label="擅长外语：" prop="language">
            <el-select v-model="modalData.language" placeholder="请选择外语">
              <el-option
                v-for="(item, index) in languageList"
                :value="item.value"
                :label="item.name"
                :key="index"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>

        <el-col :span="8">
          <el-form-item label="外语水平：" prop="languageLevel">
            <el-select v-model="modalData.languageLevel" placeholder="请选择外语水平">
              <el-option
                v-for="(item, index) in languageLevel"
                :value="item.value+''"
                :label="item.name"
                :key="index"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>

        <el-col :span="8">
          <el-form-item label="职称：" prop="technicalTitle">
            <el-input
              v-model="modalData.technicalTitle"
              placeholder="请输入职称：教授、副教授等"
              :maxLength="32"
            ></el-input>
          </el-form-item>
        </el-col>
      </el-row>

      <el-divider content-position="left">执裁经历</el-divider>
      <el-row :gutter="40">
        <el-col :span="24">
          <el-row :gutter="40">
            <el-col :span="12">
              <el-form-item label="裁判等级：" prop="level">
                <el-select v-model="modalData.level" placeholder="请选择裁判等级" filterable>
                  <el-option
                    v-for="(item, index) in levelList"
                    :value="item.code"
                    :label="item.name"
                    :key="index"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>

            <el-col :span="12">
              <el-form-item label="发证时间：" prop="prejudgeda">
                <el-date-picker
                  style="width:100%"
                  v-model="modalData.prejudgeda"
                  value-format="timestamp"
                  type="month"
                  placeholder="选择发证时间"
                ></el-date-picker>
              </el-form-item>
            </el-col>

            <el-col :span="12">
              <el-form-item label="证书编号：" prop="certificateCode">
                <el-input v-model="modalData.certificateCode" placeholder="请输入证书编号" />
              </el-form-item>
            </el-col>

            <el-col :span="12">
              <el-form-item label="发证单位：" prop="certificateUnit">
                <el-input
                  type="text"
                  v-model="modalData.certificateUnit"
                  placeholder="请输入发证单位"
                />
              </el-form-item>
            </el-col>

            <el-col :span="12"  v-if="modalData.level == 4 || modalData.level == 5">
              <el-form-item label="技术类型：" prop="technical">
                <el-select v-model="modalData.technical" placeholder="请选择技术类型" filterable>
                  <el-option
                    v-for="(item, index) in positionList"
                    :value="item.code"
                    :label="item.name"
                    :key="index"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>

          <el-form-item label="执裁经历：" prop="experience">
            <el-input
              type="textarea"
              autosize
              v-model="modalData.experience"
              placeholder="请输入执裁经历"
              :maxLength="32"
            ></el-input>
          </el-form-item>

          <el-form-item label="特长：" prop="speciality">
            <el-select
              v-model="modalData.speciality"
              placeholder="请选择特长最多3个"
              :multiple-limit="3"
              multiple
            >
              <el-option
                v-for="(item, index) in specialityList"
                :key="index"
                :value="item.code"
                :label="item.name"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>

      <el-divider content-position="left">证件上传</el-divider>
      <el-form-item prop="certificateCoverPath">
        <el-row :gutter="20">
          <el-col :span="6">
            <UploadImg
              :defaultUrl="
                modalData.certificateCoverPath ? imgUrl + modalData.certificateCoverPath : ''
              "
              action="/admin/referee/add/temp"
              @success="
                e => {
                  fileUpload(e, 'certificateCoverPath');
                }
              "
            ></UploadImg>
            <span>等级证书封面</span>
          </el-col>

          <el-col :span="6">
            <UploadImg
              :defaultUrl="modalData.levelPhotoPath ? imgUrl + modalData.levelPhotoPath : ''"
              action="/admin/referee/add/temp"
              @success="
                e => {
                  fileUpload(e, 'levelPhotoPath');
                }
              "
            ></UploadImg>
            <span>等级证书内容面</span>
          </el-col>
          <el-col :span="6">
            <UploadImg
              :defaultUrl="
                modalData.certificateBackPath ? imgUrl + modalData.certificateBackPath : ''
              "
              action="/admin/referee/add/temp"
              @success="
                e => {
                  fileUpload(e, 'certificateBackPath');
                }
              "
            ></UploadImg>
            <span>等级证书背面</span>
          </el-col>

          <el-col :span="6" v-if="modalData.level == 4 || modalData.level == 5">
            <el-form-item prop="technicalPath" label-width="0">
              <UploadImg
                :defaultUrl="modalData.technicalPath ? imgUrl + modalData.technicalPath : ''"
                action="/admin/referee/add/temp"
                @success="
                  e => {
                    fileUpload(e, 'technicalPath');
                  }
                "
              ></UploadImg>
              <span>技术官员证</span>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form-item>

      <el-form-item class="img-tips">
        <p>上传证书<span style="margin-left: 20px;">宽高比例4：3</span></p>
        <dl>
          <dt>证书格式要求：</dt>
          <dd>证件图像能清晰辨认，未经加工润色，无污点，无损坏；</dd>
          <dd>证件格式为jpeg、png，大小不大于40K-300KB。</dd>
        </dl>
      </el-form-item>
    </el-form>

    <div slot="footer">
      <el-button @click="closeModal">
        取消
      </el-button>

      <el-button @click="submit" type="primary">
        确定
      </el-button>
    </div>
  </el-dialog>
</template>

<script>
import modalMixin from '@/mixins/modalMixin';
import {areas} from '@/common/area.js';
import political from '@/common/political';
import nation from '@/common/nation';
import {fetchPosition} from '@/api/position';
import {
  EDUCATION_TYPE,
  LANGUAGE_LEVEL,
  LANGUAGE_TYPE,
  SHOES_SIZE_LIST,
  CLOTHES_SIZE_LIST,
  refereeValidator
} from '@/const/index';
import _ from 'lodash';
import moment from 'moment';

export default {
  mixins: [modalMixin],
  props: {
    modalData: {type: Object, default: {}},
    type: {},
    specialityList: {},
    unitList: {},
    levelList: {}
  },
  data() {
    let curYear = new Date().getFullYear();
    let years = new Array(100).fill(curYear).map((i, k) => {
      return i - k;
    });
    return {
      CLOTHES_SIZE_LIST: CLOTHES_SIZE_LIST,
      SHOES_SIZE_LIST: SHOES_SIZE_LIST,
      certificateYear: years,
      languageList: LANGUAGE_TYPE,
      languageLevel: LANGUAGE_LEVEL,
      educationList: EDUCATION_TYPE,
      areasList: areas.provinces,
      politicalList: political, // 政治面貌list
      ethnicityList: nation, // 民族list
      front: require('@/assets/image/idcard_front.png'),
      back: require('@/assets/image/idcard_back.png'),
      imgUrl: this.imgUrl,
      formName: 'form',
      ruleValidate: refereeValidator,
      positionList: []
    };
  },
  mounted(){
    this.getPositionList();
  },
  methods: {
    frontChange(res) {
      this.$set(this.modalData, 'idcardFacePath', res.path);

      if (res.idcardInfo.birth) {
        let birthday = new moment(res.idcardInfo.birth, 'YYYYMMDD');
        this.$set(this.modalData, 'birthday', birthday);
      }
      if (res.idcardInfo.sex) {
        this.$set(this.modalData, 'sex', res.idcardInfo.sex === '男' ? 0 : 1);
      }
      if (res.idcardInfo.name) {
        this.$set(this.modalData, 'cnName', res.idcardInfo.name);
      }

      if (res.idcardInfo.num) {
        this.$set(this.modalData, 'idcard', res.idcardInfo.num);
      }

      if (res.idcardInfo.nationality) {
        this.$set(this.modalData, 'ethnicity', res.idcardInfo.nationality + '族');
      }

      if (res.idcardInfo.address) {
        this.$set(this.modalData, 'contactAddress', res.idcardInfo.address);
      }
    },

    backChange(res) {
      this.$set(this.modalData, 'idcardBackPath', res.path);
    },

    submit() {
      this.validateForm().then(res => {
        let obj = this.deepClone(this.modalData);
        if (!this.validatenull(obj.area)) {
          obj.province = obj.area[0];
          obj.city = obj.area[1];
        }
        obj.speciality = `${_.compact(obj.speciality).join(',')}`;
        this.$emit('submit', obj);
      });
    },

    fileUpload(e, index) {
      this.$set(this.modalData, index, e);
    },

    getPositionList(){
      fetchPosition({page_size: 1000}).then(res=>{
        this.positionList = res.data.data.results;
      })
    },

    changeLevelPhoto(res) {
      this.$set(this.modalData, 'levelPhotoPath', res);
    },

    changePhoto(res) {
      this.$set(this.modalData, 'photo', res);
    }
  }
};
</script>

<style lang="less">
.img-tips {
  line-height: 23px;

  dl {
    list-style: circle;
  }

  dt {
    font-weight: bold;
    margin-top: 10px;
  }
}
</style>
