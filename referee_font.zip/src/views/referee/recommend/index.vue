<template>
  <div>
    <el-row :gutter="20" class="search-box">
      <el-col :span="4" v-if="$store.getters.userInfo.unitType === 'ALL'">
        <el-select
          v-model="listQuery.unitId"
          placeholder="注册所属省市"
          clearable
          filterable
          @change="getList(1)"
        >
          <el-option
            v-for="(item, index) in unitList"
            :key="index"
            :value="item.id"
            :label="item.cnName"
          ></el-option>
        </el-select>
      </el-col>

      <el-col :span="4">
        <el-select
          v-model="listQuery.specialityCode"
          placeholder="特长"
          clearable
          filterable
          @change="getList(1)"
        >
          <el-option
            v-for="(item, index) in specialityList"
            :key="index"
            :value="item.code"
            :label="item.name"
          ></el-option>
        </el-select>
      </el-col>

      <el-col :span="4">
        <el-select
          v-model="listQuery.languageLevel"
          placeholder="外语等级"
          clearable
          filterable
          @change="getList(1)"
        >
          <el-option
            v-for="(item, index) in LANGUAGE_LEVEL"
            :key="index"
            :value="item.value"
            :label="item.name"
          ></el-option>
        </el-select>
      </el-col>

      <el-col :span="4" v-if="isShowFilter">
        <el-select
          v-model="listQuery.language"
          placeholder="外语语种"
          clearable
          filterable
          @change="getList(1)"
        >
          <el-option
            v-for="(item, index) in LANGUAGE_TYPE"
            :key="index"
            :value="item.value"
            :label="item.name"
          ></el-option>
        </el-select>
      </el-col>

      <el-col :span="4" v-if="isShowFilter">
        <el-select
          v-model="listQuery.recommendStatus"
          placeholder="注册类型"
          clearable
          filterable
          @change="getList(1)"
        >
          <el-option :value="0" label="新注册"></el-option>
          <el-option :value="1" label="确认注册"></el-option>
        </el-select>
      </el-col>

      <el-col :span="4" v-if="isShowFilter">
        <el-select
          v-model="listQuery.unitCheckStatus"
          placeholder="单位审核"
          clearable
          filterable
          @change="getList(1)"
        >
          <el-option :value="0" label="单位未审核"></el-option>
          <el-option :value="1" label="单位已审核"></el-option>
        </el-select>
      </el-col>

      <el-col :span="4" v-if="isShowFilter">
        <el-select
          v-model="listQuery.centerCheckStatus"
          placeholder="田协审核"
          clearable
          filterable
          @change="getList(1)"
        >
          <el-option :value="0" label="田协未审核"></el-option>
          <el-option :value="1" label="田协已审核"></el-option>
        </el-select>
      </el-col>

      <el-col :span="4" v-if="isShowFilter">
        <el-select
          v-model="listQuery.isPhoto"
          placeholder="是否有头像"
          clearable
          filterable
          @change="getList(1)"
        >
          <el-option :value="0" label="无"></el-option>
          <el-option :value="1" label="有"></el-option>
        </el-select>
      </el-col>

      <el-col :span="4" v-if="isShowFilter">
        <el-input placeholder="姓名" v-model="listQuery.cnName" @change="getList(1)"></el-input>
      </el-col>

      <el-col :span="4" v-if="isShowFilter">
        <el-input placeholder="身份证" v-model="listQuery.idcard" @change="getList(1)"></el-input>
      </el-col>

      <el-col :span="4" v-if="isShowFilter">
        <el-input placeholder="手机号" v-model="listQuery.mobile" @change="getList(1)"></el-input>
      </el-col>

      <el-col :span="4">
        <el-button type="primary" @click="getList(1)">查询</el-button>
      </el-col>
    </el-row>
    <el-row :gutter="20">
      <el-button class="but" type="primary" @click="showRecommend" v-auth="per.referee_recommend_do"
        >推荐
      </el-button>
      <el-button
        class="but"
        type="danger"
        @click="onRecommendRefer(0, ids)"
        v-auth="per.referee_recommend_do"
      >
        取消推荐
      </el-button>

      <UploadExcel
        v-auth="per.referee_recommend_import"
        :ref="MODAL_KEY.UPLOAD_EXCEL"
        @submit="uploadData"
        class="but"
        style="display: inline-block;"
      >
        <el-button type="info">导入推荐裁判</el-button>
      </UploadExcel>
      <el-button
        class="but"
        type="info"
        @click="onRecomDownTemp"
        v-auth="per.referee_recommend_import"
      >
        下载推荐模板
      </el-button>

      <el-button
        class="but"
        type="primary"
        @click="onRecommendDown()"
        v-auth="per.referee_recommend_export"
      >
        导出推荐
      </el-button>
    </el-row>

    <el-table
      border
      height="600px"
      :data="dataSource"
      class="page-top-space"
      row-class-name="table-row"
      @selection-change="changeSelect"
    >
      <el-table-column type="selection"> </el-table-column>

      <el-table-column type="index" label="序号"> </el-table-column>

      <el-table-column prop="cnName" label="姓名"> </el-table-column>

      <el-table-column prop="sex" min-width="80px" label="性别">
        <template slot-scope="scope">
          <MyBadge :list="GENDER" :target="scope.row.sex"></MyBadge>
        </template>
      </el-table-column>

      <el-table-column prop="level" width="150px" label="等级">
        <template slot-scope="scope">
          <span><MyBadge :list="LEVEL_TYPE" :target="scope.row.level"></MyBadge></span>
          ({{ scope.row.prejudgeda | dateFormat(null, 'YYYY-MM-DD') }})
        </template>
      </el-table-column>

      <el-table-column prop="birthday" label="出生日期" min-width="100px">
        <template slot-scope="scope">
          <span>{{ scope.row.birthday | dateFormat(null, 'YYYY-MM-DD') }}</span>
        </template>
      </el-table-column>

      <el-table-column
        v-if="$store.getters.userInfo.unitType === 'ALL'"
        prop="unitName"
        label="注册所属省市"
      >
      </el-table-column>

      <el-table-column prop="inaugurationUnit" label="就职单位" min-width="150px">
      </el-table-column>

      <el-table-column prop="specialityName" label="特长" min-width="120px">
        <template slot-scope="scope">
          <span>{{ scope.row.specialityName && scope.row.specialityName.join(' ') }}</span>
        </template>
      </el-table-column>

      <el-table-column prop="language" width="70px" label="外语"> </el-table-column>

      <el-table-column prop="isRecommend" label="推荐状态">
        <template slot-scope="scope">
          <MyBadge :list="RECOMMEND_TYPE" :target="scope.row.isRecommend"></MyBadge>
        </template>
      </el-table-column>

      <el-table-column prop="designationNum" width="80px" label="选派次数"> </el-table-column>

      <el-table-column prop="centerCheckStatus" width="150px" label="审核状态">
        <template slot-scope="scope">
          <p>
            中国田协：
            <span v-if="scope.row.centerCheckStatus == 0" class="text-danger">
              未审核
            </span>
            <span v-else class="text-success">
              已审核
            </span>
          </p>
          <p>
            主管单位：
            <span v-if="scope.row.unitCheckStatus == 0" class="text-danger">
              未审核
            </span>
            <span v-else class="text-success">
              已审核
            </span>
          </p>
        </template>
      </el-table-column>

      <el-table-column label="操作" fixed="right" width="100px">
        <template slot-scope="scope">
          <span class="option option-primary" @click="goDetailReferee(scope.row.id)">详情</span>
        </template>
      </el-table-column>
    </el-table>

    <el-pagination
      class="page-top-space"
      background
      :total="total"
      :page-size="listQuery.pageSize"
      :current-page.sync="listQuery.pageNo"
      @current-change="getList"
    >
    </el-pagination>
    <SelectRecommendModal
      :ref="MODAL_KEY.SELECT_RECOMMEND_MODAL"
      :specialityMap="specialityMap"
      @submit="
        (ids) => {
          this.onRecommendRefer(1, ids);
        }
      "
    ></SelectRecommendModal>
  </div>
</template>

<script>
import {
  fetchRefereeList,
  RecommendReferee,
  fetchRecommendTemplate,
  importRecommend,
  exportRecommend
} from '@/api/referee';
import {
  LANGUAGE_LEVEL,
  LANGUAGE_TYPE,
  RECOMMEND_TYPE,
  GENDER,
  LEVEL_TYPE,
  ROLE
} from '@/const/index';
import {fetchSpeciality, fetchRefereeLevel} from '@/api/common';
import {fetchUnitAll} from '@/api/unit';
import {apiDownLoadFile, exportAnchorFile} from '@/common/util';
import SelectRecommendModal from './components/SelectRecommendModal';

export default {
  components: {SelectRecommendModal},
  data() {
    let userInfo = this.$store.getters.userInfo;
    return {
      isShowFilter: true,
      ROLE_CODE: ROLE,
      userInfo: this.$store.getters.userInfo,
      role: this.$store.getters.permissions[0],
      LEVEL_TYPE: LEVEL_TYPE,
      LANGUAGE_LEVEL: LANGUAGE_LEVEL,
      LANGUAGE_TYPE: LANGUAGE_TYPE,
      RECOMMEND_TYPE: RECOMMEND_TYPE,
      GENDER: GENDER,
      MODAL_KEY: {
        SELECT_RECOMMEND_MODAL: 'SELECT_RECOMMEND_MODAL',
        UPLOAD_EXCEL: 'UPLOAD_EXCEL'
      },
      listQuery: {
        pageNo: 1,
        pageSize: 10,
        isRecommend: 1,
        unitId: userInfo.unitType === 'ALL' ? '' : userInfo.unitId
      },
      total: 0,
      dataSource: [],
      modalData: {},
      modalType: '',
      specialityList: [],
      unitList: [],
      specialityMap: {},
      levelList: [],
      ids: []
    };
  },
  methods: {
    showRecommend() {
      this.$refs[this.MODAL_KEY.SELECT_RECOMMEND_MODAL].showModal();
    },
    changeSelect(selection) {
      this.ids = [];
      selection.map((item) => {
        this.ids.push(item.id);
      });
    },

    goDetailReferee(id) {
      this.$router.push(`/referee/detail/${id}`);
    },

    getList(current) {
      if (!this.validatenull(current)) {
        this.listQuery.pageNo = current;
      }
      fetchRefereeList(this.listQuery).then((res) => {
        this.dataSource = res.data.data.results;
        this.dataSource.map((item) => {
          // 特长
          if (!this.validatenull(item.speciality)) {
            item.specialityName = '';
            item.speciality = item.speciality.replace(/\s/g, '');
            item.specialityName = item.speciality
              .substring(1, item.speciality.length - 1)
              .split(',')
              .map((item) => {
                return this.specialityMap[item];
              });
          }
        });
        this.total = res.data.data.total_record;
      });
    },

    getSpeciality() {
      fetchSpeciality().then((res) => {
        this.specialityList = res.data.data;
        res.data.data &&
          res.data.data.map((item) => {
            this.specialityMap[item.code] = item.name;
          });

        this.getList();
      });
    },

    //获取单位列表
    getUnit() {
      fetchUnitAll().then((res) => {
        this.unitList = res.data.data;
      });
    },

    // 获取裁判等级列表
    getRefereeLevelList() {
      fetchRefereeLevel().then((res) => {
        this.levelList = res.data.data;
      });
    },

    //推荐
    onRecommendRefer(type, ids) {
      if (this.validatenull(ids)) {
        this.$message.error('请选择数据进行操作');
        return;
      }
      let params = [];
      ids.map((item) => {
        params.push({id: item, state: type});
      });

      this.$confirm('是否要操作推荐', '提示', {type: 'warning'}).then((res) => {
        RecommendReferee(params).then((res) => {
          this.$message.success('操作成功');
          this.getList();
          this.$refs[this.MODAL_KEY.SELECT_RECOMMEND_MODAL].closeModal();
          this.$store.dispatch('getUnitInfo'); //更新推荐人数
        });
      });
    },

    //下载推荐模板
    onRecomDownTemp() {
      exportAnchorFile(this.baseUrl + fetchRecommendTemplate());
    },

    onRecommendDown() {
      if (this.validatenull(this.listQuery.unitId)) {
        this.$message.error('请选择单位进行导出');
        return;
      }
      exportRecommend({unitId: this.listQuery.unitId}).then((res) => {
        apiDownLoadFile(
          res.data,
          'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
          '单位推荐表'
        );
      });
    },

    //导入推荐裁判
    uploadData(param) {
      this.$refs[this.MODAL_KEY.UPLOAD_EXCEL].showLoading();
      importRecommend(param)
        .then((res) => {
          this.$message({
            message: '上传成功！',
            type: 'success'
          });
          this.getList();
          this.$refs[this.MODAL_KEY.UPLOAD_EXCEL].closeLoading();
        })
        .catch(() => {
          this.$refs[this.MODAL_KEY.UPLOAD_EXCEL].closeLoading();
        });
    }
  },

  mounted() {
    this.getSpeciality();
    this.getUnit();
    this.getRefereeLevelList();
  }
};
</script>
