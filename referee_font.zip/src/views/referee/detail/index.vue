<!-- 裁判员详细信息 -->
<template>
    <div>
        <RefereeDetail :id="id"></RefereeDetail>
        <div class="text-c">
            <el-button type="info" @click="goBack">返回</el-button>
        </div>
    </div>
</template>

<script>
    import modalMixin from '@/mixins/modalMixin';
    import RefereeDetail from '@/components/refereeDetail';

    export default {
        mixins: [modalMixin],
        components: {RefereeDetail},
        data() {
            return {
                imgUrl: this.imgUrl,
                formName: 'form',
                referee: {},
                id: '',

            };
        },

        methods: {
            goBack(){
                this.$router.go(-1)
            }
        },

        mounted() {
            this.id = this.$router.history.current.params.id;
        }
    }
</script>

<style lang="less">

</style>
