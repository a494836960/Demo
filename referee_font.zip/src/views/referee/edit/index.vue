<template>
    <div style="padding: 30px;">
        <el-steps :active="active" simple style="margin-bottom: 20px;">
            <el-step title="基本信息" icon="el"></el-step>
            <el-step title="工作情况" icon="el"></el-step>
            <el-step title="教育背景" icon="el"></el-step>
            <el-step title="执裁经历" icon="el"></el-step>
        </el-steps>


        <div v-if="active === 0">
            <el-form ref="form1" :model="data1" :rules="ruleValidate" label-width="100px">
                <el-row :gutter="40">
                    <el-col :span="9">
                        <!-- <el-form-item label="身份证正面" prop="idcardFacePath" style="height: 100px;">
                            <UploadImg
                                    action="admin/resources/ocr/idcard?site=face"
                                    :defaultBg="front"
                                    :defaultUrl="data1.idcardFacePath?imgUrl+data1.idcardFacePath :''"
                                    @success="frontChange"></UploadImg>
                        </el-form-item> -->

                        <el-form-item label="姓名(中文)：" prop="cnName">
                            <el-input v-model="data1.cnName" placeholder="请输入姓名" :maxLength="32"></el-input>
                        </el-form-item>

                        <el-form-item label="身份证：" prop="idcard">
                            <el-input v-model="data1.idcard" placeholder="请输入身份证" :maxLength="32"></el-input>
                        </el-form-item>

                        <el-form-item label="性别：" prop="sex">
                            <el-radio-group v-model="data1.sex">
                                <el-radio :label="0">男</el-radio>
                                <el-radio :label="1">女</el-radio>
                            </el-radio-group>
                        </el-form-item>

                        <el-form-item label="注册所属省市：" prop="unitId">
                            <el-select v-model="data1.unitId" placeholder="请选择注册所属省市" filterable :disabled="id != -1">
                                <el-option v-for="(item,index) in unitList" :value="item.id" :label="item.cnName"
                                           :key="index"></el-option>
                            </el-select>
                        </el-form-item>

                        <el-form-item label="政治面貌：" prop="political">
                            <el-select v-model="data1.political" placeholder="请输入政治面貌">
                                <el-option v-for="(item, index) in politicalList" :value="item" :label="item"
                                           :key="index"></el-option>
                            </el-select>
                        </el-form-item>

                        <el-form-item label="身高：" prop="height">
                            <el-input v-model="data1.height" placeholder="请输入身高" :maxLength="32">
                                <span slot="suffix">cm</span>
                            </el-input>
                        </el-form-item>

                        <el-form-item label="体重：" prop="weight">
                            <el-input v-model="data1.weight" placeholder="请输入体重" :maxLength="32">
                                <span slot="suffix">kg</span>
                            </el-input>
                        </el-form-item>

                        <el-form-item label="健康状况：" prop="health">
                            <el-input type="textarea" v-model="data1.health" placeholder="良好、一般、较差、如有疾病如实填写"
                                      :maxLength="20"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="9">
                        <!-- <el-form-item label="身份证反面" prop="idcardBackPath" style="height: 100px;">
                            <UploadImg
                                    action="admin/resources/ocr/idcard?site=back"
                                    :defaultBg="back"
                                    :defaultUrl="data1.idcardBackPath?imgUrl+data1.idcardBackPath :''"
                                    @success="backChange"></UploadImg>
                        </el-form-item> -->

                        <el-form-item label="出生日期：" prop="birthday">
                            <el-date-picker
                                    v-model="data1.birthday"
                                    value-format="timestamp"
                                    type="date"
                                    placeholder="选择日期">
                            </el-date-picker>
                        </el-form-item>

                        <el-form-item label="户籍地址：" prop="contactAddress">
                            <el-input v-model="data1.contactAddress" placeholder="请输入户籍地址"
                                      :maxLength="32"></el-input>
                        </el-form-item>

                        <el-form-item label="民族：" prop="ethnicity">
                            <el-select v-model="data1.ethnicity" placeholder="请选择民族">
                                <el-option v-for="(item, index) in ethnicityList" :value="item" :label="item"
                                           :key="index"></el-option>
                            </el-select>
                        </el-form-item>

                        <el-form-item label="手机号：" prop="mobile">
                            <el-input v-model="data1.mobile" placeholder="请输入手机号" :maxLength="11"
                                      :disabled="id != -1"></el-input>
                        </el-form-item>

                        <el-row :gutter="20">
                            <el-col :span="12">
                                <el-form-item label="姓名(拼音)：" prop="enSurname">
                                    <el-input v-model="data1.enSurname" placeholder="请输入姓" :maxLength="32"></el-input>
                                </el-form-item>
                            </el-col>

                            <el-col :span="12">
                                <el-form-item prop="enName" label-width="0">
                                    <el-input v-model="data1.enName" placeholder="请输入名" :maxLength="32"></el-input>
                                </el-form-item>
                            </el-col>
                        </el-row>

                        <el-form-item label="籍贯：" prop="area">
                            <el-cascader
                                    v-model="data1.area"
                                    :options="areasList"
                                    :props="{value: 'name',label: 'name'}"></el-cascader>
                        </el-form-item>

                        <el-form-item label="QQ：" prop="qq">
                            <el-input v-model="data1.qq" placeholder="请输入QQ" :maxLength="32"></el-input>
                        </el-form-item>

                    </el-col>

                    <el-col :span="6">
                        <el-form-item prop="photo" label-width="0">
                            <UploadImg
                                    :action="id != -1 ? `/admin/referee/uploadPhoto/${id}`:'/admin/referee/add/temp'"
                                    :defaultUrl="data1.photo?imgUrl+data1.photo :''"
                                    @success="changePhoto"></UploadImg>
                        </el-form-item>

                        <div class="img-tips">
                            <p>上传头像<span style="margin-left: 20px;">宽高比例3：4</span></p>
                            <dl>
                                <dt>相片格式要求：</dt>
                                <dd> 近期（半年内）彩色正面照片，能清晰辨认容貌，未经加工润色，无污点，无损坏；</dd>
                                <dd>背景为白色，衣服颜色必须和背景颜色有明显差别；</dd>
                                <dd>除宗教或医疗等特殊原因外，拍照时不允许带帽子、头巾、发带、墨镜等；</dd>
                                <dd>相片文件格式为jpeg，大小不大于40K-300KB。</dd>
                            </dl>
                        </div>
                    </el-col>
                </el-row>

                <div class="text-c">
                    <el-button type="primary" @click="stepOne">下一步</el-button>
                </div>
            </el-form>
        </div>
        <div v-if="active === 1">
            <el-form ref="form2" :model="data2" :rules="ruleValidate" label-width="100px">
                <el-row :gutter="20">
                    <el-col :span="8">
                        <el-form-item label="就职单位：" prop="inaugurationUnit">
                            <el-input v-model="data2.inaugurationUnit" placeholder="请输入就职单位"
                                      :maxLength="32"></el-input>
                        </el-form-item>
                    </el-col>

                    <el-col :span="8">
                        <el-form-item label="就职单位电话：" prop="inaugurationUnitTel">
                            <el-input v-model="data2.inaugurationUnitTel" placeholder="请输入单位电话"
                                      :maxLength="32"></el-input>
                        </el-form-item>
                    </el-col>

                    <el-col :span="8">
                        <el-form-item label="就职单位邮箱：" prop="inaugurationUnitEmail">
                            <el-input v-model="data2.inaugurationUnitEmail" placeholder="请输入单位邮箱"
                                      :maxLength="32"></el-input>
                        </el-form-item>
                    </el-col>

                    <el-col :span="8">
                        <el-form-item label="就职单位地址：" prop="inaugurationUnitAddres">
                            <el-input v-model="data2.inaugurationUnitAddres" placeholder="请输入单位地址"
                                      :maxLength="32"></el-input>
                        </el-form-item>
                    </el-col>

                    <el-col :span="8">
                        <el-form-item label="就职单位邮编：" prop="inaugurationUnitPasspot">
                            <el-input v-model="data2.inaugurationUnitPasspot" placeholder="请输入单位邮编"
                                      :maxLength="32"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>

                <div class="text-c">
                    <el-button type="info" @click="previous">上一步</el-button>
                    <el-button type="primary" @click="stepTwo">下一步</el-button>
                </div>
            </el-form>
        </div>

        <div v-if="active === 2">
            <el-form ref="form3" :model="data3" :rules="ruleValidate" label-width="100px">
                <el-row :gutter="20">

                    <el-col :span="8">
                        <el-form-item label="教育背景：" prop="education">
                            <el-select v-model="data3.education" placeholder="请选择学历">
                                <el-option v-for="(item, index) in educationList" :value="item.value" :label="item.name"
                                           :key="index"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>

                    <el-col :span="8">
                        <el-form-item label="外语：" prop="language">
                            <el-select v-model="data3.language" placeholder="请选择外语">
                                <el-option v-for="(item, index) in languageList" :value="item.value" :label="item.name"
                                           :key="index"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>

                    <el-col :span="8">
                        <el-form-item label="外语等级：" prop="languageLevel">
                            <el-select v-model="data3.languageLevel" placeholder="请选择外语等级">
                                <el-option v-for="(item, index) in languageLevel" :value="item.value" :label="item.name"
                                           :key="index"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>

                    <el-col :span="8">
                        <el-form-item label="职称：" prop="technicalTitle">
                            <el-input v-model="data3.technicalTitle" placeholder="请输入职称"
                                      :maxLength="32"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>

                <div class="text-c">
                    <el-button type="info" @click="previous">上一步</el-button>
                    <el-button type="primary" @click="stepThree">下一步</el-button>
                </div>
            </el-form>
        </div>

        <div v-if="active === 3">
            <el-form ref="form4" :model="data4" :rules="ruleValidate" label-width="100px">
                <el-row :gutter="40">
                    <el-col :span="18">
                        <el-row :gutter="40">
                            <el-col :span="12">
                                <el-form-item label="裁判等级：" prop="level">
                                    <el-select v-model="data4.level" placeholder="请选择裁判等级" filterable>
                                        <el-option v-for="(item,index) in levelList" :value="item.code"
                                                   :label="item.name"
                                                   :key="index"></el-option>
                                    </el-select>
                                </el-form-item>
                            </el-col>

                            <el-col :span="12">
                                <el-form-item label="获得裁判时间：" prop="prejudgeda">
                                    <el-date-picker
                                            v-model="data4.prejudgeda"
                                            value-format="timestamp"
                                            type="month"
                                            placeholder="选择时间"
                                    ></el-date-picker>
                                </el-form-item>
                            </el-col>
                        </el-row>

                        <el-form-item label="执裁经历：" prop="experience">
                            <el-input type="textarea" autosize v-model="data4.experience" placeholder="请输入执裁经历"
                                      :maxLength="32"></el-input>
                        </el-form-item>

                        <el-form-item label="特长：" prop="speciality">
                            <el-select v-model="data4.speciality" placeholder="请选择特长最多3个" clearable :multiple-limit="3" multiple>
                                <el-option v-for="(item, index) in specialityList" :key="index" :value="item.code"
                                           :label="item.name"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>

                    <el-col :span="6">
                        <el-form-item prop="levelPhotoPath" label-width="0">
                            <UploadImg
                                    action="/admin/referee/add/temp"
                                    :defaultUrl="data4.levelPhotoPath ? imgUrl+data4.levelPhotoPath : ''"
                                    @success="changeLevelPhoto"></UploadImg>
                        </el-form-item>
                        <div class="img-tips">
                            <p>上传证书<span style="margin-left: 20px;">宽高比例4：3</span></p>
                            <dl>
                                <dt>证书格式要求：</dt>
                                <dd>证件图像能清晰辨认，未经加工润色，无污点，无损坏；</dd>
                                <dd>证件格式为jpeg、png，大小不大于40K-300KB。</dd>
                            </dl>
                        </div>
                    </el-col>
                </el-row>

                <div class="text-c">
                    <el-button type="info" @click="previous">上一步</el-button>
                    <el-button type="primary" @click="stepFour">保存</el-button>
                </div>
            </el-form>
        </div>
    </div>
</template>

<script>
    import modalMixin from '@/mixins/modalMixin';
    import {fetchSpeciality, fetchRefereeLevel} from '@/api/common';
    import {fetchRefereeDetail, updateReferee, addReferee} from '@/api/referee';
    import {areas} from '@/common/area.js'
    import political from '@/common/political'
    import nation from '@/common/nation'
    import {EDUCATION_TYPE, LANGUAGE_LEVEL, LANGUAGE_TYPE} from '@/const/index'
    import _ from 'lodash'
    import {fetchUnitAll} from '@/api/unit'
    import moment from 'moment'
    import {fetchUserInfo} from '@/api/user'

    export default {
        mixins: [modalMixin],
        data() {
            let curYear = new Date().getFullYear();
            let years = new Array(100).fill(curYear).map((i, k) => {
                return i - k;
            });
            return {
                userInfo: {},
                front: require("@/assets/image/idcard_front.png"),
                back: require("@/assets/image/idcard_back.png"),
                id: '-1',
                certificateYear: years,
                languageList: LANGUAGE_TYPE,
                languageLevel: LANGUAGE_LEVEL,
                educationList: EDUCATION_TYPE,
                areasList: areas.provinces,
                politicalList: political, // 政治面貌list
                ethnicityList: nation, // 民族list
                active: 0,
                levelList: [],
                unitList: [],
                specialityList: [],
                data1: {
                    mobile: '',
                },
                data2: {},
                data3: {},
                data4: {},

                imgUrl: this.imgUrl,
                formName: 'form',
                ruleValidate: {
                    qq: [{
                        required: true,
                        message: '请输入QQ',
                    }],
                    weight: [{
                        required: true,
                        message: '请输入体重',
                    }],
                    height: [{
                        required: true,
                        message: '请输入身高',
                    }],
                    health: [{
                        required: true,
                        message: '请输入健康状况',
                    }],
                    idcardBackPath: [{
                        required: true,
                        message: '请上传身份证反面',
                    }],
                    idcardFacePath: [{
                        required: true,
                        message: '请上传身份证正面',
                    }],
                    photo: [{
                        required: true,
                        message: '请上传头像',
                        trigger: 'change'
                    }],
                    contactAddress: [
                        {
                            required: true,
                            message: '户籍地址不能为空！',
                            trigger: 'blur'
                        }
                    ],
                    unitId: [
                        {
                            required: true,
                            message: '注册所属省市不能为空！',
                            trigger: 'change'
                        }
                    ],
                    cnName: [
                        {
                            required: true,
                            message: '中文姓名不能为空！',
                            trigger: 'blur'
                        }
                    ],

                    idcard: [
                        {
                            required: true,
                            message: '身份证不能为空！',
                            trigger: 'blur'
                        }
                    ],
                    area: [
                        {
                            required: true,
                            message: '籍贯不能为空！',
                            trigger: 'change'
                        }
                    ],
                    sex: [
                        {
                            required: true,
                            message: '性别不能为空！',
                            trigger: 'change'
                        }
                    ],
                    political: [
                        {
                            required: true,
                            message: '政治面貌不能为空！',
                            trigger: 'change'
                        }
                    ],
                    prejudgeda: [
                        {
                            required: true,
                            message: '获得裁判年份不能为空',
                            trigger: 'change'
                        }
                    ],
                    inaugurationUnitTel: [{
                        required: true,
                        message: '就职单位电话不能为空',
                        trigger: 'blur'
                    }],
                    ethnicity: [
                        {
                            required: true,
                            message: '民族不能为空！',
                            trigger: 'change'
                        }
                    ], mobile: [
                        {
                            required: true,
                            message: '电话号码不能为空！',
                            trigger: 'blur'
                        }
                    ], firstName: [
                        {
                            required: true,
                            message: '姓不能为空！',
                            trigger: 'blur'
                        }
                    ], lastName: [
                        {
                            required: true,
                            message: '名不能为空！',
                            trigger: 'blur'
                        }
                    ], birthday: [
                        {
                            required: true,
                            message: '出生日期不能为空！',
                            trigger: 'change'
                        }
                    ],
                    inaugurationUnit: {
                        required: true,
                        message: '请输入就职单位',
                        trigger: 'blur'
                    },
                    education: { //
                        required: true,
                        message: '请选择教育背景',
                        trigger: 'change'
                    },
                    level: {
                        required: true,
                        message: '请选择裁判等级',
                        trigger: 'change'
                    },
                    levelPhotoPath: {
                        required: true,
                        message: '请上传证书扫描件',
                        trigger: 'change'
                    },
                    speciality: {
                        required: true,
                        message: '请选择特长',
                        trigger: 'change'
                    }

                }
            };
        },
        methods: {
            previous() {
                this.active--;
            },

            getSpeciality(item) {
                fetchSpeciality().then(res => {
                    this.specialityList = res.data.data;
                });
            },

            // 获取裁判等级列表
            getRefereeLevelList() {
                fetchRefereeLevel().then(res => {
                    this.levelList = res.data.data;
                })
            },

            getUnitList() {
                fetchUnitAll().then(res => {
                    this.unitList = res.data.data;
                })
            },

            //第一步
            stepOne() {
                this.$refs.form1.validate(res => {
                    if (!res) {
                        return;
                    }
                    let obj = this.deepClone(this.data1);
                    if (!this.validatenull(obj.area)) {
                        obj.province = obj.area[0];
                        obj.city = obj.area[1];
                    }

                    this.doSave(obj).then(res => {
                        if (!this.validatenull(res.data.data)) {
                            let userInfo = this.$store.getters.userInfo;
                            userInfo.unionId = res.data.data.id;
                            this.data1.id = userInfo.unionId;
                            this.data2.id = userInfo.unionId;
                            this.data3.id = userInfo.unionId;
                            this.data4.id = userInfo.unionId;
                            this.$store.commit('SET_USER_INFO', userInfo);
                        }
                        this.$message.success('保存成功');
                        this.active++;
                    })
                })
            },

            stepTwo() {
                this.$refs.form2.validate(res => {
                    if (!res) {
                        return;
                    }
                    this.doSave(this.data2).then(res => {
                        this.$message.success('保存成功');
                        this.active++;
                    })
                });
            },

            stepThree() {
                this.$refs.form3.validate(res => {
                    if (!res) {
                        return;
                    }
                    this.doSave(this.data3).then(res => {
                        this.$message.success('保存成功');
                        this.active++;
                    })
                });
            },

            stepFour() {
                this.$refs.form4.validate(res => {
                    if (!res) {
                        return;
                    }
                    let obj = this.deepClone(this.data4);
                    obj.speciality = `[${_.compact(obj.speciality).join(',')}]`;

                    this.doSave(obj).then(res => {
                        this.$message.success('保存成功');
                        this.$router.push('/personal/detail');
                    })
                });
            },

            doSave(obj) {
                let result = updateReferee;
                if (this.validatenull(obj.id)) {
                    result = addReferee
                }
                //添加之后、后台返回 refereeId 更新refereeId
                return result(obj)
            },

            changeLevelPhoto(res) {
                this.data4.levelPhotoPath = res;
            },

            changePhoto(res) {
                if (this.id === '-1') {
                    this.$set(this.data1, 'photo', res);
                } else {
                    this.$set(this.data1, 'photo', res.photo);
                }
            },

            frontChange(res) {
                this.$set(this.data1, 'idcardFacePath', res.path);

                if (res.idcardInfo.birth) {
                    let birthday = new moment(res.idcardInfo.birth, 'YYYYMMDD');
                    this.$set(this.data1, 'birthday', birthday);
                }
                if (res.idcardInfo.sex) {
                    this.$set(this.data1, 'sex', res.idcardInfo.sex === '男' ? 0 : 1);
                }
                if (res.idcardInfo.name) {
                    this.$set(this.data1, 'cnName', res.idcardInfo.name);
                }

                if (res.idcardInfo.num) {
                    this.$set(this.data1, 'idcard', res.idcardInfo.num);
                }

                if (res.idcardInfo.nationality) {
                    this.$set(this.data1, 'ethnicity', res.idcardInfo.nationality + '族');
                }

                if (res.idcardInfo.address) {
                    this.$set(this.data1, 'contactAddress', res.idcardInfo.address);
                }

            },

            backChange(res) {
                this.$set(this.data1, 'idcardBackPath', res.path);
            },

            getData() {
                fetchRefereeDetail(this.id).then(res => {
                    let obj = res.data.data || {};
                    this.data1 = { //           height
                        id: obj.id,
                        qq: obj.qq,
                        weight: obj.weight,
                        photo: obj.photo,
                        idcardFacePath: obj.idcardFacePath,
                        unitId: obj.unitId,
                        cnName: obj.cnName,
                        idcard: obj.idcard,
                        sex: obj.sex,
                        political: obj.political,
                        ethnicity: obj.ethnicity,
                        height: obj.height,
                        health: obj.health,
                        idcardBackPath: obj.idcardBackPath,
                        mobile: obj.mobile,
                        birthday: obj.birthday,
                        enSurname: obj.enSurname,
                        enName: obj.enName,
                        area: obj.area,
                        contactAddress: obj.contactAddress,
                    };
                    this.data2 = {
                        id: obj.id,
                        inaugurationUnit: obj.inaugurationUnit,
                        inaugurationUnitTel: obj.inaugurationUnitTel,
                        inaugurationUnitEmail: obj.inaugurationUnitEmail,
                        inaugurationUnitAddres: obj.inaugurationUnitAddres,
                        inaugurationUnitPasspot: obj.inaugurationUnitPasspot,
                    }
                    this.data3 = { //
                        id: obj.id,
                        education: obj.education,
                        language: obj.language,
                        languageLevel: obj.languageLevel,
                        technicalTitle: obj.langutechnicalTitleageLevel,
                    };
                    this.data4 = {
                        id: obj.id,
                        prejudgeda: obj.prejudgeda,
                        level: obj.level,
                        experience: obj.experience,
                        levelPhotoPath: obj.levelPhotoPath,
                        speciality: obj.speciality,
                    };


                    this.data1.area = [this.data1.province, this.data1.city];
                    let spec = [];
                    if (!this.validatenull(this.data4.speciality)) {
                        this.data4.speciality = this.data4.speciality.replace(/\s/g, '');
                        spec = this.data4.speciality.substring(1, this.data4.speciality.length - 1).split(',');
                    }
                    this.$set(this.data4, 'speciality', spec);
                });
            },

            getUserInfo() {
                fetchUserInfo().then(res => {
                    this.userInfo = res.data.data;
                    this.data1.mobile = this.userInfo.mobile;
                    this.data1.idcard = this.userInfo.idcard;
                })
            }
        },

        mounted() {
            this.id = this.$store.getters.userInfo.unionId;
            this.getUserInfo();
            this.getUnitList();
            this.getSpeciality();
            this.getRefereeLevelList();
            if (Number(this.id) != -1) {
                this.getData();
            }
        }
    }
</script>

<style lang="less">
    .img-tips {
        line-height: 23px;

        dl {
            list-style: circle;
        }

        dt {
            font-weight: bold;
            margin-top: 10px;
        }
    }
</style>
