<template>
  <div>
    <el-row :gutter="20" class="search-box">
      <el-col :span="4" v-if="userInfo.unitType === 'ALL'">
        <el-select
          v-model="listQuery.unitId"
          placeholder="请选择单位"
          clearable
          filterable
          @change="getList(1)"
        >
          <el-option
            v-for="(item, index) in unitList"
            :key="index"
            :value="item.id"
            :label="item.cnName"
          ></el-option>
        </el-select>
      </el-col>

      <el-col :span="4">
        <el-select
          v-model="listQuery.activated"
          placeholder="请选择状态"
          clearable
          filterable
          @change="getList(1)"
        >
          <el-option
            v-for="(item, index) in USER_ACTIVE"
            :key="index"
            :value="item.value"
            :label="item.name"
          ></el-option>
        </el-select>
      </el-col>

      <el-col :span="4">
        <el-select
          v-model="listQuery.binDing"
          placeholder="是否绑定账户"
          clearable
          filterable
          @change="getList(1)"
        >
          <el-option :value="true" label="是"></el-option>
          <el-option :value="false" label="否"></el-option>
        </el-select>
      </el-col>

      <el-col :span="4">
        <el-select
          v-model="listQuery.authority"
          placeholder="角色"
          clearable
          filterable
          @change="getList(1)"
        >
          <el-option
            v-for="(item, index) in roleList"
            :key="index"
            :value="item.name"
            :label="item.display"
          ></el-option>
        </el-select>
      </el-col>

      <el-col :span="4">
        <el-input v-model="listQuery.mobile" placeholder="手机号码" @change="getList(1)"></el-input>
      </el-col>

      <el-col :span="4">
        <el-input v-model="listQuery.userName" placeholder="用户名" @change="getList(1)"></el-input>
      </el-col>

      <el-col :span="4" class="pull-right text-r">
        <el-button type="primary" @click="getList(1)">查询</el-button>
      </el-col>
    </el-row>

    <div>
      <el-button
        type="danger"
        @click="changeStatus(ids, false)"
        v-auth="per.system_user_unit_active"
        >关闭</el-button
      >
      <el-button
        type="success"
        @click="changeStatus(ids, true)"
        v-auth="per.system_user_unit_active"
        >激活</el-button
      >

      <el-button type="primary" @click="showAddUser" v-auth="per.system_user_unit_add"
        >新增
      </el-button>
    </div>

    <el-table
      border
      :data="dataSource"
      class="page-top-space"
      row-class-name="table-row"
      @selection-change="selectChange"
    >
      <el-table-column type="selection"> </el-table-column>

      <el-table-column type="index" label="序号"> </el-table-column>

      <el-table-column prop="unitName" label="注册所属省市"> </el-table-column>

      <el-table-column prop="username" label="用户名"> </el-table-column>

      <el-table-column prop="mobile" label="手机号"> </el-table-column>

      <el-table-column prop="email" label="邮箱"> </el-table-column>

      <el-table-column prop="activated" label="激活状态">
        <template slot-scope="scope">
          <MyBadge :list="USER_ACTIVE" :target="scope.row.activated"></MyBadge>
        </template>
      </el-table-column>

      <el-table-column label="操作">
        <template slot-scope="scope">
          <span
            class="option option-primary"
            @click="showEditUser(scope.row)"
            v-auth="per.system_user_unit_update"
            >编辑</span
          >
          <span
            class="option option-danger"
            v-if="scope.row.activated"
            @click="changeStatus([scope.row.id], false)"
            v-auth="per.system_user_unit_active"
            >关闭</span
          >
          <span
            class="option option-primary"
            v-else
            @click="changeStatus([scope.row.id], true)"
            v-auth="per.system_user_unit_active"
            >激活</span
          >
        </template>
      </el-table-column>
    </el-table>

    <el-pagination
      class="page-top-space"
      background
      :total="total"
      :page-size="listQuery.pageSize"
      :current-page.sync="listQuery.pageNo"
      @current-change="getList"
    >
    </el-pagination>

    <EditModal
      :ref="MODAL_KEY.EDIT_MODAL"
      :modal-data="modalData"
      :type="modalType"
      @submit="doSubmit"
      :unitList="unitList"
    ></EditModal>
  </div>
</template>

<script>
import {fetchUserPage, updateUser, updateUserStatus} from '@/api/user';
import {fetchUnitAll} from '@/api/unit';
import {USER_TYPE, USER_ACTIVE, ROLE} from '@/const/index';
import EditModal from '../component/EditModal';
import {fetchRoleList} from '@/api/permission';

export default {
  components: {EditModal},
  data() {
    let userInfo = this.$store.getters.userInfo;
    return {
      userInfo: userInfo,
      MODAL_KEY: {
        EDIT_MODAL: 'EDIT_MODAL'
      },
      USER_ACTIVE: USER_ACTIVE,
      ROLE: ROLE,
      USER_TYPE: USER_TYPE,
      activeName: '',
      modalData: {},
      ids: [],
      modalType: '',
      dataSource: [],
      unitList: [],
      listQuery: {
        pageNo: 1,
        pageSize: 10,
        type: USER_TYPE.UNIT,
        unitId: userInfo.unitType === 'ALL' ? '' : userInfo.unitId
      },
      roleList: [],
      total: 0
    };
  },

  methods: {
    getUnitList() {
      fetchUnitAll().then((res) => {
        this.unitList = res.data.data;
      });
    },

    //选择table 分组查询学生成绩
    selectChange(selection) {
      this.ids = [];
      selection.map((item) => {
        this.ids.push(item.id);
      });
    },

    getRoleList() {
      fetchRoleList({type: '0', pageNo: 1, pageSize: 10000}).then((res) => {
        this.roleList = res.data.data.records;
      });
    },

    changeStatus(ids, type) {
      if (this.validatenull(ids)) {
        this.$message.error('请选择先用户再操作！');
        return;
      }

      let list = [];
      ids &&
        ids.map((item) => {
          list.push({id: item, activated: type});
        });

      updateUserStatus(list).then((res) => {
        this.$message.success('操作成功');
        this.getList();
      });
    },
    getList(current) {
      if (this.validatenull(current)) {
        this.listQuery.pageNo = current;
      }

      if (this.listQuery.type === USER_TYPE.UNIT) {
        this.listQuery.refereeIdcard = '';
        this.listQuery.refereeName = '';
      }

      this.listQuery.types = this.listQuery.type;
      fetchUserPage(this.listQuery).then((res) => {
        this.dataSource = res.data.data.results;
        this.total = res.data.data.total_record;
      });
    },
    showAddUser() {
      this.modalData = {
        activated: false,
        type: this.listQuery.type,
        id: '',
        email: '',
        mobile: '',
        password: '',
        username: ''
      };
      this.modalType = 'add';
      this.$refs[this.MODAL_KEY.EDIT_MODAL].showModal();
    },

    showEditUser(data) {
      this.modalData = {
        id: data.id,
        activated: data.activated,
        authority: data.authority,
        email: data.email,
        mobile: data.mobile,
        username: data.username,
        unitId: data.unitId,
        type: this.listQuery.type,
        remark: data.remark
      };
      this.modalType = 'edit';
      this.$refs[this.MODAL_KEY.EDIT_MODAL].showModal();
    },

    doSubmit(data) {
      data.type = this.listQuery.type;
      switch (data.type) {
        case USER_TYPE.PERSONAL:
          data.authority = ROLE.personal;
          break;

        case USER_TYPE.RECORD:
          data.authority = ROLE.record;
          break;
        default:
      }
      updateUser(data).then((res) => {
        this.$message.success('操作成功');
        this.getList();
        this.$refs[this.MODAL_KEY.EDIT_MODAL].closeModal();
      });
    }
  },

  mounted() {
    this.getList();
    this.getUnitList();
    this.getRoleList();
  }
};
</script>
