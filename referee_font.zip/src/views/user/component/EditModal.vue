<template>
    <el-dialog
            :title="(type==='edit'?'编辑': '新增') + (modalData.type === USER_TYPE.UNIT? '单位': (modalData.type === USER_TYPE.PERSONAL?'个人':'选录'))+'用户'"
            :close-on-click-modal="isClickModalClose"
            :visible.sync="isShow"
            :width="defaultWidth"
            @close="closeModal"
    >
        <el-form :ref="formName" :model="modalData" :rules="ruleValidate" label-width="120px">
            <el-form-item label="单位" prop="unitId" v-if="modalData.type === USER_TYPE.UNIT && $store.getters.userInfo.unitType === 'ALL'">
                <el-select v-model='modalData.unitId' placeholder="请选择单位" clearable filterable>
                    <el-option v-for="(item,index) in unitList" :key="index" :value="item.id"
                               :label="item.cnName"></el-option>
                </el-select>
            </el-form-item>

            <el-form-item label="用户名：" prop="username">
                <el-input v-model="modalData.username" placeholder="请输入用户名" :maxLength="32"></el-input>
            </el-form-item>

            <el-form-item label="手机号：" prop="mobile">
                <el-input v-model="modalData.mobile" placeholder="请输入联系人手机号" :maxLength="11"></el-input>
            </el-form-item>

            <el-form-item label="密码：" prop="password"
                          :rules="{required: type === 'add',message: '密码不能为空',trigger: 'blur'}">
                <el-input v-model="modalData.password" placeholder="请输入密码" :maxLength="20"></el-input>
            </el-form-item>

            <el-form-item label="邮箱：" prop="email">
                <el-input v-model="modalData.email" placeholder="请输入联系人姓名" :maxLength="50"></el-input>
            </el-form-item>

            <el-form-item label="角色：" prop="authority" v-if="modalData.type === USER_TYPE.UNIT">
                <el-select v-model="modalData.authority" placeholder="请选择角色">
                    <el-option v-for="(item,index) in roleList" :key="index" :value="item.name"
                               :label="item.display"></el-option>
                </el-select>
            </el-form-item>

            <el-form-item label="是否激活：" prop="activated">
                <el-checkbox v-model="modalData.activated">激活</el-checkbox>
            </el-form-item>

            <el-form-item label="田协账号：" prop="remark" v-if="modalData.type === USER_TYPE.UNIT && $store.getters.userInfo.unitType === 'ALL'">
                <el-checkbox v-model="modalData.remark" false-label="" true-label="ALL">是</el-checkbox>
            </el-form-item>
        </el-form>

        <div slot="footer">
            <el-button @click="closeModal">
                取消
            </el-button>

            <el-button @click="submit" type="primary">
                确定
            </el-button>
        </div>
    </el-dialog>
</template>

<script>
    import modalMixin from '@/mixins/modalMixin';
    import {ROLE, USER_TYPE} from '@/const/index'
    import {fetchRoleList} from '@/api/permission';

    export default {
        mixins: [modalMixin],
        props: ['modalData', 'type', 'unitList'],
        data() {
            return {
                ROLE: ROLE,
                USER_TYPE: USER_TYPE,
                imgUrl: this.imgUrl,
                formName: 'form',
                roleList: [],
                ruleValidate: {
                    authority: {
                        required: true,
                        message: '角色不能为空',
                        trigger: 'change'
                    },
                    unitId: [
                        {
                            required: true,
                            message: '用户名不能为空！',
                            trigger: 'blur'
                        }
                    ],
                    username: [
                        {
                            required: true,
                            message: '用户名不能为空！',
                            trigger: 'blur'
                        }
                    ],
                    mobile: [
                        {
                            required: true,
                            message: '手机号不能为空！',
                            trigger: 'blur'
                        }
                    ],
                }
            };
        },
        methods: {
            getRoleList() {
                fetchRoleList({type: '0', pageNo: 1, pageSize: 10000}).then(res => {
                    this.roleList = res.data.data.records;
                })
            },

            submit() {
                if (this.type === 'detail') {
                    this.closeModal();
                    return;
                }
                this.validateForm().then(res => {
                    this.$emit('submit', this.modalData);
                })
            },
        },

        mounted() {
            this.getRoleList();
        }

    }
</script>
