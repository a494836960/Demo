<template>
    <!-- 新增模态框 -->
    <el-dialog
            :visible.sync="isShow"
            :width="defaultWidth"
            :close-on-click-modal="isClickModalClose"
            @close="closeModal"
            :title="`角色${this.modalType=='edit'?'编辑':'添加'}`"
    >
        <el-form :ref="formName" :model="modalData" :rules="rules" label-width="80px">

            <el-form-item label="角色名称" prop="display">
                <el-input v-model="modalData.display" placeholder="请填写角色名称" :maxLength="32"></el-input>
            </el-form-item>

            <el-form-item label="角色代码" prop="name" v-if="this.modalType=='edit'">
                <el-input v-model="modalData.name" placeholder="请填写角色代码" disabled :maxLength="32"></el-input>
            </el-form-item>

        </el-form>

        <el-divider content-position="left">权限分配</el-divider>
        <el-tree :data="treeData" ref="tree" node-key="resourcesId" show-checkbox
                 :props="{label:'name',children: 'node'}"></el-tree>
        <div slot="footer">
            <el-button @click="closeModal">取消</el-button>
            <el-button type="primary" @click="submit">确定</el-button>
        </div>
    </el-dialog>
</template>

<script>
    import modalMixin from '@/mixins/modalMixin';
    import {fetchRolePermissionById, fetchCurPermission, fetchResourceList} from '@/api/permission'
    import {ROLE} from '@/const/index';

    export default {
        mixins: [modalMixin],
        props: ['type', 'modalData', 'roleLists', 'modalType'],
        data() {
            return {
                baseData: [], //后台原数据
                resourceArr: [],
                treeData: [],
                curData: [],
                rules: {
                    display: {
                        required: true,
                        message: '角色名称不能为空',
                        trigger: 'blur'
                    }
                },
                formName: 'formRef'
            }
        },

        mounted() {
            this.getUserMenu();
        },
        methods: {
            showModal(roleId) {
                this.isShow = true;
                this.resourceArr = [];
                this.$refs.tree && this.$refs.tree.setCheckedKeys([]);
                if (!this.validatenull(roleId)) {
                    this.getCurRoleResource(roleId);
                }
            },

            //获取当前角色的权限
            getCurRoleResource(id) {
                fetchRolePermissionById({authorityId: id, resultType: 0}).then(res => {
                    res.data.data && res.data.data.map(item => {
                        this.resourceArr.push(item.resourcesId);
                    });
                    this.$nextTick(() => {
                        this.$refs.tree.setCheckedKeys(this.resourceArr);
                    })
                });
            },

            submit() {
                let resultMenu = [];
                resultMenu = this.$refs.tree.getCheckedKeys();
                if (resultMenu.length === 0) {
                    this.$message.error('权限不能为空');
                    return;
                }
                this.validateForm().then(res => {
                    this.modalData.resoucesList = resultMenu;
                    this.$emit('submit', this.modalData);
                })
            },

            getUserMenu() {// 如果当前用户是系统管理员， 查询所有的权限
                let result = fetchCurPermission;
                if (this.$store.getters.roles[0] === ROLE.system) {
                    result = fetchResourceList;
                }
                result().then(res => {
                    this.treeData = res.data.data;
                })
            },
        }
    }
</script>
