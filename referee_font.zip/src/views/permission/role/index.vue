<template>
    <div>
            <div class="text-r">
                <el-button type="primary" @click="addRole">
                    添加
                </el-button>
            </div>

            <el-table class="page-top-space" border :data="dataSource">
                <el-table-column prop="display" label="角色名称"></el-table-column>
                <el-table-column prop="name" label="角色代码"></el-table-column>
                <el-table-column prop="operation" label="操作">
                    <template slot-scope="scope">
                        <span class="option option-primary" @click="showEdit(scope.row)">编辑</span>
                        <span class="option option-danger" @click="showDel(scope.row.authority_id);">删除</span>
                    </template>
                </el-table-column>
            </el-table>

            <el-pagination
                    class="page-top-space"
                    background
                    :total="Number(total)"
                    :page-size="listQuery.size"
                    :current-page.sync="listQuery.current"
                    @current-change="getList"
            >
            </el-pagination>
        <EditRoleModal :ref="MODAL_KEY.EDIT_ROLE_MODAL" :modalData="formValidateData" :modalType="modalType"
                       @submit="operationRole"></EditRoleModal>
    </div>

</template>

<script>
    import {fetchRoleList, updateRole, delRole, addRole} from '@/api/permission';
    import EditRoleModal from './component/EditRoleModal';


    export default {

        data() {
            return {
                MODAL_KEY: {
                    EDIT_ROLE_MODAL: 'EDIT_ROLE_MODAL'
                },
                treeData: [],
                modalType: '',
                listQuery: {
                    current: 1,
                    size: 15,
                    username: ''
                },
                total: 0,
                formValidateData: {},
                dataSource: []
            }
        },
        components: {
            EditRoleModal: EditRoleModal
        },

        mounted() {
            this.getList();
        },

        methods: {
            addRole() {
                this.formValidateData = {};
                this.modalType = 'add'
                this.$refs[this.MODAL_KEY.EDIT_ROLE_MODAL].showModal();
            },

            showDel(id) {
                this.$confirm('确认要删除吗','提示',{type: 'warning'}).then(res=>{
                    this.doDel(id)
                })
            },

            doDel(id) {
                delRole({id}).then(res => {
                    this.$message({
                        message: "删除成功",
                        type: 'success'
                    });
                    this.validateCurrentDataLen([id], this.dataSource, this);
                    this.getList();
                })
            },

            showEdit(data) {
                this.formValidateData = this.deepClone(data) || {};
                this.modalType = 'edit';
                this.$refs[this.MODAL_KEY.EDIT_ROLE_MODAL].showModal(this.formValidateData.authority_id);
            },

            getList(current) {
                if (!this.validatenull(current)) {
                    this.listQuery.current = current;
                }
                fetchRoleList(this.listQuery).then(res => {
                    this.dataSource = res.data.data.records;
                    this.total = res.data.data.total;
                });
            },

            operationRole(params) {
                let msg = '';
                if (!this.validatenull(params.authority_id)) {
                    msg = "编辑成功";
                } else {
                    msg = '添加成功';
                }

                updateRole(params).then(res => {
                    this.$message({
                        message: msg,
                        type: 'success'
                    });
                    this.$refs[this.MODAL_KEY.EDIT_ROLE_MODAL].closeModal();
                    this.getList();
                })
            }
        },
    }
</script>

<style scoped>

</style>
