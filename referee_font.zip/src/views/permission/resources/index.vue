<template>
    <div>
        <div class="text-r">
            <el-button type="primary" @click="showAdd">
                添加
            </el-button>
        </div>

        <div>
            <el-table
                    border
                    :tree-props="{children: 'node', hasChildren: 'hasChildren'}"
                    :data="dataSource"
                    :expand-row-keys="['-1']"
                    row-class-name="table-row"
                    row-key="resourcesId">
                <el-table-column label="名称" prop="name"></el-table-column>
                <el-table-column label="标识" prop="permission"></el-table-column>
                <el-table-column label="操作" prop="operation">
                    <template slot-scope="scope">
                        <span class="option option-primary" @click="showAdd(scope.row)" v-auth="per.permission_resource_add">添加</span>
                        <span v-if="scope.row.resourcesId !== '-1'">
                        <span class="option option-primary" @click="showEdit(scope.row)" v-auth="per.permission_resource_update">编辑</span>
                        <span class="option option-danger" @click="showDel(scope.row)" v-auth="per.permission_resource_del">删除</span>
                        <i class="el-icon-caret-top move-icon" @click="doMove('up',scope.row.resourcesId)" v-auth="per.permission_resource_move"></i>
                        <i class="el-icon-caret-bottom move-icon" @click="doMove('down',scope.row.resourcesId)" v-auth="per.permission_resource_move"></i>
                        </span>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <EditResourceModal :ref="MODAL_KEY.EDIT_RESOURCE_MODAL" :modalData="formValidateData" :modalType="modalType"
                           :resources="dataSource"
                           @submit="operationSource"></EditResourceModal>
    </div>

</template>

<script>
    import {
        fetchResourceList,
        addResource,
        updateResource,
        delResource,
        moveDownResource,
        moveUpResource
    } from '@/api/permission';
    import EditResourceModal from './component/EditResourceModal';

    export default {
        data() {
            return {
                MODAL_KEY: {
                    EDIT_RESOURCE_MODAL: 'EDIT_RESOURCE_MODAL'
                },
                treeData: [],
                modalType: '',
                listQuery: {
                    current: 1,
                    size: 15,
                    username: ''
                },
                total: 0,
                formValidateData: {},
                dataSource: []
            }
        },
        components: {
            EditResourceModal: EditResourceModal
        },

        mounted() {
            this.getList();
        },

        methods: {
            showAdd(data) {
                this.formValidateData = {
                    type: 0,
                    parentId: '',
                };
                if (data) {
                    this.formValidateData.parentId = data.resourcesId
                } else {
                    this.formValidateData = {}
                }

                this.modalType = 'add'
                this.$refs[this.MODAL_KEY.EDIT_RESOURCE_MODAL].showModal();
            },

            showDel(data) {
                this.$confirm('确认要删除吗', '提示', {type: 'warning'}).then(res => {
                    this.doDel(data.resourcesId)
                })
            },

            doDel(id) {
                delResource({id}).then(res => {
                    this.$message({
                        message: "删除成功",
                        type: 'success'
                    });
                    this.validateCurrentDataLen([id], this.dataSource, this);
                    this.getList();
                })
            },

            showEdit(data) {
                this.formValidateData = this.deepClone(data) || {};
                this.modalType = 'edit';
                this.$refs[this.MODAL_KEY.EDIT_RESOURCE_MODAL].showModal();
            },

            getList(current) {
                fetchResourceList(this.listQuery).then(res => {
                    this.dataSource = [{parentId: 0, resourcesId: '-1', node: res.data.data, name: '国家级裁判员系统'}];
                });
            },

            doMove(type, id) {
                let result;
                if (type === 'down') {
                    result = moveDownResource
                } else {
                    result = moveUpResource
                }
                result(id).then(res => {
                    this.$message.success('操作成功');
                    this.getList();
                })
            },

            operationSource(params) {
                let result;
                let msg = '';
                if (!this.validatenull(params.resourcesId)) {
                    msg = "编辑成功";
                    result = updateResource;
                } else {
                    msg = '添加成功';
                    result = addResource;
                }

                result(params).then(res => {
                    this.$message({
                        message: msg,
                        type: 'success'
                    });
                    this.$refs[this.MODAL_KEY.EDIT_RESOURCE_MODAL].closeModal();
                    this.getList();
                })
            }
        },
    }
</script>

<style scoped>

</style>
