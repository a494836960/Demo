<template>
    <!-- 新增模态框 -->
    <el-dialog
            :visible.sync="isShow"
            :width="defaultWidth"
            :close-on-click-modal="isClickModalClose"
            @close="closeModal"
            :title="`${this.modalType=='edit'?'编辑':'添加'}资源`"
    >
        <el-form :ref="formName" :model="modalData" :rules="rules" label-width="80px">

            <el-form-item label="类型" prop="type">
                <el-radio-group v-model="modalData.type">
                    <el-radio :label="0">菜单</el-radio>
                    <el-radio :label="1">按钮</el-radio>
                </el-radio-group>
            </el-form-item>

            <el-form-item label="资源名称" prop="name">
                <el-input v-model="modalData.name" placeholder="请填写资源名称" :maxLength="32"></el-input>
            </el-form-item>

            <el-form-item label="资源标识" prop="permission">
                <el-input v-model="modalData.permission" placeholder="请填写资源标识" :maxLength="32"></el-input>
            </el-form-item>

            <el-form-item label="父级" prop="parentId">
                <el-cascader v-model="modalData.parentId" :options="resources" placeholder="请选择父级"
                             :props="{label:'name',children: 'node',value:'resourcesId',checkStrictly: true}"></el-cascader>
            </el-form-item>
        </el-form>

        <div slot="footer">
            <el-button @click="closeModal">取消</el-button>
            <el-button type="primary" @click="submit">确定</el-button>
        </div>
    </el-dialog>
</template>

<script>
    import modalMixin from '@/mixins/modalMixin';
    import {fetchRolePermissionById, fetchCurPermission} from '@/api/permission'

    export default {
        mixins: [modalMixin],
        props: ['modalData', 'resources', 'modalType'],
        data() {
            return {
                baseData: [], //后台原数据
                resourceArr: [],
                treeData: [],
                curData: [],
                rules: { // permission parentId name type
                    permission: {
                        required: true,
                        message: '请输入资源标识',
                        trigger: 'blur'
                    },
                    parentId: {
                        required: true,
                        message: '请选择父节点',
                        trigger: 'change',
                    },
                    name: {
                        required: true,
                        message: '请资源名称',
                        trigger: 'blur',
                    },
                    type: {
                        required: true,
                        message: '请选择资源类型',
                        trigger: 'change',
                    }
                },
                formName: 'formRef'
            }
        },

        methods: {
            showModal() {
                this.isShow = true;
            },

            submit() {
                this.validateForm().then(res => {
                    let obj = this.deepClone(this.modalData);
                    obj.parentId = typeof obj.parentId === 'string' ? obj.parentId : obj.parentId[obj.parentId.length - 1];
                    obj.applicationId = 1;
                    obj.module = -1;
                    obj.level = obj.parentId.length - 1;
                    this.$emit('submit', obj);
                })
            },
        }
    }
</script>
