<template>
    <div>
        <el-divider content-position="left">时间设置</el-divider>
        <el-form ref="form" label-width="135px">
            <el-form-item label="注册开放时间：">
                <el-date-picker
                        v-model="data.reg"
                        value-format="timestamp"
                        type="datetimerange"
                        range-separator="至"
                        start-placeholder="开始日期"
                        end-placeholder="结束日期">
                </el-date-picker>
            </el-form-item>

            <el-form-item label="单位审核开放时间：">
                <el-date-picker
                        v-model="data.unit"
                        value-format="timestamp"
                        type="datetimerange"
                        range-separator="至"
                        start-placeholder="开始日期"
                        end-placeholder="结束日期">
                </el-date-picker>
            </el-form-item>

            <el-form-item label="田协审核开放时间：">
                <el-date-picker
                        v-model="data.center"
                        type="datetimerange"
                        value-format="timestamp"
                        range-separator="至"
                        start-placeholder="开始日期"
                        end-placeholder="结束日期">
                </el-date-picker>
            </el-form-item>

            <el-form-item>
                <el-button @click="doSubmit" type="primary" v-auth="per.system_setting_update">保存</el-button>
            </el-form-item>
        </el-form>
    </div>
</template>

<script>
    import {fetchSetting, updateSetting} from '@/api/system';

    export default {
        data() {
            return {
                data: {
                    reg: [],
                    unit: [],
                    center: [],
                }
            }
        },
        methods: {
            getSetting() {
                fetchSetting().then(res => {
                    let date = res.data.data;
                    this.data = {
                        reg: [date.registerBeginTime, date.registerEndTime],
                        unit: [date.unitBeginAuditTime, date.unitEndAuditTime],
                        center: [date.centerBeginAuditTime, date.centerEndAuditTime],
                    }
                })
            },

            doSubmit() {
                let params = {
                    centerEndAuditTime: this.data.center[1],
                    centerBeginAuditTime: this.data.center[0],
                    unitEndAuditTime: this.data.unit[1],
                    unitBeginAuditTime: this.data.unit[0],
                    registerBeginTime: this.data.reg[0],
                    registerEndTime: this.data.reg[1],
                };
                updateSetting(params).then(res => {
                    this.$message.success('修改成功');
                })
            },
        },

        mounted() {
            this.getSetting();
        }
    }
</script>
