<template>
    <el-dialog
            :title="type==='edit'?'编辑岗位': '新增岗位'"
            :close-on-click-modal="isClickModalClose"
            :visible.sync="isShow"
            :width="defaultWidth"
            @close="closeModal"
    >
        <el-form :ref="formName" :model="modalData" :rules="ruleValidate" label-width="90px">
            <el-form-item label="岗位名称：" prop="name">
                <el-input v-model="modalData.name" placeholder="请输入岗位名称" :maxLength="32"></el-input>
            </el-form-item>

            <el-form-item label="岗位特长：" prop="specialityCode">
                <el-select v-model="modalData.specialityCode" placeholder="请选择岗位特长" :maxLength="32" :multiple-limit="5" multiple>
                    <el-option v-for="(item, index) in specialityList" :key="index" :value="item.code" :label="item.name"></el-option>
                </el-select>
            </el-form-item>

            <el-form-item label="岗位描述：" prop="posDescribe">
                <el-input type="textarea" autosize v-model="modalData.posDescribe" placeholder="请输入岗位描述" :maxLength="50"></el-input>
            </el-form-item>
        </el-form>

        <div slot="footer">
            <el-button @click="closeModal">
                取消
            </el-button>

            <el-button @click="submit" type="primary">
                确定
            </el-button>
        </div>
    </el-dialog>
</template>

<script>
    import modalMixin from '@/mixins/modalMixin';

    export default {
        mixins: [modalMixin],
        props: ['modalData', 'type', 'specialityList'],
        data() {
            return {
                formName: 'form',
                ruleValidate: {
                    name: [
                        {
                            required: true,
                            type: 'string',
                            message: '岗位名称不能为空！',
                            trigger: 'blur'
                        }
                    ],
                }
            };
        },
        methods: {
            submit() {
                this.validateForm().then(res => {
                    let obj = this.deepClone(this.modalData);
                    obj.specialityCode = obj.specialityCode.join(',')
                    this.$emit('submit', obj);
                })
            },
        },

    }
</script>
