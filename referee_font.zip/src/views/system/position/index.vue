<template>
  <div>
    <el-row :gutter="20">
      <el-col :span="4">
        <el-input v-model="listQuery.name" placeholder="岗位名称" @change="getList(1)" />
      </el-col>

      <el-col :span="4">
        <el-button type="primary" @click="getList(1)">查询</el-button>
      </el-col>

      <el-col :span="16" class="text-r">
        <el-button
          class="but"
          type="primary"
          @click="showAddPosition"
          v-auth="per.system_position_add"
          >新增
        </el-button>
      </el-col>
    </el-row>

    <el-table border :data="dataSource" class="page-top-space" row-class-name="table-row">
      <el-table-column type="index" label="序号"> </el-table-column>

      <el-table-column prop="name" label="岗位名称"> </el-table-column>

      <el-table-column prop="specialityName" label="岗位特长">
        <template slot-scope="scope">
          <span>{{ scope.row.specialityName.join('、') }}</span>
        </template>
      </el-table-column>

      <el-table-column prop="posDescribe" label="岗位描述"> </el-table-column>

      <el-table-column label="操作">
        <template slot-scope="scope">
          <span
            class="option option-primary"
            @click="showEditPosition(scope.row)"
            v-auth="per.system_position_update"
            >编辑</span
          >
          <span
            class="option option-danger"
            @click="doDelPosition(scope.row.id)"
            v-auth="per.system_position_delete"
            >删除</span
          >
          <i
            class="el-icon-caret-top move-icon"
            v-if="scope.row.posOrder != 1"
            v-auth="per.system_position_sort"
            @click="doMove('up', scope.row.id)"
          ></i>
          <i
            class="el-icon-caret-bottom move-icon"
            v-if="scope.row.posOrder != total"
            v-auth="per.system_position_sort"
            @click="doMove('down', scope.row.id)"
          ></i>
        </template>
      </el-table-column>
    </el-table>

    <el-pagination
      class="page-top-space"
      background
      :total="total"
      :page-size="listQuery.pageSize"
      :current-page.sync="listQuery.pageNo"
      @current-change="getList"
    >
    </el-pagination>

    <EditModal
      :ref="MODAL_KEY.EDIT_MODAL"
      :modal-data="modalData"
      :type="modalType"
      :specialityList="specialityList"
      @submit="doSubmit"
    ></EditModal>
  </div>
</template>

<script>
import {
  fetchPosition,
  delPosition,
  addPosition,
  updatePosition,
  moveUpPosition,
  moveDownPosition,
} from '@/api/position';
import {fetchSpeciality} from '@/api/common';
import EditModal from './component/EditModal';

export default {
  components: {EditModal},
  data() {
    return {
      MODAL_KEY: {
        EDIT_MODAL: 'EDIT_MODAL',
      },
      listQuery: {
        pageNo: 1,
        pageSize: 10,
      },
      total: 0,
      dataSource: [],
      specialityMap: {},
      specialityList: {},
      modalData: {},
      modalType: '',
    };
  },
  methods: {
    showAddPosition() {
      this.modalData = {code: ''};
      this.modalType = 'add';
      this.$refs[this.MODAL_KEY.EDIT_MODAL].showModal();
    },

    showEditPosition(data) {
      this.modalData = {
        code: data.code,
        name: data.name,
        specialityCode: data.specialityCode ? data.specialityCode.split(',') : [],
        id: data.id,
        posDescribe: data.posDescribe,
      };
      this.modalType = 'edit';
      this.$refs[this.MODAL_KEY.EDIT_MODAL].showModal();
    },

    doSubmit(data) {
      let result = addPosition;
      if (!this.validatenull(data.id)) {
        result = updatePosition;
      }

      result(data).then((res) => {
        this.$message.success('操作成功');
        this.getList();
        this.$refs[this.MODAL_KEY.EDIT_MODAL].closeModal();
      });
    },
    doDelPosition(id) {
      this.$confirm('确定要删除这个岗位吗', '提示', {
        type: 'warning',
      }).then((res) => {
        delPosition(id).then((res) => {
          this.$message.success('删除成功');
          this.getList();
        });
      });
    },
    getList(current) {
      if (!this.validatenull(current)) {
        this.listQuery.pageNo = current;
      }
      fetchPosition(this.listQuery).then((res) => {
        this.dataSource = res.data.data.results;
        this.dataSource.map((item) => {
          item.specialityName = item.specialityCode.split(',').map((code) => {
            return this.specialityMap[code];
          });
        });

        this.total = res.data.data.total_record;
      });
    },
    getSpeciality() {
      fetchSpeciality().then((res) => {
        this.specialityList = res.data.data;
        res.data.data &&
          res.data.data.map((item) => {
            this.specialityMap[item.code] = item.name;
          });
      });
      this.getList();
    },
    doMove(type, id) {
      let result = moveUpPosition;
      if (type === 'down') {
        result = moveDownPosition;
      }

      result(id).then((res) => {
        this.getList();
      });
    },
  },

  mounted() {
    this.getSpeciality();
  },
};
</script>

<style lang="less">
.move-icon {
  display: none;
  font-size: 16px;
  margin: 0 10px;
  background: #73d4f6;
  border-radius: 50%;
  color: #fff;
  cursor: pointer;
}

.table-row {
  &:hover {
    .move-icon {
      display: inline-block;
    }
  }
}
</style>
