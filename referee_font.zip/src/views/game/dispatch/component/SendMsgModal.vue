<template>
    <el-dialog
            title="发送短信"
            :close-on-click-modal="isClickModalClose"
            :visible.sync="isShow"
            :width="defaultWidth"
            @close="closeModal"
    >
        <div>
            <el-form ref="loginForm" :model="modalData" :rules="rules"
                     :hide-required-asterisk="true"
                     label-width="65px"
                     @keyup.enter.native="submit">
                <el-form-item prop="code" label="验证码：">
                    <el-row>
                        <el-col :span="10">
                            <el-input type="text" size="large" v-model="modalData.code"
                                      placeholder="请输入验证码">
                            </el-input>
                        </el-col>

                        <el-col :offset="2" :span="10">
                            <div @click="refreshCode">
                                <VerifyCode :pageid="modalData.pageId"></VerifyCode>
                            </div>
                        </el-col>
                    </el-row>
                </el-form-item>
            </el-form>
        </div>
        <div slot="footer">
            <el-button @click="closeModal">
                取消
            </el-button>

            <el-button @click="submit" type="primary">
                确定
            </el-button>
        </div>
    </el-dialog>
</template>

<script>
    import modalMixin from '@/mixins/modalMixin';
    import {generateUid} from '@/common/util';

    export default {
        mixins: [modalMixin],
        data() {
            return {
                modalData: {
                    code: '',
                    pageId: '',
                },
                rules: {
                    code: [{required: true, message: '请输入验证码', trigger: 'blur'}]
                }
            }
        },
        methods: {
            showModal() {
                this.isShow = true;
                this.$nextTick(() => {
                    this.refreshCode();
                });
            },
            refreshCode() {
                this.modalData.code = '';
                this.modalData.pageId = generateUid();
            },
            submit() {
                this.$emit('submit', this.modalData);
            },
        }
    }
</script>
