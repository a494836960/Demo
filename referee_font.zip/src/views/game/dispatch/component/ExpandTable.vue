<template>
    <el-table :data="rows" @selection-change="selectionChange">
        <el-table-column type="selection"></el-table-column>
        <el-table-column type="index"></el-table-column>
        <el-table-column prop="refereeName" label="姓名"></el-table-column>
        <el-table-column prop="sex" label="性别">
            <template slot-scope="scope">
                <MyBadge :list="GENDER" :target="scope.row.sex"></MyBadge>
            </template>
        </el-table-column>
        <el-table-column prop="birthday" label="出生日期">
            <template slot-scope="scope">
                {{scope.row.birthday|dateFormat(null,'YYYY-MM-DD')}}
            </template>
        </el-table-column>
        <el-table-column prop="unitName" label="注册所属省市"></el-table-column>
        <el-table-column prop="level" label="等级">
            <template slot-scope="scope">
                <MyBadge :list="LEVEL_TYPE" :target="scope.row.level"></MyBadge>
            </template>
        </el-table-column>
        <el-table-column prop="specialityName" label="特长">
            <template slot-scope="scope">
                {{scope.row.specialityName.join('、 ')}}
            </template>
        </el-table-column>
        <el-table-column prop="msgNum" label="通知状态">
            <template slot-scope="scope">
                <MyBadge :list="NOTIFY_STATUS" :target="scope.row.msgNum"></MyBadge>
            </template>
        </el-table-column>
        <el-table-column prop="designationNum" label="选派次数"></el-table-column>
        <el-table-column prop="confirmState" label="选派状态">
            <template slot-scope="scope">
                <MyBadge :list="CONFIRM_TYPE" :target="scope.row.confirmState"></MyBadge>
            </template>
        </el-table-column>
    </el-table>
</template>

<script>
    import {GENDER,LEVEL_TYPE,NOTIFY_STATUS,CONFIRM_TYPE} from '@/const/index'

    export default {
        props: ['rows', 'positionId'],
        data() {
            return {
                ids: [],
                CONFIRM_TYPE:CONFIRM_TYPE,
                GENDER: GENDER,
                LEVEL_TYPE: LEVEL_TYPE,
                NOTIFY_STATUS:NOTIFY_STATUS,
            };
        },

        methods: {
            selectionChange(selection) {
                this.ids = [];
                selection.map(item => {
                    this.ids.push(item.id);
                });

                this.$emit('selection-change', this.positionId, this.ids);
            }
        }
    }
</script>
