<template>
    <el-dialog
            title="选择岗位"
            :close-on-click-modal="isClickModalClose"
            :visible.sync="isShow"
            :width="defaultWidth"
            @close="closeModal"
    >
        <div>
            <div>点击标签选择岗位（可多选）：</div>
            <div class="position-content">
                <el-tag class="tag-item"
                        v-for="item in positions"
                        @click="clickTag(item)"
                        :key="item.id"
                        type="warning"
                        :effect="item.active?'dark':'plain'">
                    {{item.name}}
                </el-tag>
            </div>
        </div>
        <div slot="footer">
            <el-button @click="closeModal">
                取消
            </el-button>

            <el-button @click="submit" type="primary">
                确定
            </el-button>
        </div>
    </el-dialog>
</template>

<script>
    import modalMixin from '@/mixins/modalMixin';
    import {fetchPosition} from '@/api/position';

    export default {
        mixins: [modalMixin],
        props: ['gameId'],
        data() {
            return {
                formName: 'form',
                positions: [],
                ids: [],
                listQuery: {
                    pageNo: 1,
                    pageSize: 100
                }
            };
        },
        methods: {
            showModal() {
                this.ids = [];
                this.positions && this.positions.map(item => {
                    this.$set(item, 'active', false)
                })
                this.isShow = true;
            },

            submit() {
                if (this.ids.length <= 0) {
                    this.$message.error('请选择要添加的岗位');
                    return;
                }
                this.$emit('submit', this.ids);
            },

            //查询所有的岗位
            getPosition() {
                fetchPosition(this.listQuery).then(res => {
                    this.positions = res.data.data.results
                })
            },

            clickTag(item) {
                if (item.active) {
                    this.$set(item, 'active', false)
                    let index = this.ids.indexOf(item.id);
                    this.ids.splice(index, 1);
                } else {
                    this.$set(item, 'active', true)
                    this.ids.push(item.id);
                }
            }
        },

        mounted() {
            this.getPosition();
        }

    }
</script>

<style lang="less" scoped>
    .position-content {
        padding: 20px;
        margin-top: 10px;
        border: 1px solid #e1e1e1;
        border-radius: 5px;

        .tag-item {
            margin-right: 10px;
            margin-bottom: 10px;
            cursor: pointer;
        }
    }
</style>
