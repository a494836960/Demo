<template>
    <div>
        <el-alert
                v-if="baseInfo.confirmState === CONFIRM_TYPE_CODE.CONFIRM"
                title="当前赛事已确认选派，无法进行添加或移除操作！"
                type="warning"
                :closable="false">
        </el-alert>

        <div class="select-title">
            <span>{{baseInfo.gameNameCHN}}</span>
            <el-button class="float-r" type="info" @click="()=>{this.$router.go(-1)}">返回</el-button>
        </div>

        <div>
            <el-button type="primary" :disabled="baseInfo.confirmState === CONFIRM_TYPE_CODE.CONFIRM"
                       v-auth="per.game_dispatch_position_add"
                       @click="showAddPosition">添加岗位
            </el-button>
            <el-button type="danger" :disabled="baseInfo.confirmState === CONFIRM_TYPE_CODE.CONFIRM"
                       v-auth="per.game_dispatch_position_del"
                       @click="doDelPosition">移除岗位
            </el-button>
            <el-button type="danger" :disabled="baseInfo.confirmState === CONFIRM_TYPE_CODE.CONFIRM"
                       v-auth="per.game_dispatch_referee_del"
                       @click="doDelReferee">移除裁判员
            </el-button>

            <el-button type="info" @click="sendMsg" v-auth="per.game_dispatch_send_msg">发送短信通知</el-button>
            <el-button type="primary" v-if="baseInfo.confirmState === CONFIRM_TYPE_CODE.UNCONFIRM" @click="doConfirm(1)" v-auth="per.game_dispatch_confirm">
                一键确认
            </el-button>
            <el-button type="danger" v-else @click="doConfirm(0)" v-auth="per.game_dispatch_confirm">取消确认</el-button>
            <el-button type="primary" @click="doExport" v-auth="per.game_dispatch_referee_export">导出裁判选派名单</el-button>
        </div>

        <el-table border :data="dataSource" class="page-top-space"
                  @selection-change="selectionChange">
            <el-table-column type="expand">
                <template slot-scope="scope">
                    <ExpandTable :rows="scope.row.positionRefereeList" :positionId="scope.row.gamePositionId"
                                 @selection-change="changeIds"></ExpandTable>
                </template>
            </el-table-column>

            <el-table-column type="selection"></el-table-column>
            <el-table-column prop="name" label="岗位">
                <template slot-scope="scope">
                    <span class="option option-primary">{{scope.row.name}}</span>
                </template>
            </el-table-column>

            <el-table-column prop="operation" label="操作" width="330px">
                <template slot-scope="scope">
                    <el-button  :disabled="baseInfo.confirmState === CONFIRM_TYPE_CODE.CONFIRM" type="primary" v-auth="per.game_dispatch_referee_add" plain @click="showAddReferee(scope.row)">添加岗位裁判员</el-button>
                    <el-button :disabled="baseInfo.confirmState === CONFIRM_TYPE_CODE.CONFIRM" type="danger" v-auth="per.game_dispatch_referee_del" plain @click="doDelPositionReferee(scope.row.gamePositionId)">移除岗位裁判员</el-button>
                </template>
            </el-table-column>
        </el-table>
        <AddPositionModal :ref="MODAL_KEY.ADD_POSITION" @submit="doAddPosition"></AddPositionModal>
        <AddPositionRefereeModal :ref="MODAL_KEY.ADD_POSITION_REFEREE_MODAL"
                                 @submit="doAddReferee" :positionList="dataSource"
                                 :positionName="positionName"></AddPositionRefereeModal>
        <SendMsgModal :ref="MODAL_KEY.SEND_MSG_MODAL" @submit="doSendMsg"></SendMsgModal>
    </div>
</template>

<script>
    import {
        fetchGameReferee,
        gameAddPosition,
        gameDelPosition,
        gameDelReferee,
        gameConfirm,
        exportGame,
        delPositionReferee,
        addPositionReferee,
        sendMsg
    } from '@/api/game';
    import {fetchSpeciality} from '@/api/common'
    import ExpandTable from './component/ExpandTable';
    import AddPositionModal from './component/AddPositionModal';
    import {CONFIRM_TYPE_CODE} from '@/const/index';
    import {apiDownLoadFile} from "@/common/util";
    import AddPositionRefereeModal from './component/AddPositionRefereeModal';
    import SendMsgModal from './component/SendMsgModal';

    export default {
        components: {ExpandTable, AddPositionModal, AddPositionRefereeModal, SendMsgModal},
        data() {
            return {
                specialityMap: {},
                CONFIRM_TYPE_CODE: CONFIRM_TYPE_CODE,
                gameId: '',
                positionIds: [],
                refereeIds: [],
                refereeSelect: {},
                dataSource: [],
                baseInfo: {},
                curPosition: '',
                positionName: '',
                MODAL_KEY: {
                    ADD_POSITION: 'ADD_POSITION',
                    ADD_POSITION_REFEREE_MODAL: 'ADD_POSITION_REFEREE_MODAL',
                    SEND_MSG_MODAL: 'SEND_MSG_MODAL',
                }
            }
        },

        methods: {
            showAddPosition() {
                this.$refs[this.MODAL_KEY.ADD_POSITION].showModal();
            },

            getList() {
                fetchGameReferee({gameId: this.gameId}).then(res => {
                    this.baseInfo = res.data.data.results[0];
                    this.dataSource = this.baseInfo && this.baseInfo.positionList || [];
                    this.dataSource.map(postItem => {
                        postItem.positionRefereeList && postItem.positionRefereeList.map(item => {
                            item.specialityName = '';
                            item.speciality = item.speciality.replace(/\s/g, '');
                            item.specialityName = item.speciality.substring(1, item.speciality.length - 1).split(',').map(item => {
                                return this.specialityMap[item];
                            })
                        })
                    });

                })
            },

            //添加岗位
            doAddPosition(ids) {
                let params = [];
                ids.map(item => {
                    params.push({gameId: this.gameId, positionId: item})
                });

                gameAddPosition(params).then(res => {
                    this.$message.success('岗位添加成功');
                    this.getList();
                    this.$refs[this.MODAL_KEY.ADD_POSITION].closeModal();
                })
            },

            //移除岗位
            doDelPosition() {
                if (this.positionIds.length === 0) {
                    this.$message.error('请选择要移除的岗位');
                    return;
                }

                this.$confirm('是否要移除岗位', '提示', {
                    type: 'warning'
                }).then(res=>{
                    gameDelPosition(this.positionIds).then(res => {
                        this.$message.success('移除成功');
                        this.getList();
                    })
                })
            },

            //移除裁判员
            doDelReferee() {
                if (this.refereeIds.length === 0) {
                    this.$message.error('请选择要移除的裁判');
                    return;
                }

                this.$confirm('是否要移除裁判员', '提示', {
                    type: 'warning'
                }).then(res=> {
                    gameDelReferee(this.refereeIds).then(res => {
                        this.$message.success('移除成功');
                        this.getList();
                    })
                })
            },

            // 发送短信
            sendMsg() {
                if (this.refereeIds.length === 0) {
                    this.$message.error('请选择要发送短信的裁判');
                    return;
                }

                if (this.baseInfo.confirmState === CONFIRM_TYPE_CODE.UNCONFIRM) {
                    this.$message.error('请确认当前赛事裁判员已选派后操作');
                    return;
                }

                this.$refs[this.MODAL_KEY.SEND_MSG_MODAL].showModal();
            },

            doSendMsg(data) {
                sendMsg({ids: this.refereeIds,...data}).then(res=>{
                    this.$message.success('短信发送成功');
                    this.$refs[this.MODAL_KEY.SEND_MSG_MODAL].closeModal();
                })
            },

            selectionChange(selection) {
                this.positionIds = [];
                selection.map(item => {
                    this.positionIds.push(item.gamePositionId);
                })
            },

            //修改裁判员Id
            changeIds(positionId, refereeIds) {
                this.refereeSelect[positionId] = refereeIds;
                this.refereeIds = [];
                Object.keys(this.refereeSelect).map(item => {
                    this.refereeIds.push(...this.refereeSelect[item]);
                })
            },
            //一键确认|取消
            doConfirm(state) {
                gameConfirm({
                    gameId: this.gameId,
                    state
                }).then(res => {
                    this.$message.success('操作成功');
                    this.getList();
                })
            },

            //导出派选名单
            doExport(data) {
                exportGame({gameId: this.gameId}).then(res => {
                    apiDownLoadFile(res.data, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', this.baseInfo.gameNameCHN + '选派名单.doc');
                })
            },

            //移除岗位裁判员
            doDelPositionReferee(positionId) {
                this.$confirm('是否移除当前岗位下的所有裁判员', '提示', {type: 'warning'}).then(res => {
                    delPositionReferee(positionId).then(res => {
                        this.$message.success('移除成功');
                        this.getList();
                    })
                })
            },
            showAddReferee(data) {
                this.curPosition = data.id;
                this.positionName = data.name;
                this.$refs[this.MODAL_KEY.ADD_POSITION_REFEREE_MODAL].showModal();
            },
            //添加岗位裁判员
            doAddReferee(ids) {
                let params = [];
                ids.map(item => {
                    params.push({gameId: this.gameId, positionId: this.curPosition, refereeId: item});
                })

                addPositionReferee(params).then(res => {
                    this.getList();
                    this.$message.success('选派成功');
                    this.$refs[this.MODAL_KEY.ADD_POSITION_REFEREE_MODAL].closeModal();
                    this.curPosition = '';
                    this.positionName = '';
                })
            },

            getSpeciality() {
                fetchSpeciality().then(res => {
                    this.specialityList = res.data.data;
                    res.data.data && res.data.data.map(item => {
                        this.specialityMap[item.code] = item.name;
                    })

                    this.getList();
                });
            },

        },

        mounted() {
            this.gameId = this.$router.history.current.params.id;
            this.getSpeciality();
        }
    }
</script>
<style lang="less" scoped>
    .select-title {
        margin-top: 10px;
        line-height: 40px;
        height: 40px;
        font-size: 20px;
        border-bottom: 1px solid #e1e1e1;
        margin-bottom: 15px;
    }
</style>
