<!-- 赛事中心 -->
<template>
  <div>
    <el-row :gutter="20" class="page-top-space">
      <el-col :span="12" class="top-search">
        <el-row :gutter="20">
          <el-col :span="8">
            <el-select
              @change="getList(1)"
              placeholder="请输入赛事开始年份"
              v-model="listQuery.year"
              clearable
              filterable
            >
              <el-option
                v-for="(item, index) in yearList"
                :value="item"
                :label="item"
                :key="index"
              ></el-option>
            </el-select>
          </el-col>

          <el-col :span="8">
            <el-input
              placeholder="请输入赛事名称关键字搜索"
              v-model="listQuery.gameName"
              @change="getList(1)"
            ></el-input>
          </el-col>

          <el-col :span="8">
            <el-button type="primary" @click="getList(1)">查询</el-button>
          </el-col>
        </el-row>
      </el-col>

      <el-col :span="12" class="text-r">
        <el-button type="info" @click="doBatExport(ids)" v-auth="per.game_export"
          >批量导出</el-button
        >
      </el-col>
    </el-row>

    <el-table border :data="dataSource" class="page-top-space" @selection-change="selectionChange">
      <el-table-column type="selection"></el-table-column>
      <el-table-column label="序号" type="index"></el-table-column>
      <el-table-column label="赛事名称" prop="gameNameCHN"></el-table-column>
      <el-table-column label="赛事地点" prop="gameSiteCHN"></el-table-column>
      <el-table-column label="赛事报名起止时间" prop="index">
        <template slot-scope="scope">
          {{ scope.row.signUpBeginTime | dateFormat(null, 'YYYY-MM-DD') }} ~
          {{ scope.row.signUpEndTime | dateFormat(null, 'YYYY-MM-DD') }}
        </template>
      </el-table-column>

      <el-table-column label="赛事起止时间" prop="index">
        <template slot-scope="scope">
          {{ scope.row.beginTime | dateFormat(null, 'YYYY-MM-DD') }} ~
          {{ scope.row.endTime | dateFormat(null, 'YYYY-MM-DD') }}
        </template>
      </el-table-column>

      <el-table-column label="选派确认" prop="index" width="100px">
        <template slot-scope="scope">
          <MyBadge :list="CONFIRM_TYPE" :target="scope.row.confirmState"></MyBadge>
        </template>
      </el-table-column>

      <el-table-column label="操作" prop="operation" fixed="right" min-width="100px">
        <template slot-scope="scope">
          <span
            class="option option-primary"
            @click="goSelect(scope.row)"
            v-auth="per.game_dispatch_manage"
            >选派</span
          >
          <span
            class="option option-primary"
            @click="doExport(scope.row)"
            v-auth="per.game_export_list"
            >导出名单</span
          >
        </template>
      </el-table-column>
    </el-table>

    <el-pagination
      class="page-top-space"
      background
      :total="total"
      :page-size="listQuery.pageSize"
      :current-page.sync="listQuery.pageNo"
      @current-change="getList"
    >
    </el-pagination>
  </div>
</template>

<script>
import {fetchGameList, batExportGame, exportGame} from '@/api/game';
import {CONFIRM_TYPE, GAME_AUDIT_STATUS_CODE} from '@/const/index';
import {apiDownLoadFile} from '@/common/util';

export default {
  data() {
    let yearList = [];
    let start = 2018;
    let tar = new Date().getFullYear() + 2;
    yearList = new Array(tar - start).fill(start).map((item, index) => {
      return item + index;
    });
    return {
      yearList: yearList,
      MODAL_KEY: {
        EDIT_MODAL: 'EDIT_MODAL',
      },
      modalData: {},
      modalType: '',
      CONFIRM_TYPE: CONFIRM_TYPE,
      dataSource: [],
      total: 0,
      ids: [],
      listQuery: {
        pageNo: 1,
        pageSize: 10,
        dataSources: 2,
        auditState: GAME_AUDIT_STATUS_CODE.PASS,
      },
    };
  },
  methods: {
    selectionChange(selection) {
      this.ids = [];
      selection.map((item) => {
        this.ids.push(item.id);
      });
    },
    getList(current) {
      if (!this.validatenull(current)) {
        this.listQuery.pageNo = current;
      }

      fetchGameList(this.listQuery).then((res) => {
        this.dataSource = res.data.data.results;
        this.total = res.data.data.total_record;
      });
    },

    doBatExport(ids) {
      if (this.validatenull(ids)) {
        this.$message.error('请选择赛事再导出');
        return;
      }

      batExportGame({gameIds: ids}).then((res) => {
        apiDownLoadFile(
          res.data,
          'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
          '赛事选派名单.doc'
        );
      });
    },

    doExport(data) {
      exportGame({gameId: data.id}).then((res) => {
        apiDownLoadFile(
          res.data,
          'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
          data.gameNameCHN + '选派名单.doc'
        );
      });
    },

    goSelect(data) {
      this.$router.push(`/game/center/${data.id}`);
    },
  },

  mounted() {
    this.getList();
  },
};
</script>
