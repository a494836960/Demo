<template>
  <div>
    <el-alert
      v-if="baseInfo.auditState === AUDIT_TYPE_CODE.AUDITED"
      title="当前赛事已被管理员确认审核，无法进行添加编辑移除操作！"
      type="warning"
      :closable="false"
    >
    </el-alert>

    <div class="select-title">
      <span>{{ baseInfo.gameNameCHN }}</span>
      <el-button
        class="float-r"
        type="info"
        @click="
          () => {
            this.$router.go(-1);
          }
        "
        >返回</el-button
      >
    </div>

    <div>
      <el-button
        type="primary"
        @click="showAddPosition"
        v-auth="per.record_dispatch_position_add"
        :disabled="baseInfo.auditState === AUDIT_TYPE_CODE.AUDITED"
        >添加岗位
      </el-button>
      <el-button
        type="primary"
        @click="showAddReferee"
        v-auth="per.record_dispatch_referee_add"
        :disabled="baseInfo.auditState === AUDIT_TYPE_CODE.AUDITED"
        >录入裁判
      </el-button>
      <el-button
        type="danger"
        @click="doDelReferee"
        :disabled="baseInfo.auditState === AUDIT_TYPE_CODE.AUDITED"
        v-auth="per.record_dispatch_referee_del"
      >
        移除裁判
      </el-button>

      <!--<el-button type="danger" v-if="baseInfo.auditState" @click="doAudit([gameId],false)">取消审核</el-button>
            <el-button type="primary" v-else @click="doAudit([gameId],true)">录入审核</el-button>-->
    </div>

    <el-table
      border
      :data="dataSource"
      class="page-top-space"
      :expand-row-keys="keys"
      row-key="id"
      @selection-change="selectionChange"
    >
      <el-table-column type="expand">
        <template slot-scope="scope">
          <RecordExpandTable
            :rows="scope.row.gameRefereeRecordList || []"
            :auditState="baseInfo.auditState"
            @showEdit="showEditReferee"
            @doDel="expandDelReferee"
            :positionId="scope.row.gamePositionId"
            @selection-change="changeIds"
          ></RecordExpandTable>
        </template>
      </el-table-column>

      <el-table-column prop="positionName" label="岗位">
        <template slot-scope="scope">
          <span class="option option-primary">{{ scope.row.positionName }}</span>
        </template>
      </el-table-column>

      <el-table-column prop="operation" label="操作" width="330px">
        <template slot-scope="scope">
          <el-button
            type="primary"
            @click="showAddReferee(scope.row.positionId)"
            v-auth="per.record_dispatch_referee_add"
            :disabled="baseInfo.auditState === AUDIT_TYPE_CODE.AUDITED"
            >录入裁判
          </el-button>

          <el-button
            type="danger"
            plain
            @click="doDelPositionReferee([scope.row.id])"
            v-auth="per.record_dispatch_position_del"
            :disabled="baseInfo.auditState === AUDIT_TYPE_CODE.AUDITED"
            >移除岗位
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <AddPositionModal :ref="MODAL_KEY.ADD_POSITION" @submit="doAddPosition"></AddPositionModal>
    <EditRefereeModal
      :ref="MODAL_KEY.ADD_POSITION_REFEREE_MODAL"
      :modalData="modalData"
      @submit="doAddReferee"
      :positionList="dataSource"
    ></EditRefereeModal>
  </div>
</template>

<script>
import {
  gameDelPosition,
  editRecordReferee,
  fetchGameDetail,
  fetchRecordDetail,
  addRecordPosition,
  delRecordPosition,
  recordAudit,
  delRecordReferee
} from '@/api/game';
import RecordExpandTable from './component/RecordExpandTable';
import AddPositionModal from './component/AddPositionModal';
import {AUDIT_TYPE_CODE} from '@/const/index';
import EditRefereeModal from './component/EditRefereeModal';

export default {
  components: {RecordExpandTable, AddPositionModal, EditRefereeModal},
  data() {
    return {
      keys: [],
      AUDIT_TYPE_CODE: AUDIT_TYPE_CODE,
      modalData: {},
      gameId: '',
      positionIds: [],
      refereeIds: [],
      refereeSelect: {},
      dataSource: [],
      baseInfo: {},
      curPosition: '',
      positionName: '',
      MODAL_KEY: {
        ADD_POSITION: 'ADD_POSITION',
        ADD_POSITION_REFEREE_MODAL: 'ADD_POSITION_REFEREE_MODAL'
      }
    };
  },

  methods: {
    showAddPosition() {
      this.$refs[this.MODAL_KEY.ADD_POSITION].showModal();
    },

    getList() {
      fetchRecordDetail(this.gameId).then((res) => {
        this.dataSource = res.data.data;
      });
    },

    //添加岗位
    doAddPosition(ids) {
      let params = [];
      ids.map((item) => {
        params.push({gameId: this.gameId, positionId: item});
      });

      addRecordPosition(params).then((res) => {
        this.$message.success('岗位添加成功');
        this.getList();
        this.$refs[this.MODAL_KEY.ADD_POSITION].closeModal();
      });
    },

    //移除岗位
    doDelPosition() {
      if (this.positionIds.length === 0) {
        this.$message.error('请选择要移除的岗位');
        return;
      }
      gameDelPosition(this.positionIds).then((res) => {
        this.$message.success('移除成功');
        this.getList();
      });
    },

    expandDelReferee(id) {
      this.$confirm('是否要移除裁判', '提示', {type: 'warning'}).then((res) => {
        delRecordReferee(id).then((res) => {
          this.$message.success('移除成功');
          this.getList();
        });
      });
    },

    //移除裁判员
    doDelReferee() {
      if (this.refereeIds.length === 0) {
        this.$message.error('请选择要移除的裁判');
        return;
      }

      this.expandDelReferee(this.refereeIds);
    },

    selectionChange(selection) {
      this.positionIds = [];
      selection.map((item) => {
        this.positionIds.push(item.gamePositionId);
      });
    },

    //修改裁判员Id
    changeIds(positionId, refereeIds) {
      this.refereeSelect[positionId] = refereeIds;
      this.refereeIds = [];
      Object.keys(this.refereeSelect).map((item) => {
        this.refereeIds.push(...this.refereeSelect[item]);
      });
    },

    //移除岗位裁判员
    doDelPositionReferee(positionId) {
      this.$confirm('是否移除当前岗位', '提示', {type: 'warning'}).then((res) => {
        delRecordPosition(positionId).then((res) => {
          this.$message.success('移除成功');
          this.getList();
        });
      });
    },
    showAddReferee(id) {
      this.modalData = {
        unitId: undefined,
        unitName: undefined,
        sex: undefined,
        political: undefined,
        level: undefined,
        mobile: undefined,
        education: undefined,
        idcard: undefined,
        birthday: undefined,
        cnName: undefined,
        ethnicity: undefined,
        enName: undefined,
        enSurname: undefined,
        positionId: id || undefined
      };
      this.modalType = 'add';
      this.$refs[this.MODAL_KEY.ADD_POSITION_REFEREE_MODAL].showModal();
    },

    showEditReferee(data) {
      this.modalData = this.deepClone(data);
      this.modalType = 'edit';
      this.$refs[this.MODAL_KEY.ADD_POSITION_REFEREE_MODAL].showModal();
    },

    //添加岗位裁判员
    doAddReferee(params) {
      params.gameId = this.gameId;

      editRecordReferee(params).then((res) => {
        this.$message.success('编辑成功');
        this.getList();
        this.$refs[this.MODAL_KEY.ADD_POSITION_REFEREE_MODAL].closeModal();
      });
    },

    /****************/
    getGameInfo() {
      fetchGameDetail(this.gameId).then((res) => {
        this.baseInfo = res.data.data;
      });
    },

    doAudit(ids, type) {
      if (ids.length === 0) {
        this.$message.error('请选择数据进行操作');
        return;
      }
      let params = [];
      ids &&
        ids.map((item) => {
          params.push({id: item, auditState: type});
        });

      recordAudit(params).then((res) => {
        this.getGameInfo();
        this.$message.success('操作成功');
      });
    }
  },

  mounted() {
    this.gameId = this.$router.history.current.params.id;
    this.getList();
    this.getGameInfo();
  }
};
</script>
<style lang="less" scoped>
.select-title {
  margin-top: 10px;
  line-height: 40px;
  height: 40px;
  font-size: 20px;
  border-bottom: 1px solid #e1e1e1;
  margin-bottom: 15px;
}
</style>
