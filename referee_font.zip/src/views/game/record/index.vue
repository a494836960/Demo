<template>
  <div class="page-top-space">
    <el-row :gutter="20">
      <el-col :span="4">
        <el-select
          @change="getList(1)"
          placeholder="请输入赛事开始年份"
          v-model="listQuery.year"
          clearable
          filterable
        >
          <el-option
            v-for="(item, index) in yearList"
            :value="item"
            :label="item"
            :key="index"
          ></el-option>
        </el-select>
      </el-col>

      <el-col :span="4">
        <el-input
          v-model="listQuery.cnName"
          placeholder="请输入赛事名称关键字搜索"
          @change="getList(1)"
        />
      </el-col>

      <el-col :span="4">
        <el-button type="primary" @click="getList(1)">查询</el-button>
      </el-col>

      <!--<el-col :span="12" class="text-r">
                    <el-button class="but" type="primary" @click="doAudit(ids, AUDIT_TYPE_CODE.AUDITED)"
                               v-auth="per.game_audit">录入审核
                    </el-button>
                    <el-button class="but" type="danger" @click="doAudit(ids, AUDIT_TYPE_CODE.UNAUDITED)"
                               v-auth="per.game_cancel_audit">取消审核
                    </el-button>
                </el-col>-->
    </el-row>

    <el-table
      border
      :data="dataSource"
      class="page-top-space"
      row-class-name="table-row"
      @selection-change="selectChange"
    >
      <el-table-column type="selection"></el-table-column>
      <el-table-column type="index" label="序号"> </el-table-column>

      <el-table-column prop="gameNameCHN" label="赛事名称"> </el-table-column>

      <el-table-column prop="gameSiteCHN" label="赛事地点"> </el-table-column>

      <el-table-column prop="beginTime" width="150px" label="比赛开始时间">
        <template slot-scope="scope">
          {{ scope.row.beginTime | dateFormat(null, 'YYYY-MM-DD') }}
        </template>
      </el-table-column>

      <el-table-column prop="endTime" width="150px" label="比赛结束时间">
        <template slot-scope="scope">
          {{ scope.row.endTime | dateFormat(null, 'YYYY-MM-DD') }}
        </template>
      </el-table-column>

      <!--<el-table-column
                        prop="auditState"
                        width="100px"
                        label="审核状态">
                    <template slot-scope="scope">
                        <MyBadge :list="AUDIT_TYPE" :target="scope.row.auditState"></MyBadge>
                    </template>
                </el-table-column>-->

      <el-table-column label="操作" prop="operation">
        <template slot-scope="scope">
          <span
            class="option option-primary"
            @click="goSelect(scope.row)"
            v-auth="per.game_record_dispatch"
            >选派</span
          >
          <!-- <span v-if="scope.row.auditState" class="option option-danger"
                               @click="doAudit([scope.row.id],AUDIT_TYPE_CODE.UNAUDITED)" v-auth="per.game_cancel_audit">取消审核</span>
                         <span v-else class="option option-primary"
                               @click="doAudit([scope.row.id],AUDIT_TYPE_CODE.AUDITED)"
                               v-auth="per.game_audit">录入审核</span>-->
        </template>
      </el-table-column>
    </el-table>

    <el-pagination
      class="page-top-space"
      background
      :total="total"
      :page-size="listQuery.pageSize"
      :current-page.sync="listQuery.pageNo"
      @current-change="getList"
    >
    </el-pagination>
  </div>
</template>

<script>
import {fetchGameList, fetchRecordList, recordAudit} from '@/api/game';
import {AUDIT_TYPE, AUDIT_TYPE_CODE, GAME_AUDIT_STATUS_CODE} from '@/const/index';

export default {
  data() {
    let yearList = [];
    let start = 2018;
    let tar = new Date().getFullYear() + 2;
    yearList = new Array(tar - start).fill(start).map((item, index) => {
      return item + index;
    });
    return {
      yearList: yearList,
      AUDIT_TYPE_CODE: AUDIT_TYPE_CODE,
      AUDIT_TYPE: AUDIT_TYPE,
      ids: [],
      dataSource: [],
      total: 0,
      listQuery: {
        pageNo: 1,
        pageSize: 10,
        userId:
          this.$store.getters.userInfo.unitType === 'ALL' ? '' : this.$store.getters.userInfo.id,
        auditState: GAME_AUDIT_STATUS_CODE.PASS,
      },
    };
  },
  methods: {
    selectChange(selection) {
      this.ids = [];
      selection.map((item) => {
        this.ids.push(item.id);
      });
    },
    getList(current) {
      if (!this.validatenull(current)) {
        this.listQuery.pageNo = current;
      }
      fetchGameList(this.listQuery).then((res) => {
        this.dataSource = res.data.data.results;
        this.total = res.data.data.total_record;
      });
    },

    doAudit(ids, type) {
      if (ids.length === 0) {
        this.$message.error('请选择数据进行操作');
        return;
      }
      let params = [];
      ids &&
        ids.map((item) => {
          params.push({id: item, auditState: type});
        });

      recordAudit(params).then((res) => {
        this.getList();
        this.$message.success('操作成功');
      });
    },

    goSelect(data) {
      this.$router.push(`/game/record/${data.id}`);
    },
  },

  mounted() {
    this.getList();
  },
};
</script>
