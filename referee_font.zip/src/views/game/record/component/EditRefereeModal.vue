<template>
    <el-dialog
            :title="type==='edit'?'编辑裁判': '新增裁判'"
            :close-on-click-modal="isClickModalClose"
            :visible.sync="isShow"
            width="900px"
            @close="closeModal"
    >
        <el-form :ref="formName" :model="modalData" :rules="ruleValidate" label-width="100px">
            <el-row :gutter="40">
                <el-col :span="12">
                    <el-form-item label="姓名(中文)：" prop="cnName">
                        <el-autocomplete
                                style="width: 100%;"
                                v-model="modalData.cnName"
                                :fetch-suggestions="querySearchAsync"
                                placeholder="请输入姓名"
                                @select="handleSelect">
                            <template slot-scope="{ item }">
                                <div style="font-size: 14px;">{{ item.cnName}} <span
                                        style="font-size: 14px;color: #b4b4b4;">（{{ item.unitName }}）</span></div>

                            </template>
                        </el-autocomplete>
                    </el-form-item>

                    <el-form-item label="注册所属省市：" prop="unitId">
                        <el-select v-model="modalData.unitId" placeholder="请选择注册所属省市" filterable>
                            <el-option v-for="(item,index) in unitList" :value="item.id" :label="item.cnName"
                                       :key="index"></el-option>
                        </el-select>
                    </el-form-item>

                    <el-form-item label="身份证：" prop="idcard">
                        <el-input v-model="modalData.idcard" placeholder="请输入身份证" :maxLength="32"></el-input>
                    </el-form-item>

                    <el-form-item label="性别：" prop="sex">
                        <el-radio-group v-model="modalData.sex">
                            <el-radio :label="0">男</el-radio>
                            <el-radio :label="1">女</el-radio>
                        </el-radio-group>
                    </el-form-item>

                    <el-form-item label="培训岗位：" prop="positionId">
                        <el-select v-model="modalData.positionId" placeholder="请选择岗位">
                            <el-option v-for="(item, index) in positionList" :value="item.id" :label="item.name"
                                       :key="index"></el-option>
                        </el-select>
                    </el-form-item>

                    <el-form-item label="民族：" prop="ethnicity">
                        <el-select v-model="modalData.ethnicity" placeholder="请选择民族">
                            <el-option v-for="(item, index) in ethnicityList" :value="item" :label="item"
                                       :key="index"></el-option>
                        </el-select>
                    </el-form-item>

                </el-col>
                <el-col :span="12">
                    <el-form-item label="手机号：" prop="mobile">
                        <el-input v-model="modalData.mobile" placeholder="请输入手机号" :maxLength="11"></el-input>
                    </el-form-item>

                    <el-form-item label="出生日期：" prop="birthday">
                        <el-date-picker
                                v-model="modalData.birthday"
                                value-format="timestamp"
                                type="date"
                                placeholder="选择日期">
                        </el-date-picker>
                    </el-form-item>

                    <el-row :gutter="20">
                        <el-col :span="12">
                            <el-form-item label="姓名(拼音)：" prop="enSurname">
                                <el-input v-model="modalData.enSurname" placeholder="请输入姓" :maxLength="32"></el-input>
                            </el-form-item>
                        </el-col>

                        <el-col :span="12">
                            <el-form-item prop="enName" label-width="0">
                                <el-input v-model="modalData.enName" placeholder="请输入名" :maxLength="32"></el-input>
                            </el-form-item>
                        </el-col>
                    </el-row>

                    <el-form-item label="裁判等级：" prop="level">
                        <el-select v-model="modalData.level" placeholder="请选择裁判等级" filterable>
                            <el-option v-for="(item,index) in levelList" :value="item.value+''" :label="item.name"
                                       :key="index"></el-option>
                        </el-select>
                    </el-form-item>

                    <el-form-item label="政治面貌：" prop="political">
                        <el-select v-model="modalData.political" placeholder="请输入政治面貌">
                            <el-option v-for="(item, index) in politicalList" :value="item" :label="item"
                                       :key="index"></el-option>
                        </el-select>
                    </el-form-item>

                    <el-form-item label="教育背景：" prop="education">
                        <el-select v-model="modalData.education" placeholder="请选择学历">
                            <el-option v-for="(item, index) in educationList" :value="item.value" :label="item.name"
                                       :key="index"></el-option>
                        </el-select>
                    </el-form-item>
                </el-col>
            </el-row>
        </el-form>

        <div slot="footer">
            <el-button @click="closeModal">
                取消
            </el-button>

            <el-button @click="submit" type="primary">
                确定
            </el-button>
        </div>
    </el-dialog>
</template>

<script>
    import modalMixin from '@/mixins/modalMixin';
    import political from '@/common/political'
    import {fetchPosition} from '@/api/position';
    import nation from '@/common/nation'
    import {fetchUnitAll} from '@/api/unit';
    import {EDUCATION_TYPE, LANGUAGE_LEVEL, LANGUAGE_TYPE, LEVEL_TYPE} from '@/const/index'
    import {fetchRefereeByName} from '@/api/game';

    export default {
        mixins: [modalMixin],
        props: ['modalData', 'type'],
        data() {
            return {
                unitList: [],
                positionList: [],
                levelList: LEVEL_TYPE,
                languageList: LANGUAGE_TYPE,
                languageLevel: LANGUAGE_LEVEL,
                educationList: EDUCATION_TYPE,
                politicalList: political, // 政治面貌list
                ethnicityList: nation, // 民族list


                imgUrl: this.imgUrl,
                formName: 'form',
                ruleValidate: {
                    positionId: [
                        {
                            required: true,
                            message: '岗位不能为空！',
                            trigger: 'change'
                        }
                    ],
                    unitId: [
                        {
                            required: true,
                            message: '注册所属省市不能为空！',
                            trigger: 'change'
                        }
                    ],
                    cnName: [
                        {
                            required: true,
                            message: '中文姓名不能为空！',
                            trigger: 'blur'
                        }
                    ],

                    idcard: [
                        {
                            required: true,
                            message: '身份证不能为空！',
                            trigger: 'blur'
                        }
                    ],
                    area: [
                        {
                            required: true,
                            message: '籍贯不能为空！',
                            trigger: 'change'
                        }
                    ],
                    sex: [
                        {
                            required: true,
                            message: '性别不能为空！',
                            trigger: 'change'
                        }
                    ],
                    mobile: [
                        {
                            required: true,
                            message: '电话号码不能为空！',
                            trigger: 'blur'
                        }
                    ], birthday: [
                        {
                            required: true,
                            message: '出生日期不能为空！',
                            trigger: 'change'
                        }
                    ],

                }
            };
        },
        methods: {
            submit() {
                this.validateForm().then(res => {
                    this.unitList.map(item=>{
                        if(item.id === this.modalData.unitId){
                            this.modalData.unitName = item.cnName;
                        }
                    })
                    this.$emit('submit', this.modalData);
                })
            },

            //获取单位列表
            getUnit() {
                fetchUnitAll().then(res => {
                    this.unitList = res.data.data;
                })
            },

            //查询所有的岗位
            getPosition() {
                fetchPosition(this.listQuery).then(res => {
                    this.positionList = res.data.data.results
                })
            },
            querySearchAsync(str, cb) {
                fetchRefereeByName({cnName: str}).then(res => {
                    cb(res.data.data);
                })
            },
            handleSelect(item) {
                Object.assign(this.modalData, {
                    unitId: item.unitId,
                    unitName: item.unitName,
                    sex: item.sex,
                    political: item.political,
                    level: item.level,
                    mobile: item.mobile,
                    education: item.education,
                    idcard: item.idcard,
                    birthday: item.birthday,
                    cnName: item.cnName,
                    ethnicity: item.ethnicity,
                    enName: item.enName,
                    enSurname: item.enSurname,
                })
            }
        },

        mounted() {
            this.getUnit();
            this.getPosition();
        }
    }
</script>

<style lang="less">
    .img-tips {
        line-height: 23px;

        dl {
            list-style: circle;
        }

        dt {
            font-weight: bold;
            margin-top: 10px;
        }
    }
</style>
