<template>
    <el-table :data="rows" @selection-change="selectionChange">
        <el-table-column type="selection"></el-table-column>
        <el-table-column type="index"></el-table-column>
        <el-table-column prop="cnName" label="姓名"></el-table-column>
        <el-table-column prop="sex" label="性别">
            <template slot-scope="scope">
                <MyBadge :list="GENDER" :target="scope.row.sex"></MyBadge>
            </template>
        </el-table-column>

        <el-table-column prop="unitName" label="注册所属省市"></el-table-column>
        <el-table-column prop="mobile" label="手机号码"></el-table-column>
        <el-table-column prop="idcard" label="身份证"></el-table-column>

        <el-table-column prop="birthday" label="出生日期">
            <template slot-scope="scope">
                {{scope.row.birthday|dateFormat(null,'YYYY-MM-DD')}}
            </template>
        </el-table-column>

        <el-table-column prop="unitName" label="当前评分">
            <template slot-scope="scope">
                0
            </template>
        </el-table-column>

        <el-table-column prop="unitName" label="操作">
            <template slot-scope="scope">
                <span class="option option-primary" @click="doEdit(scope.row)">编辑</span>
                <span class="option option-danger" @click="doDel(scope.row)">移除</span>
            </template>
        </el-table-column>
    </el-table>
</template>

<script>
    import {GENDER, LEVEL_TYPE, NOTIFY_STATUS, CONFIRM_TYPE, AUDIT_TYPE_CODE} from '@/const/index'

    export default {
        props: ['rows', 'positionId', 'auditState'],
        data() {
            return {
                ids: [],
                CONFIRM_TYPE: CONFIRM_TYPE,
                GENDER: GENDER,
                LEVEL_TYPE: LEVEL_TYPE,
                NOTIFY_STATUS: NOTIFY_STATUS,
            };
        },

        methods: {
            doEdit(data) {
                if (this.auditState === AUDIT_TYPE_CODE.AUDITED) {
                    return;
                }
                this.$emit('showEdit', data)
            },
            doDel(data) {
                if (this.auditState === AUDIT_TYPE_CODE.AUDITED) {
                    return;
                }
                this.$emit('doDel', [data.id]);
            },
            selectionChange(selection) {
                this.ids = [];
                selection.map(item => {
                    this.ids.push(item.id);
                });

                this.$emit('selection-change', this.positionId, this.ids);
            }
        }
    }
</script>
