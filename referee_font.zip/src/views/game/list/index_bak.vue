<!-- 赛事中心 -->
<template>
    <div>
        <el-row :gutter="20" class="page-top-space">
            <el-col :span="12" class="top-search">
                <el-row :gutter="20">
                    <el-col :span="8">
                        <el-input placeholder="请输入赛事名称关键字搜索" v-model="listQuery.gameName"
                                  @change="getList(1)"></el-input>
                    </el-col>

                    <el-col :span="8">
                        <el-button type="primary" @click="getList(1)">查询</el-button>
                    </el-col>
                </el-row>
            </el-col>

            <el-col :span="12" class="text-r">
                <el-button type="primary" @click="showAdd" v-auth="per.game_sync">添加赛事</el-button>
                <el-button type="danger" @click="doDel(ids)" v-auth="per.game_delete">删除赛事</el-button>
                <el-button type="info" @click="doBatExport(ids)" v-auth="per.game_export">批量导出</el-button>
            </el-col>
        </el-row>

        <el-table border :data="dataSource" class="page-top-space" @selection-change="selectionChange">
            <el-table-column type="selection"></el-table-column>
            <el-table-column label="序号" type="index"></el-table-column>
            <el-table-column label="赛事名称" prop="gameNameCHN"></el-table-column>
            <el-table-column label="赛事地点" prop="gameSiteCHN"></el-table-column>
            <el-table-column label="赛事起止时间" prop="index">
                <template slot-scope="scope">
                    {{scope.row.beginTime|dateFormat(null,'YYYY-MM-DD')}} -
                    {{scope.row.endTime|dateFormat(null,'YYYY-MM-DD')}}
                </template>
            </el-table-column>
            <el-table-column label="选派人数" prop="refereeNum"></el-table-column>
            <el-table-column label="选派确认" prop="index">
                <template slot-scope="scope">
                    <MyBadge :list="CONFIRM_TYPE" :target="scope.row.confirmState"></MyBadge>
                </template>
            </el-table-column>
            <el-table-column label="操作" prop="operation">
                <template slot-scope="scope">
                    <span class="option option-primary" @click="goSelect(scope.row)" v-auth="per.game_dispatch">选派</span>
                    <span class="option option-primary" @click="showEdit(scope.row)" v-auth="per.game_update">编辑</span>
                    <span class="option option-primary" @click="doExport(scope.row)" v-auth="per.game_export_list">导出名单</span>
                </template>
            </el-table-column>
        </el-table>

        <el-pagination
                class="page-top-space"
                background
                :total="total"
                :page-size="listQuery.pageSize"
                :current-page.sync="listQuery.pageNo"
                @current-change="getList"
        >
        </el-pagination>
        <EditModal :ref="MODAL_KEY.EDIT_MODAL" :modalData="modalData" @submit="doSubmit" :modalType="modalType"></EditModal>
    </div>
</template>

<script>
    import {fetchGameList, syncGame, delGame, batExportGame, exportGame, updateGame, addGame} from '@/api/game';
    import {CONFIRM_TYPE} from '@/const/index';
    import {apiDownLoadFile} from "@/common/util";
    import EditModal from './component/EditModal';

    export default {
        components: {EditModal},
        data() {
            return {
                MODAL_KEY: {
                    EDIT_MODAL: 'EDIT_MODAL'
                },
                modalData: {},
                modalType: '',
                CONFIRM_TYPE: CONFIRM_TYPE,
                dataSource: [],
                total: 0,
                ids: [],
                listQuery: {
                    pageNo: 1,
                    pageSize: 10,
                    dataSources:2
                },
            }
        },
        methods: {
            selectionChange(selection) {
                this.ids = [];
                selection.map(item => {
                    this.ids.push(item.id);
                })
            },
            getList(current) {
                if (!this.validatenull(current)) {
                    this.listQuery.pageNo = current;
                }

                fetchGameList(this.listQuery).then(res => {
                    this.dataSource = res.data.data.results;
                    this.total = res.data.data.total_record;
                });
            },

            showAdd(){
                this.modalType = 'add';
                this.modalData = {};
                this.$refs[this.MODAL_KEY.EDIT_MODAL].showModal();
            },

            doDel(ids) {
                if (this.validatenull(ids)) {
                    this.$message.error('请选择数据进行操作');
                    return;
                }

                this.$confirm('是否要删除赛事', '提示', {type: 'warning'}).then(res => {
                    delGame(ids).then(res => {
                        this.getList();
                        this.$message.success('删除成功');
                    })
                });
            },

            doBatExport(ids) {
                if (this.validatenull(ids)) {
                    this.$message.error('请选择赛事再导出');
                    return;
                }

                batExportGame({gameIds: ids}).then(res => {
                    apiDownLoadFile(res.data, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '赛事选派名单.doc');
                })
            },

            doExport(data) {
                exportGame({gameId: data.id}).then(res => {
                    apiDownLoadFile(res.data, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', data.gameNameCHN + '选派名单.doc');
                })
            },

            goSelect(data) {
                this.$router.push(`/game/center/${data.id}`);
            },
            showEdit(data) {
                this.modalData = this.deepClone(data);
                this.modalType = 'edit';
                this.$refs[this.MODAL_KEY.EDIT_MODAL].showModal();
            },

            doSubmit(data) {
                let result = addGame;
                if(!this.validatenull(data.id)){
                    result = updateGame;
                }

                result(data).then(res => {
                    this.$message.success('操作成功');
                    this.getList();
                    this.$refs[this.MODAL_KEY.EDIT_MODAL].closeModal();
                })
            }
        },

        mounted() {
            this.getList();
        }
    }
</script>
