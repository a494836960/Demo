<template>
  <div>
    <el-dialog
      :title="modalType === 'add' ? '添加赛事' : '编辑赛事'"
      :close-on-click-modal="isClickModalClose"
      :visible.sync="isShow"
      width="1000px"
      @close="closeModal"
    >
      <el-form
        :ref="formName"
        :model="modalData"
        :rules="ruleValidate"
        label-width="120px"
      >
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="赛事中文名称：" prop="gameNameCHN">
              <el-input placeholder="请输入赛事中文名称" v-model="modalData.gameNameCHN"></el-input>
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="赛事英文名称：" prop="gameNameENG">
              <el-input placeholder="请输入赛事英文名称" v-model="modalData.gameNameENG"></el-input>
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="赛事类型：" prop="gameType">
              <el-select placeholder="请选择赛事类型" v-model="modalData.gameType">
                <el-option
                  v-for="(item, index) in GAME_TYPE"
                  :key="index"
                  :value="item.value"
                  :label="item.name"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="赛事规程：" prop="gameFile">
              <el-input
                v-model="modalData.gameFile"
                placeholder="请选择上传赛事规程"
                :disabled="true"
              >
                <uploadFile
                  slot="append"
                  action="admin/referee/add/temp"
                  @success="uploadGameFile"
                ></uploadFile>
              </el-input>
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="赛事报名时间：" prop="signUpDate">
              <el-date-picker
                :picker-options="pickerOptions"
                style="width: 100%;"
                @change="changeSign"
                v-model="modalData.signUpDate"
                :default-time="['00:00:00', '23:59:59']"
                value-format="timestamp"
                type="daterange"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
              >
              </el-date-picker>
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="赛事时间：" prop="date">
              <el-date-picker
                :picker-options="pickerOptions"
                :default-value="defaultTime"
                style="width: 100%;"
                v-model="modalData.date"
                :default-time="['00:00:00', '23:59:59']"
                value-format="timestamp"
                type="daterange"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
              >
              </el-date-picker>
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="赛事地区中文：" prop="area">
              <el-cascader
                v-model="modalData.area"
                :options="areasList"
                :props="{ value: 'name', label: 'name' }"
              ></el-cascader>
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="赛事地区英文：" prop="gameAreaENG">
              <el-input
                placeholder="请输入英文赛事省市区"
                v-model="modalData.gameAreaENG"
              ></el-input>
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="赛事地点中文：" prop="gameSiteCHN">
              <el-input placeholder="请输入中文赛事地点" v-model="modalData.gameSiteCHN"></el-input>
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="赛事地点英文：" prop="gameSiteENG">
              <el-input placeholder="请输入英文赛事地点" v-model="modalData.gameSiteENG"></el-input>
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="组别类型：" prop="sortType">
              <el-select v-model="modalData.sortType" placeholder="请选择组别类型">
                <el-option
                  v-for="(item, index) in SORT_TYPE"
                  :key="index"
                  :value="item.value"
                  :label="item.name"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="比赛级别：" prop="matchLevel">
              <el-row>
                <el-col :span="17">
                  <el-select v-model="modalData.matchLevel" placeholder="请选择比赛级别">
                    <el-option
                      v-for="(item, index) in matchLevelList"
                      :key="index"
                      :value="item.value"
                      :label="item.name"
                    ></el-option>
                  </el-select>
                </el-col>

                <el-col :span="7" class="text-c">
                  <span class="option option-primary" @click="showPreImg">查看说明</span>
                </el-col>
              </el-row>
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="主办单位：" prop="sponsorUnit">
              <el-input
                v-model="modalData.sponsorUnit"
                placeholder="主办单位，可填多个，用英文逗号“,”分割"
              ></el-input>
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="协办单位：" prop="coOrganizer">
              <el-input
                v-model="modalData.coOrganizer"
                placeholder="协办单位，可填多个，用英文逗号“,”分割"
              ></el-input>
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="承办单位：" prop="undertakingUnit">
              <el-input v-model="modalData.undertakingUnit" placeholder="请输入承办单位"></el-input>
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="赛区联系人：" prop="contacts">
              <el-input v-model="modalData.contacts" placeholder="请输入赛区联系人"></el-input>
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="赛区联系电话：" prop="contactPhone">
              <el-input
                v-model="modalData.contactPhone"
                placeholder="请输入赛区联系电话"
              ></el-input>
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="赛区传真：" prop="fax">
              <el-input v-model="modalData.fax" placeholder="请输入赛区传真"></el-input>
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="赛区邮箱：" prop="email">
              <el-input v-model="modalData.email" placeholder="请输入赛区邮箱"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>

      <div slot="footer">
        <el-button @click="closeModal">
          取消
        </el-button>

        <el-button @click="submit" type="primary">
          确定
        </el-button>
      </div>
    </el-dialog>

    <PreviewImgModal ref="preImg" :url="preUrl"></PreviewImgModal>
  </div>
</template>

<script>
import modalMixin from "@/mixins/modalMixin";
import { GAME_TYPE, SORT_TYPE, MATCH_LEVEL_LIST } from "@/const/index";
import { areas } from "@/common/area.js";
import PreviewImgModal from "@/components/previewImg";
import explainImg from "@/assets/image/explain.jpg";

export default {
  mixins: [modalMixin],
  components: { PreviewImgModal },
  props: ["modalData", "modalType"],
  data() {
    return {
      preUrl: explainImg,
      matchLevelList: MATCH_LEVEL_LIST,
      pickerOptions: {
        disabledDate(time) {
          return time.getTime() < Date.now();
        }
      },
      defaultTime: new Date(),
      formName: "form",
      GAME_TYPE: GAME_TYPE,
      SORT_TYPE: SORT_TYPE,
      areasList: areas.provinces,
      ruleValidate: {
        gameNameCHN: {
          required: true,
          message: "赛事中文名称不能为空",
          trigger: "blur"
        },
        matchLevel: {
          required: true,
          message: "赛事级别不能为空",
          trigger: "change"
        },
        gameNameENG: {
          required: true,
          message: "赛事英文名称不能为空",
          trigger: "blur"
        },
        gameType: {
          required: true,
          message: "赛事类型不能为空",
          trigger: "blur"
        },

        signUpDate: {
          required: true,
          message: "赛事报名时间不能为空",
          trigger: "change"
        },
        date: {
          required: true,
          message: "赛事考试时间不能为空",
          trigger: "change"
        },
        sortType: {
          required: true,
          message: "组别类型不能为空",
          trigger: "change"
        },
        gameSiteCHN: {
          required: true,
          message: "地点不能为空",
          trigger: "blur"
        },
        area: {
          required: true,
          message: "比赛地区不能为空",
          trigger: "blur"
        },
        contactPhone: {
          required: true,
          message: "请输入赛区联系电话",
          trigger: "blur"
        },
        contacts: {
          required: true,
          message: "请输入赛区人",
          trigger: "blur"
        }
      }
    };
  },
  methods: {
    showPreImg() {
      this.$refs.preImg.showModal();
    },
    changeSign(time) {
      if (!this.validatenull(time)) {
        this.defaultTime = time[1];
      }
    },
    uploadGameFile(res) {
      this.$set(this.modalData, "gameFile", res);
    },

    submit() {
      this.validateForm().then(res => {
        let obj = this.deepClone(this.modalData);

        obj.signUpEndTime = obj.signUpDate[1];
        obj.signUpBeginTime = obj.signUpDate[0];

        obj.endTime = obj.date[1];
        obj.beginTime = obj.date[0];

        obj.gameAreaCHN = obj.area.join("/");

        this.$emit("submit", obj);
      });
    }
  }
};
</script>
