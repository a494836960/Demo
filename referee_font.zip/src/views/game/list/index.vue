<!-- 赛事列表 -->
<template>
  <div>
    <el-row :gutter="20" class="search-box">
      <el-col :span="4">
        <el-select
          @change="getList(1)"
          placeholder="请输入赛事开始年份"
          v-model="listQuery.year"
          clearable
          filterable
        >
          <el-option
            v-for="(item, index) in yearList"
            :value="item"
            :label="item"
            :key="index"
          ></el-option>
        </el-select>
      </el-col>

      <el-col :span="4" v-if="userInfo.unitType === 'ALL'">
        <el-select
          v-model="listQuery.unitId"
          placeholder="申请单位"
          clearable
          filterable
          @change="getList(1)"
        >
          <el-option
            v-for="(item, index) in unitList"
            :key="index"
            :value="item.id"
            :label="item.cnName"
          ></el-option>
        </el-select>
      </el-col>

      <el-col :span="4">
        <el-select
          placeholder="请选择赛事审核状态"
          v-model="listQuery.auditState"
          @change="getList(1)"
          clearable
        >
          <el-option
            v-for="(item, index) in GAME_AUDIT_STATUS"
            :value="item.value"
            :label="item.name"
            :key="index"
          ></el-option>
        </el-select>
      </el-col>

      <!-- <el-col :span="8">
              <el-select v-model="listQuery.matchLevel" placeholder="请选择比赛级别">
                    <el-option
                      v-for="(item, index) in matchLevelList"
                      :key="index"
                      :value="item.value"
                      :label="item.name"
                    ></el-option>
                  </el-select>
            </el-col> -->

      <el-col :span="4">
        <el-input
          placeholder="请输入赛事名称关键字搜索"
          v-model="listQuery.gameName"
          @change="getList(1)"
        ></el-input>
      </el-col>

      <el-col :span="4">
        <el-button type="primary" @click="getList(1)">查询</el-button>
      </el-col>
    </el-row>

    <div>
      <el-button type="primary" @click="showAdd" v-auth="per.game_add">赛事申请</el-button>
      <el-button type="danger" @click="doDel(ids)" v-auth="per.game_delete">删除赛事</el-button>
      <el-button
        type="primary"
        @click="doAudit(ids, GAME_AUDIT_STATUS_CODE.PASS)"
        v-auth="per.game_list_audit"
      >
        审核赛事
      </el-button>
      <el-button
        type="danger"
        @click="doAudit(ids, GAME_AUDIT_STATUS_CODE.FAIL)"
        v-auth="per.game_list_audit"
      >
        驳回赛事
      </el-button>
    </div>

    <el-table border :data="dataSource" class="page-top-space" @selection-change="selectionChange">
      <el-table-column type="selection"></el-table-column>
      <el-table-column label="序号" type="index"></el-table-column>
      <el-table-column label="申请单位" prop="unitName" width="100px">
        <template slot-scope="scope">
          <span>{{ scope.row.unitName || scope.row.createdName || '-' }}</span>
        </template>
      </el-table-column>
      <el-table-column label="赛事级别" prop="matchLevel"></el-table-column>
      <el-table-column label="赛事名称" prop="gameNameCHN"></el-table-column>
      <el-table-column label="赛事地点" prop="gameSiteCHN"></el-table-column>
      <el-table-column label="赛事报名起止时间" prop="index" min-width="100px">
        <template slot-scope="scope">
          {{ scope.row.signUpBeginTime | dateFormat(null, 'YYYY-MM-DD') }} ~
          {{ scope.row.signUpEndTime | dateFormat(null, 'YYYY-MM-DD') }}
        </template>
      </el-table-column>

      <el-table-column label="赛事起止时间" prop="index" min-width="100px">
        <template slot-scope="scope">
          {{ scope.row.beginTime | dateFormat(null, 'YYYY-MM-DD') }} ~
          {{ scope.row.endTime | dateFormat(null, 'YYYY-MM-DD') }}
        </template>
      </el-table-column>

      <el-table-column label="比赛规程" prop="gameFile" width="100px">
        <template slot-scope="scope">
          <span
            v-if="scope.row.gameFile"
            class="option option-primary"
            @click="doDownLoad(scope.row.gameFile)"
            >规程下载</span
          >
          <span v-else>
            暂无规程
          </span>
        </template>
      </el-table-column>

      <el-table-column label="审核状态" prop="auditState">
        <template slot-scope="scope">
          <el-tooltip
            v-if="scope.row.auditContent"
            class="item"
            effect="dark"
            :content="`驳回理由：${scope.row.auditContent}`"
            placement="top-start"
          >
            <MyBadge :list="GAME_AUDIT_STATUS" :target="scope.row.auditState"></MyBadge>
          </el-tooltip>
          <MyBadge v-else :list="GAME_AUDIT_STATUS" :target="scope.row.auditState"></MyBadge>
        </template>
      </el-table-column>
      <el-table-column label="操作" prop="operation" fixed="right" min-width="150px">
        <template slot-scope="scope">
          <!-- 赛事申报员只有在未审核通过的时候能够修改赛事 -->
          <span
            class="option option-primary"
            @click="showEdit(scope.row)"
            v-if="
              userInfo.unitType === 'ALL' || GAME_AUDIT_STATUS_CODE.PASS !== scope.row.auditState
            "
            v-auth="per.game_update"
            >编辑</span
          >
          <span class="option option-danger" @click="doDel([scope.row.id])" v-auth="per.game_delete"
            >删除</span
          >
          <span
            class="option option-primary"
            v-auth="per.game_list_audit"
            @click="doAudit([scope.row.id], GAME_AUDIT_STATUS_CODE.PASS)"
            >通过审核</span
          >
          <span
            class="option option-danger"
            v-auth="per.game_list_audit"
            @click="doAudit([scope.row.id], GAME_AUDIT_STATUS_CODE.FAIL)"
            >驳回审核</span
          >
          <span
            class="option option-primary"
            v-if="
              scope.row.auditState === GAME_AUDIT_STATUS_CODE.FAIL && userInfo.unitType !== 'ALL'
            "
            @click="doReapplyAudit([scope.row.id])"
            >重新审核</span
          >
        </template>
      </el-table-column>
    </el-table>

    <el-pagination
      class="page-top-space"
      background
      :total="total"
      :page-size="listQuery.pageSize"
      :current-page.sync="listQuery.pageNo"
      @current-change="getList"
    >
    </el-pagination>
    <EditModal
      :ref="MODAL_KEY.EDIT_MODAL"
      :modalData="modalData"
      @submit="doSubmit"
      :modalType="modalType"
    ></EditModal>
  </div>
</template>

<script>
import {
  fetchGameList,
  gameAudit,
  delGame,
  batExportGame,
  exportGame,
  updateGame,
  addGame,
  reapplyAudit,
} from '@/api/game';
import {fetchUnitAll} from '@/api/unit';
import {
  CONFIRM_TYPE,
  GAME_AUDIT_STATUS,
  GAME_AUDIT_STATUS_CODE,
  MATCH_LEVEL_LIST,
} from '@/const/index';
import {exportAnchorFile} from '@/common/util';
import EditModal from './component/EditModal';

export default {
  components: {EditModal},
  data() {
    let userInfo = this.$store.getters.userInfo;
    let yearList = [];
    let start = 2018;
    let tar = new Date().getFullYear() + 2;
    yearList = new Array(tar - start).fill(start).map((item, index) => {
      return item + index;
    });
    return {
      matchLevelList: MATCH_LEVEL_LIST,
      yearList: yearList,
      userInfo: userInfo,
      MODAL_KEY: {
        EDIT_MODAL: 'EDIT_MODAL',
      },
      modalData: {},
      modalType: '',
      GAME_AUDIT_STATUS_CODE: GAME_AUDIT_STATUS_CODE,
      GAME_AUDIT_STATUS: GAME_AUDIT_STATUS,
      CONFIRM_TYPE: CONFIRM_TYPE,
      dataSource: [],
      total: 0,
      ids: [],
      unitList: [],
      listQuery: {
        pageNo: 1,
        pageSize: 10,
        dataSources: 2,
        unitId: userInfo.unitType === 'ALL' ? '' : userInfo.unitId,
        year: '2020',
      },
    };
  },
  methods: {
    selectionChange(selection) {
      this.ids = [];
      selection.map((item) => {
        this.ids.push(item.id);
      });
    },

    doReapplyAudit(ids) {
      reapplyAudit(ids).then((res) => {
        this.$message.success('提交成功');
        this.getList();
      });
    },

    getUnit() {
      fetchUnitAll().then((res) => {
        this.unitList = res.data.data;
      });
    },

    audit(ids, type, value) {
      let params = [];
      ids &&
        ids.map((item) => {
          params.push({
            id: item,
            auditState: type,
            auditContent: value || '',
          });
        });

      gameAudit(params).then((res) => {
        this.$message.success('操作成功!');
        this.getList();
      });
    },

    doAudit(ids, type) {
      if (this.validatenull(ids)) {
        this.$message.error('请选择数据');
        return;
      }
      let txt = type === GAME_AUDIT_STATUS_CODE.FAIL ? '驳回' : '通过';
      this.$confirm(`是否要${txt}审核`, '提示', {type: 'warning'}).then((res) => {
        if (type === GAME_AUDIT_STATUS_CODE.FAIL) {
          this.$prompt('请输入驳回理由', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
          }).then(({value}) => {
            this.audit(ids, type, value);
          });
        } else {
          this.audit(ids, type);
        }
      });
    },

    doDownLoad(url) {
      exportAnchorFile(this.loadUrl + '/api/resource/respource?path=' + url + '&isDownload=true');
    },

    getList(current) {
      if (!this.validatenull(current)) {
        this.listQuery.pageNo = current;
      }

      fetchGameList(this.listQuery).then((res) => {
        this.dataSource = res.data.data.results;
        this.total = res.data.data.total_record;
      });
    },

    showAdd() {
      this.modalType = 'add';
      this.modalData = {};
      this.$refs[this.MODAL_KEY.EDIT_MODAL].showModal();
    },

    doDel(ids) {
      if (this.validatenull(ids)) {
        this.$message.error('请选择数据进行操作');
        return;
      }

      this.$confirm('是否要删除赛事', '提示', {type: 'warning'}).then((res) => {
        delGame(ids).then((res) => {
          this.getList();
          this.$message.success('删除成功');
        });
      });
    },

    doBatExport(ids) {
      if (this.validatenull(ids)) {
        this.$message.error('请选择赛事再导出');
        return;
      }

      batExportGame({gameIds: ids}).then((res) => {
        apiDownLoadFile(
          res.data,
          'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
          '赛事选派名单.doc'
        );
      });
    },

    doExport(data) {
      exportGame({gameId: data.id}).then((res) => {
        apiDownLoadFile(
          res.data,
          'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
          data.gameNameCHN + '选派名单.doc'
        );
      });
    },

    goSelect(data) {
      this.$router.push(`/game/center/${data.id}`);
    },
    showEdit(data) {
      this.modalData = this.deepClone(data);
      this.$set(this.modalData, 'area', this.modalData.gameAreaCHN.split('/'));
      this.$set(this.modalData, 'date', [this.modalData.beginTime, this.modalData.endTime]);
      this.$set(this.modalData, 'signUpDate', [
        this.modalData.signUpBeginTime,
        this.modalData.signUpEndTime,
      ]);

      this.modalType = 'edit';
      this.$refs[this.MODAL_KEY.EDIT_MODAL].showModal();
    },

    doSubmit(data) {
      let result = addGame;
      if (!this.validatenull(data.id)) {
        result = updateGame;
      }

      result(data).then((res) => {
        this.$message.success('操作成功');
        this.getList();
        this.$refs[this.MODAL_KEY.EDIT_MODAL].closeModal();
      });
    },
  },

  mounted() {
    this.getList();
    this.getUnit();
  },
};
</script>
