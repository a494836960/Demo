<template>
    <div class="forget">
        <div class="forget-content">
            <el-steps :active="active" finish-status="success">
                <el-step title="账户验证" description="请输入注册时填写的手机号码，这是您的唯一认证号码">
                </el-step>
                <el-step title="手机号码认证" description="请输入收到的短信验证码">
                    <el-button @click="toEnd">确定</el-button>
                </el-step>
                <el-step title="重置完成" description="密码设置完成，重新登录"></el-step>
            </el-steps>

            <div v-if="active === 0">
                <el-form ref="stepForm" :model="step1" :rules="step1Rule" :hide-required-asterisk="true"
                         label-width="85px" style="margin-top: 20px;">
                    <el-form-item label="手机号码：" prop="mobile">
                        <el-input placeholder="请输入你的手机号码" v-model="step1.mobile"></el-input>
                    </el-form-item>

                    <el-form-item prop="code" label="验证码：">
                        <el-row>
                            <el-col :span="17">
                                <el-input type="text" size="large" v-model="step1.code"
                                          placeholder="请输入验证码">
                                </el-input>
                            </el-col>
                            <el-col :span="1">
                                &emsp;
                            </el-col>
                            <el-col :span="6">
                                <div @click="refreshCode" style="cursor: pointer;">
                                    <img :src="code+step1.pageid"
                                         style="height: 25px; vertical-align: middle;">
                                </div>
                            </el-col>
                        </el-row>
                    </el-form-item>
                    <el-form-item label="">
                        <el-button size="large" type="primary" @click="toTwo" long>确 定</el-button>
                    </el-form-item>
                </el-form>
            </div>

            <div v-else-if="active === 1">
                <el-form ref="step2Form" :model="step2" :rules="step2Rule" style="margin-top: 10px;"
                         :hide-required-asterisk="true"
                         label-width="85px">
                    <el-form-item prop="code" label="短信验证码：">
                        <el-row>
                            <el-col :span="17">
                                <el-input type="text" size="large" v-model="step2.code"
                                          placeholder="请输入验证码">
                                </el-input>
                            </el-col>
                            <el-col :span="1"></el-col>
                            <el-col :span="6">
                                <el-button type="primary" @click="sendMsg" :disabled="count != 0">{{verifyText}}
                                </el-button>
                            </el-col>
                        </el-row>
                    </el-form-item>

                    <el-form-item prop="password" label="密码：" key="1">
                        <el-input type="password" size="large" v-model="step2.password"
                                  placeholder="请输入密码">
                        </el-input>
                    </el-form-item>

                    <el-form-item prop="confirmPass" label="确认密码：" key="2">
                        <el-input type="password" size="large" v-model="step2.confirmPass"
                                  placeholder="请输入密码">
                        </el-input>
                    </el-form-item>

                    <el-form-item label="">
                        <el-button type="primary" @click="toEnd">确定</el-button>
                    </el-form-item>
                </el-form>

            </div>

            <div v-else="active === 2" class="finish">
                <p style=" margin-bottom: 20px;">密码重置成功</p>
                <el-button type="primary" @click="()=>{this.$router.push('/login')}">去登录</el-button>
            </div>

            <div class="text-r">
                <router-link to="/login">去登录</router-link>
            </div>
        </div>
    </div>
</template>

<script>
    import {generateUid, validatorForm} from '@/common/util';
    import {forgetIsMobile, forgetSendMsg, forgetUpdatePwd} from '@/api/common'
    import {ROLE, ACCOUNT_TYPE, ACCOUNT_TYPE_CODE} from '@/const/index'

    export default {
        data() {
            return {
                ROLE: ROLE,
                code: '/api/login/code?pageid=',
                ACCOUNT_TYPE: ACCOUNT_TYPE,
                active: 0,
                step1: {
                    pageid: generateUid(),
                },
                step1Rule: {
                    loginType: [{
                        required: true,
                        message: '请选择账号类型',
                        trigger: 'change'
                    }],
                    mobile: [
                        {required: true, message: "手机号码不能为空", trigger: "change"},
                        {validator: validatorForm.phone, trigger: 'change'}
                    ],
                    code: [
                        {required: true, message: "验证码不能为空", trigger: "change"}
                    ],
                },


                verifyText: '获取验证码',
                count: 0,
                step2: {
                    mobile: '',
                    pageid: generateUid(),
                },

                step2Rule: {
                    code: [
                        {required: true, message: "验证码不能为空", trigger: "change"}
                    ],
                    confirmPass: [
                        {required: true, message: "确认密码不能为空", trigger: "change"},
                        {
                            validator: (rule, val, callback) => {
                                if (val !== this.step2.password) {
                                    callback('两次密码输入不一致');
                                }
                                callback()
                            }, trigger: "change"
                        },
                    ],

                    password: [
                        {required: true, message: "密码不能为空", trigger: "change"},
                        {min: 6, message: "密码至少6位", trigger: "change"},
                    ],

                }
            };
        },
        methods: {
            refreshCode() {
                this.step1.code = '';
                this.step1.pageid = generateUid();
            },

            sendMsg() {
                let params = {
                    mobile: this.step2.mobile,
                    pageid: this.step2.pageid,
                    loginType: this.step2.loginType,
                }
                forgetSendMsg(params).then(res => {
                    this.startInterval(60);
                })
            },

            toTwo() {
                this.$refs.stepForm.validate(res => {
                    if (res) {
                        forgetIsMobile(this.step1).then(res => {
                            this.active++;
                            this.step2.loginType = this.step1.loginType;
                            this.step2.mobile = this.step1.mobile;
                        })
                    }
                })
            },
            toEnd() {
                this.$refs.step2Form.validate(res => {
                    if (res) {
                        forgetUpdatePwd(this.step2).then(res => {
                            this.active++;
                        });
                    }
                })
            },

            startInterval(time) {
                this.endInterVal();
                this.count = time;

                this.timer = setInterval(() => {
                    if (this.count > 0) {
                        this.count--;
                        this.verifyText = this.count;
                    } else {
                        this.verifyText = '获取验证码';
                        this.endInterVal();
                    }
                }, 1000)
            },

            endInterVal() {
                clearInterval(this.timer)
            },
        },
        mounted() {
            let type = this.$router.history.current.query.type;
            if(type === 'personal'){
                this.step1.loginType = ACCOUNT_TYPE_CODE.PERSONAL
            } else {
                this.step1.loginType = ACCOUNT_TYPE_CODE.UNIT
            }
            if (this.$store.state.user.userType === ROLE.APPLY) {
                this.step1.loginType = ACCOUNT_TYPE_CODE.UNIT;
            }
        }
    }
</script>

<style lang="less" scoped>
    .forget {
        background: url("../../../assets/image/login_bg.png") 100%;
        border-radius: 5px;
        padding: 10px;

        .forget-content {
            background: #fff;
            padding: 20px 30px;
            border-radius: 5px;
        }
    }

    .finish {
        height: 500px;
        padding-top: 200px;
        text-align: center;
        font-size: 24px;
        color: #55D5BE;

    }
</style>
