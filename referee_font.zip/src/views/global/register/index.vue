<template>
    <div>
        <div class="login-body">
            <div class="login-content">
                <div class="login-right">
                    <div class="box-login-line">
                        <div class="login-form">
                            <div class="title">
                                裁判员注册
                            </div>
                            <el-form ref="loginForm" :model="loginForm" :rules="loginRules" style="margin-top: 10px;"
                                     :hide-required-asterisk="true"
                                     label-width="85px"
                                     @keyup.enter.native="handleSubmit">
                                <el-form-item prop="mobile" label="手机号：">
                                    <el-input v-model='loginForm.mobile' placeholder="请输入手机号" :maxLength="11"></el-input>
                                </el-form-item>

                                <el-form-item prop="idcard" label="身份证号：">
                                    <el-input v-model='loginForm.idcard' placeholder="请输入身份证号"></el-input>
                                </el-form-item>

                                <el-form-item prop="code" label="短信验证码：">
                                    <el-row>
                                        <el-col :span="17">
                                            <el-input type="text" size="large" v-model="loginForm.code"
                                                      placeholder="请输入验证码">
                                            </el-input>
                                        </el-col>
                                        <el-col :span="1">
                                            &emsp;
                                        </el-col>
                                        <el-col :span="6">
                                            <el-button type="primary" @click="sendMsg" :disabled="count != 0">{{verifyText}}</el-button>
                                        </el-col>
                                    </el-row>
                                </el-form-item>

                                <el-form-item prop="password" label="密码：">
                                    <el-input type="password" size="large" v-model="loginForm.password"
                                              placeholder="请输入密码">
                                    </el-input>
                                </el-form-item>

                                <el-form-item prop="confirmPass" label="确认密码：">
                                    <el-input type="password" size="large" v-model="loginForm.confirmPass"
                                              placeholder="请输入密码">
                                    </el-input>
                                </el-form-item>

                                <el-button style="width: 100%;" size="large" type="primary" @click="handleSubmit" long>注
                                    册
                                </el-button>
                            </el-form>
                            <div style="margin-top: 10px;">
                                <router-link class="float-r" to="/login">有账号，去登录？</router-link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import {validatorForm, generateUid} from '@/common/util';
    import {register, sendRegisterMsg} from '@/api/common'

    export default {
        data() {
            return {
                verifyText: '获取验证码',
                count:0,
                loginForm: {
                    pageid: generateUid()
                },
                loginRules: {
                    mobile: [
                        {required: true, message: "手机号码不能为空", trigger: "change"},
                        {validator: validatorForm.phone, trigger: 'change'}
                    ],

                    code: [
                        {required: true, message: "验证码不能为空", trigger: "change"}
                    ],

                    password: [
                        {required: true, message: "密码不能为空", trigger: "change"},
                        {min: 6, message: "密码至少6位", trigger: "change"},
                    ],

                    confirmPass: [
                        {required: true, message: "密码不能为空", trigger: "change"},
                        {
                            validator: (rule, val, callback) => {
                                if (val !== this.loginForm.password) {
                                    callback('两次密码输入不一致');
                                }
                                callback()
                            }, trigger: "change"
                        },
                    ],

                    idcard: [
                        {required: true, message: "身份证号不能为空", trigger: "change"},
                        {
                            validator: (rule, val, callback) => {
                                if (!/^[1-9][0-9]{5}([1][9][0-9]{2}|[2][0][0|1][0-9])([0][1-9]|[1][0|1|2])([0][1-9]|[1|2][0-9]|[3][0|1])[0-9]{3}([0-9]|[X|x])$/.test(val)) {
                                    callback('请输入正确的身份证号！');
                                }
                                callback();
                            }, trigger: "change"
                        },
                    ]
                }
            };
        },
        methods: {
            sendMsg() {
                let count = 0;
                this.$refs.loginForm.validateField(['mobile', 'idcard'], (res) => {
                    if (this.validatenull(res)) {
                        count++;
                    }
                });
                if(count != 2){
                    return;
                }

                let params = {
                    mobile: this.loginForm.mobile,
                    pageid: this.loginForm.pageid,
                    idcard: this.loginForm.idcard,
                }
                sendRegisterMsg(params).then(res=>{
                    this.startInterval(60);
                })
            },

            startInterval(time) {
                this.endInterVal();
                this.count = time;

                this.timer = setInterval(() => {
                    if (this.count > 0) {
                        this.count--;
                        this.verifyText = this.count;
                    } else {
                        this.verifyText = '获取验证码';
                        this.endInterVal();
                    }
                }, 1000)
            },

            endInterVal() {
                clearInterval(this.timer)
            },

            handleSubmit() {
                this.$refs.loginForm.validate(valid => {
                    if (valid) {
                        register(this.loginForm).then(res => {
                            this.$message.success('注册成功');
                            this.$router.push('/login');
                        })
                    }
                })
            },
        },

        mounted() {

        }
    };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">

    .refresh {
        display: inline-block;
        width: 25px;
        height: 25px;
        background: #cccccc;
        color: #505050;
        font-size: 16px;
        text-align: center;
        line-height: 25px;
    }

    .footer {
        text-align: center;
        line-height: 25px;
        width: 100%;
        position: fixed;
        bottom: 0;
        left: 0;

        span {
            margin-left: 15px;
        }
    }

    .login-nav {
        overflow: hidden;
        height: 30px;
        line-height: 28px;

        .login-nav-item {
            width: 50%;
            float: left;
            border-bottom: 2px solid #f1f1f1;
            text-align: center;

            span {
                padding: 0 10px;
                display: inline-block;
                height: 28px;
                cursor: pointer;
            }

            &.active {
                span {
                    border-bottom: 2px solid #4ef1eb;
                }
            }
        }
    }

    .title {
        text-align: center;
        font-size: 20px;
        margin-bottom: 25px;
    }

    .login-body {
        background-repeat: no-repeat;
        background-size: 100% 100%;
        height: auto;
        overflow: hidden;
        padding-top: 4%;
        min-width: 1150px;

        .login-content {
            overflow: hidden;
            position: relative;
            width: 1150px;
            margin: 0 auto;
            background: url("../../../assets/image/pic.png") 50% bottom no-repeat;
            background-size: 25%;
        }

        .box-login-line {
            background: url("../../../assets/image/login_bg.png") 100%;
            border-radius: 5px;
            padding: 10px;
            width: 750px;
            margin: auto;
        }

        .login-form {
            background: #fff;
            border-radius: 5px;
            padding: 20px 50px 30px;
            margin: auto;
        }
    }
</style>
