<template>
    <div>
        <div class="login-body">
            <div class="login-content">
                <div class="login-left">
                    <img src="@/assets/image/pic2.png" alt="run">
                </div>
                <div class="login-right">
                    <div class="box-login-line">
                        <div class="login-form">
                            <ul class="login-nav">
                                <li class="login-nav-item" :class="tabType.unit === activeTab?'active': ''"
                                    @click="handleClick(tabType.unit)">
                                    <span>单位登录</span>
                                </li>
                                <li class="login-nav-item" :class="tabType.personal === activeTab?'active': ''"
                                    @click="handleClick(tabType.personal)">
                                    <span>个人登录</span>
                                </li>
                            </ul>

                            <el-form ref="loginForm" :model="loginForm" :rules="loginRules" style="margin-top: 10px;"
                                     :hide-required-asterisk="true"
                                     label-width="70px"
                                     @keyup.enter.native="handleSubmit('formInline')">
                                <el-form-item prop="username" :label="tabType.personal === activeTab?'手机号：':'用户名：'" v-if="!isMsgLogin">
                                    <el-input v-model='loginForm.username' placeholder="请输入用户名或手机号"></el-input>
                                </el-form-item>

                                <el-form-item prop="mobile_code" label="手机号：" v-if="isMsgLogin">
                                    <el-input v-model='loginForm.mobile_code' placeholder="请输入手机号码"></el-input>
                                </el-form-item>

                                <el-form-item prop="code" label="验证码：" v-if="isMsgLogin">
                                    <el-row>
                                        <el-col :span="12">
                                            <el-input type="text" size="large" v-model="loginForm.code"
                                                      placeholder="请输入验证码">
                                            </el-input>
                                        </el-col>
                                        <el-col :span="11" :offset="1" class="text-r">
                                            <el-button type="primary" @click="sendMsg" :disabled="count != 0">
                                                {{verifyText}}
                                            </el-button>
                                        </el-col>
                                    </el-row>
                                </el-form-item>

                                <el-form-item prop="password" label="密码：" v-if="!isMsgLogin">
                                    <el-input type="password" size="large" v-model="loginForm.password"
                                              placeholder="请输入密码">
                                    </el-input>
                                </el-form-item>

                                <el-form-item prop="code" label="验证码：" v-if="!isMsgLogin">
                                    <el-row>
                                        <el-col :span="10">
                                            <el-input type="text" size="large" v-model="loginForm.code" maxLength="4"
                                                      placeholder="请输入验证码">
                                            </el-input>
                                        </el-col>

                                        <el-col :offset="2" :span="10">
                                            <div @click="refreshCode">
                                                <VerifyCode :pageid="loginForm.pageid"></VerifyCode>
                                            </div>
                                        </el-col>
                                    </el-row>
                                </el-form-item>
                                <div style="text-align: left;height: 24px;line-height: 0;">
                                    <span style="color: #999;cursor: pointer;" @click="switchLogin">{{isMsgLogin? '用户名登录': '短信登录'}}</span>

                                    <router-link
                                            v-if="curDate<regEnd && curDate>regStart && tabType.personal === activeTab"
                                            style="color: #999;margin-left: 75px;"
                                            to="/register">没有账号？去注册
                                    </router-link>

                                    <router-link class="float-r" :to="{path:'/forget', query: {type: activeTab}}"
                                                 style="color: #999;">忘记密码
                                    </router-link>
                                </div>
                                <el-button style="width: 100%;" size="large" type="primary"
                                           @click="handleSubmit" long>登 录
                                </el-button>
                            </el-form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import {registerState} from '@/api/common.js';
    import {generateUid} from '@/common/util';
    import {loginVerify} from '@/api/user';

    export default {
        data() {
            let tabType = {
                unit: 'unit',
                personal: 'personal'
            };
            return {
                isMsgLogin: false, // 短信登录， 账号密码登录
                verifyText: '获取验证码',
                count: 0,

                curDate: +new Date(),
                tabType: tabType,
                activeTab: tabType.personal,
                regStart: '',
                regEnd: '',
                userList: [],
                loginForm: {
                    username: "",
                    password: "",
                    mobile_code: '',
                    code: '',
                    pageid: ''
                },
                loginRules: {
                    mobile_code: {
                        required: true,
                        message: '手机号码不能为空',
                        trigger: 'blur'
                    },
                    username: [
                        {required: true, message: "用户名不能为空", trigger: "change"}
                    ],
                    password: [{required: true, message: "密码不能为空", trigger: "blur"}],
                    code: [
                        {required: true, message: "请输入验证码", trigger: "blur"},
                        {min: 4, max: 6, message: "请输入正确的验证码", trigger: "blur"}
                    ]
                }
            };
        },
        methods: {
            switchLogin() {
                this.isMsgLogin = !this.isMsgLogin;
                this.refreshCode();
                this.loginForm.username = '';
                this.loginForm.mobile_code = '';
                this.loginForm.password = '';
                this.$nextTick(() => {
                    this.$refs.loginForm.clearValidate();
                })

            },
            refreshCode() {
                this.loginForm.code = '';
                this.loginForm.pageid = generateUid();
            },

            sendMsg() {
                if (this.tabType.unit === this.activeTab) { //单位登录
                    this.loginForm.loginType = 0;
                } else { //个人登录
                    this.loginForm.loginType = 1;
                }

                this.$refs.loginForm.validateField('mobile_code', valid => {
                    if (this.validatenull(valid)) {
                        let params = {
                            mobile: this.loginForm.mobile_code,
                            loginType: this.loginForm.loginType,
                        }
                        loginVerify(params).then(res => {
                            this.startInterval(60);
                        })
                    }
                })
            },

            endInterVal() {
                clearInterval(this.timer)
            },

            startInterval(time) {
                this.endInterVal();
                this.count = time;

                this.timer = setInterval(() => {
                    if (this.count > 0) {
                        this.count--;
                        this.verifyText = this.count;
                    } else {
                        this.verifyText = '获取验证码';
                        this.endInterVal();
                    }
                }, 1000)
            },

            handleSubmit() {
                this.$refs.loginForm.validate(valid => {
                    if (valid) {
                        if (this.tabType.unit === this.activeTab) { //单位登录
                            this.loginForm.loginType = 0;
                        } else { //个人登录
                            this.loginForm.loginType = 1;
                        }
                        this.$store.dispatch('LoginByUsername', this.loginForm).then(res => {
                            if (this.validatenull(this.$store.getters.permissions)) {
                                this.$message.error('该账号暂时没有权限进入，请联系管理员！');
                                return;
                            }
                            let menu = this.$store.state.user.menu;
                            if (menu[0]) {
                                this.$router.push(menu[0].children[0].path);
                            } else {
                                this.$message.error('没有权限进入！请联系管理员');
                            }
                        });
                    }
                })
            },
            handleClick(tab) { // 切换tab
                this.activeTab = tab;
                this.loginForm.username = '';
            },
            getRegisterState() {
                registerState().then(res => {
                    this.regStart = res.data.data.registerBeginTime;
                    this.regEnd = res.data.data.registerEndTime;
                })
            }
        },
        destroyed(){
          this.endInterVal();
        },
        mounted() {
            this.$store.commit('SET_USER_TYPE', 'OTHER');
        },
        created() {
            this.getRegisterState();
            this.refreshCode();
        }
    };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">

    .refresh {
        display: inline-block;
        width: 25px;
        height: 25px;
        background: #cccccc;
        color: #505050;
        font-size: 16px;
        text-align: center;
        line-height: 25px;
    }

    .footer {
        text-align: center;
        line-height: 25px;
        width: 100%;
        position: fixed;
        bottom: 0;
        left: 0;

        span {
            margin-left: 15px;
        }
    }

    .login-nav {
        overflow: hidden;
        height: 30px;
        line-height: 28px;

        .login-nav-item {
            width: 50%;
            float: left;
            border-bottom: 2px solid #f1f1f1;
            text-align: center;

            span {
                padding: 0 10px;
                display: inline-block;
                height: 28px;
                cursor: pointer;
            }

            &.active {
                span {
                    border-bottom: 2px solid #4ef1eb;
                }
            }
        }
    }

    .login-body {
        background-repeat: no-repeat;
        background-size: 100% 100%;
        height: auto;
        overflow: hidden;
        padding-top: 4%;
        min-width: 1150px;

        .login-content {
            overflow: hidden;
            position: relative;
            width: 1150px;
            margin: 0 auto;
            background-size: 25%;
        }

        .login-left {
            float: left;
        }

        .login-right {
            float: right;

            .box-login-line {
                background: url("../../../assets/image/login_bg.png") 100%;
                border-radius: 5px;
                padding: 10px;
            }

            .login-form {
                background: #fff;
                border-radius: 5px;
                width: 360px;
                padding: 10px 15px 30px 10px;
            }
        }
    }
</style>
