<template>
    <div>
        <div>
            <el-button type="primary" @click="doExport" v-auth="per.statistics_level_export">报表导出</el-button>
        </div>
        <el-table height="80vh" border :data="dataSource" class="page-top-space"
                  row-class-name="table-row">
            <el-table-column fixed label="单位" prop="name"></el-table-column>
            <el-table-column v-for="(item, index) in headers" :label="item" :key="index">
                <el-table-column label="男">
                    <template slot-scope="scope">
                        {{scope.row.itemList[index].man}}
                    </template>
                </el-table-column>

                <el-table-column label="女">
                    <template slot-scope="scope">
                        {{scope.row.itemList[index].woman}}
                    </template>
                </el-table-column>

                <el-table-column label="小计">
                    <template slot-scope="scope">
                        {{scope.row.itemList[index].total}}
                    </template>
                </el-table-column>
            </el-table-column>
        </el-table>
    </div>
</template>

<script>
    import {
        fetchRefereeLevel,
        exportRefereeLevel
    } from '@/api/statistics';
    import {exportFile} from "@/common/util";

    export default {
        data() {
            return {
                dataSource: [],
                headers: [],
            }
        },
        methods: {
            doExport() {
                exportRefereeLevel().then(res => {
                    exportFile(res.data, '裁判员等级报表');
                })
            },

            getList() {
                fetchRefereeLevel().then(res => {
                    this.dataSource = res.data.data.body;
                    this.headers = res.data.data.header;
                })
            }
        },

        mounted() {
            this.getList();
        }
    }
</script>
