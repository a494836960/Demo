<template>
  <div>
    <el-row :gutter="20" class="search-box">
      <el-col :span="4" v-if="userInfo.unitType === 'ALL'">
        <el-select
          placeholder="请选择单位"
          @change="getList(1)"
          v-model="listQuery.unitId"
          filterable
          clearable
        >
          <el-option
            v-for="(item, index) in unitList"
            :key="index"
            :value="item.id"
            :label="item.cnName"
          ></el-option>
        </el-select>
      </el-col>

      <el-col :span="4">
        <el-select
          placeholder="请选择赛事"
          @change="getList(1)"
          v-model="listQuery.gameId"
          filterable
          clearable
        >
          <el-option
            v-for="(item, index) in gameList"
            :key="index"
            :value="item.id"
            :label="item.gameNameCHN"
          ></el-option>
        </el-select>
      </el-col>

      <el-col :span="4">
        <el-button type="primary" @click="getList(1)">查询</el-button>
      </el-col>
    </el-row>
    <div>
      <el-button class="but" type="primary" @click="showAddGame" v-auth="per.cultivate_unit_add"
        >新增</el-button
      >
      <el-button class="but" type="danger" @click="doDel(ids)" v-auth="per.cultivate_unit_delete"
        >删除</el-button
      >
    </div>
    <el-table
      border
      :data="dataSource"
      class="page-top-space"
      row-class-name="table-row"
      @selection-change="selectionChange"
    >
      <el-table-column type="selection"></el-table-column>
      <el-table-column label="序号" type="index"></el-table-column>
      <el-table-column label="单位名称" prop="unitName"></el-table-column>
      <el-table-column label="培训名称" prop="gameName"></el-table-column>
      <el-table-column label="报名人数" prop="recommendNum"></el-table-column>
      <el-table-column label="人数限制" prop="recommendNumLimit">
        <template slot-scope="scope">
          <div>
            <el-input
              :ref="`isEditInput${scope.$index}`"
              v-model="scope.row.recommendNumLimit"
              v-if="scope.row.isEdit"
              placeholder="请输入人数限制"
            >
              <el-button slot="append" @click="doUpdate(scope.row)">确定</el-button>
            </el-input>
            <span v-else>{{ scope.row.recommendNumLimit }}</span>
          </div>
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <span
            class="option option-primary"
            @click="showEditGame(scope.row, scope.$index)"
            v-auth="per.cultivate_unit_add"
            >编辑</span
          >
          <span
            class="option option-primary"
            @click="goReferee(scope.row)"
            v-auth="per.cultivate_referee_manage"
            >报名人员</span
          >
          <span
            class="option option-danger"
            @click="doDel([scope.row.id])"
            v-auth="per.cultivate_unit_delete"
            >删除</span
          >
        </template>
      </el-table-column>
    </el-table>

    <el-pagination
      class="page-top-space"
      background
      :total="total"
      :page-size="listQuery.size"
      :current-page.sync="listQuery.current"
      @current-change="getList"
    ></el-pagination>

    <EditModal
      :ref="MODAL_KEY.EDIT_MODAL"
      :modal-data="modalData"
      :unitList="unitList"
      :gameList="gameList"
      @submit="doSubmit"
    ></EditModal>
  </div>
</template>

<script>
import {fetchUnit, addUnit, updateUnit, delUnit} from '@/api/cultivate';
import EditModal from './component/EditModal';
import {IS_OPEN, GAME_SOURCE} from '@/const/index';
import {fetchUnitAll} from '@/api/unit';
import {fetchGameAll} from '@/api/game';

export default {
  components: {EditModal},
  data() {
    let userInfo = this.$store.getters.userInfo;
    return {
      userInfo: userInfo,
      IS_OPEN: IS_OPEN,
      MODAL_KEY: {
        EDIT_MODAL: 'EDIT_MODAL'
      },
      imgUrl: this.imgUrl,
      listQuery: {
        current: 1,
        size: 10,
        gameId: '',
        unitId: userInfo.unitType === 'ALL' ? '' : userInfo.unitId
      },
      total: 0,
      gameList: [],
      dataSource: [],
      unitList: [],
      modalData: {},
      modalType: '',
      ids: []
    };
  },
  methods: {
    selectionChange(selection) {
      this.ids = [];
      selection.map((item) => {
        this.ids.push(item.id);
      });
    },

    goReferee(row) {
      this.$router.push({
        path: '/cultivate/referee',
        query: {gameId: row.gameId, unitId: row.unitId}
      });
    },

    showAddGame() {
      this.modalData = {};
      this.modalType = 'add';
      this.$refs[this.MODAL_KEY.EDIT_MODAL].showModal();
    },

    doDelGame(data) {
      this.$confirm('是否要删除赛事', '提示', {type: 'warning'}).then((res) => {
        delUnit({id: data.id}).then((res) => {
          this.$message.success('删除成功');
          this.getList();
        });
      });
    },

    doUpdate(row) {
      updateUnit({id: row.id, recommendNumLimit: row.recommendNumLimit}).then((res) => {
        this.$message.success('修改成功');
        this.$set(row, 'isEdit', false);
      });
    },

    doDel(ids) {
      if (ids.length === 0) {
        this.$message.error('请选择要删除的数据');
        return;
      }
      this.$confirm('是否要删除单位', '提示', {type: 'warning'}).then((res) => {
        delUnit(ids).then((res) => {
          this.$message.success('删除成功');
          this.getList();
        });
      });
    },

    showEditGame(row, index) {
      this.$set(row, 'isEdit', true);
      this.$nextTick(() => {
        this.$refs['isEditInput' + index].focus();
      });
    },

    doSubmit(data) {
      let params = [];
      data.ids.map((item) => {
        params.push({
          gameId: data.gameId,
          unitId: item.id,
          recommendNumLimit: item.recommendNumLimit
        });
      });

      addUnit(params).then((res) => {
        this.$message.success('添加成功');
        this.$refs[this.MODAL_KEY.EDIT_MODAL].closeModal();
        this.getList();
      });
    },

    getList(current) {
      if (!this.validatenull(current)) {
        this.listQuery.pageNo = current;
      }

      fetchUnit(this.listQuery).then((res) => {
        this.total = Number(res.data.data.total);
        this.dataSource = res.data.data.records.filter((item, index) => {
          item.isEdit = false;
          return true;
        });
      });
    },

    getUnitAll() {
      fetchUnitAll().then((res) => {
        this.unitList = res.data.data;
      });
    },

    getGameList() {
      fetchGameAll([GAME_SOURCE.CULTIVATE_APPLY]).then((res) => {
        this.gameList = res.data.data;
      });
    }
  },

  mounted() {
    // 单位指定unitId
    this.listQuery.gameId = this.$router.history.current.query.gameId;
    this.getList();
    this.getUnitAll();
    this.getGameList();
  }
};
</script>
