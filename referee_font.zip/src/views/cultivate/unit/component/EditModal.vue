<template>
    <el-dialog
            title="培训单位管理"
            :close-on-click-modal="isClickModalClose"
            :visible.sync="isShow"
            :width="defaultWidth"
            @close="closeModal"
    >
        <el-form :ref="formName" :model="modalData" :rules="ruleValidate" label-width="110px">
            <el-form-item label="培训：" prop="gameId">
                <el-select placeholder="请选择培训" v-model="modalData.gameId" filterable clearable>
                    <el-option v-for="(item,index) in gameList" :key="index" :value="item.id"
                               :label="item.gameNameCHN"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="单位：">
                <div style="border-bottom: 1px solid #e9e9e9;padding-bottom:6px;margin-bottom:6px;">
                    <el-checkbox :indeterminate="indeterminate"
                                 :value="checkAll"
                                 @change="handleCheckAll">全选
                        <el-input style="width: 100px;margin-left: 10px;" v-model="limit" @input="changeLimit"
                                  placeholder="限报人数"></el-input>
                    </el-checkbox>
                </div>

                <el-checkbox :label="item.id" v-model="item.selectId" v-for="(item,index) in units" :key="index"
                             @change="checkAllGroupChange">
                    <span style="width: 75px;display: inline-block;">{{item.name}}</span>
                    <el-input style="width: 100px;margin-left: 10px;" v-model="item.recommendNumLimit"
                              placeholder="请输入限报人数"></el-input>
                </el-checkbox>
            </el-form-item>
        </el-form>

        <div slot="footer">
            <el-button @click="closeModal">
                取消
            </el-button>

            <el-button @click="submit" type="primary">
                确定
            </el-button>
        </div>
    </el-dialog>
</template>

<script>
    import modalMixin from '@/mixins/modalMixin';

    export default {
        mixins: [modalMixin],
        props: ['unitList', 'gameList'],
        data() {
            return {
                indeterminate: false,
                checkAll: false,
                limit: '',
                modalData: {
                    ids: []
                },
                units: [],
                formName: 'form',
                ruleValidate: {
                    gameId: [{
                        required: true,
                        message: '请选择培训',
                        trigger: 'change'
                    }],
                    ids: [{
                        required: true,
                        message: '请选择要添加的单位',
                        trigger: 'change'
                    }],
                    recommendNumLimit: [{
                        required: true,
                        message: '请输入限报人数',
                        trigger: 'blur'
                    }]
                }
            };
        },
        methods: {
            showModal() {
                this.isShow = true;
                this.$nextTick(() => {
                    this.indeterminate = false;
                    this.checkAll = false;
                    this.units = [];
                    this.unitList && this.unitList.map(item => {
                        this.units.push({
                            id: item.id,
                            selectId: false,
                            recommendNumLimit: '',
                            name: item.cnName
                        })
                    })
                });
            },

            changeLimit() {
                this.units.map(item => {
                    item.recommendNumLimit = this.limit;
                })
            },
            handleCheckAll() {
                if (this.indeterminate) {
                    this.checkAll = false;
                } else {
                    this.checkAll = !this.checkAll;
                }
                this.indeterminate = false;

                this.units.map((item, index) => {
                    item.selectId = this.checkAll;
                })

            },

            checkAllGroupChange(data) {
                let ids = this.units.filter(item => {
                    return item.selectId;
                })
                if (ids.length === this.units.length) {
                    this.indeterminate = false;
                    this.checkAll = true;
                } else if (ids.length > 0) {
                    this.indeterminate = true;
                    this.checkAll = false;
                } else {
                    this.indeterminate = false;
                    this.checkAll = false;
                }
            },

            submit() {
                this.validateForm().then(res => {
                    let ids = this.units.filter(item=>{
                        return item.selectId;
                    })

                    this.modalData.ids = ids;
                    this.$emit('submit', this.modalData);
                })
            },
        },

    }
</script>
