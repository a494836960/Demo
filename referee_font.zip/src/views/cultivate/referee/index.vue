<template>
  <div>
    <el-row :gutter="20" class="search-box">
      <el-col :span="4" v-if="userInfo.unitType === 'ALL'">
        <el-select
          placeholder="请选择单位"
          @change="getList(1)"
          v-model="listQuery.unitId"
          filterable
          clearable
        >
          <el-option
            v-for="(item, index) in unitList"
            :key="index"
            :value="item.id"
            :label="item.cnName"
          ></el-option>
        </el-select>
      </el-col>

      <el-col :span="4">
        <el-select
          placeholder="请选择赛事"
          @change="getList(1)"
          v-model="listQuery.newsNoticeId"
          filterable
          clearable
        >
          <el-option
            v-for="(item, index) in newsList"
            :key="index"
            :value="item.id"
            :label="item.nameTile"
          ></el-option>
        </el-select>
      </el-col>

      <el-col :span="4">
        <el-select
          placeholder="审核状态"
          @change="getList(1)"
          v-model="listQuery.unitCheckStatus"
          filterable
          clearable
        >
          <el-option
            v-for="(item, index) in CULTIVATE_REFEREE_STATUS"
            :key="index"
            :value="item.value"
            :label="item.name"
          ></el-option>
        </el-select>
      </el-col>

      <el-col :span="3">
        <el-button type="primary" @click="getList(1)">查询</el-button>
      </el-col>
    </el-row>
    <div>
      <el-button class="but" type="primary" @click="showAddGame" v-auth="per.cultivate_referee_add"
        >新增
      </el-button>

      <el-button
        class="but"
        type="primary"
        v-auth="per.cultivate_referee_audit"
        @click="doAudit(ids, CULTIVATE_REFEREE_STATUS_CODE.SUCCESS)"
        >通过申请
      </el-button>
      <el-button
        class="but"
        type="danger"
        v-auth="per.cultivate_referee_audit"
        @click="doAudit(ids, CULTIVATE_REFEREE_STATUS_CODE.FAIL)"
        >驳回申请
      </el-button>

      <el-button
        class="but"
        type="primary"
        @click="showExport"
        v-auth="per.cultivate_referee_load_package"
      >
        导出扫描件
      </el-button>
      <el-button class="but" type="info" @click="loadTemplate">登记模板</el-button>
    </div>
    <el-table
      border
      :data="dataSource"
      class="page-top-space"
      row-class-name="table-row"
      @selection-change="selectionChange"
    >
      <el-table-column type="selection"></el-table-column>
      <el-table-column label="序号" type="index"></el-table-column>
      <el-table-column label="报名人名称" prop="cnName"></el-table-column>
      <el-table-column label="单位名称" prop="unitName"></el-table-column>
      <el-table-column label="培训名称" prop="gameNameCHN"></el-table-column>
      <el-table-column label="审核状态" prop="unitCheckStatus">
        <template slot-scope="scope">
          <MyBadge :list="CULTIVATE_REFEREE_STATUS" :target="scope.row.unitCheckStatus"></MyBadge>
          <span
            v-if="
              scope.row.auditExplain &&
                scope.row.unitCheckStatus === CULTIVATE_REFEREE_STATUS_CODE.FAIL
            "
            >（{{ scope.row.auditExplain }}）</span
          >
        </template>
      </el-table-column>
      <el-table-column prop="reportFile" label="登记表扫描件">
        <template slot-scope="scope">
          <img
            v-if="scope.row.reportFile"
            width="80px"
            :src="imgUrl + scope.row.reportFile"
            @click="preImg(scope.row.reportFile)"
            alt="登记表"
            style="cursor: pointer;"
          />
        </template>
      </el-table-column>

      <el-table-column prop="levelPhotoPath" label="证书扫描件">
        <template slot-scope="scope">
          <span class="option option-primary" @click="preImg(scope.row.levelPhotoPath)"
            >查看证书</span
          >
        </template>
      </el-table-column>

      <el-table-column label="操作" prop="operation">
        <template slot-scope="scope">
          <span
            class="option option-primary"
            v-auth="per.cultivate_referee_audit"
            @click="doAudit([scope.row.id], CULTIVATE_REFEREE_STATUS_CODE.SUCCESS)"
          >
            通过申请
          </span>

          <span
            class="option option-primary"
            v-auth="per.cultivate_referee_audit"
            @click="doAudit([scope.row.id], CULTIVATE_REFEREE_STATUS_CODE.FAIL)"
          >
            驳回申请
          </span>

          <span
            class="option option-danger"
            @click="doDel(scope.row.id)"
            v-auth="per.cultivate_referee_delete"
            >删除</span
          >
        </template>
      </el-table-column>
    </el-table>

    <el-pagination
      class="page-top-space"
      background
      :total="total"
      :page-size="listQuery.size"
      :current-page.sync="listQuery.current"
      @current-change="getList"
    ></el-pagination>

    <EditModal
      :ref="MODAL_KEY.EDIT_MODAL"
      :modal-data="modalData"
      :gameList="gameList"
      @submit="doSubmit"
    ></EditModal>
    <PreviewImg :ref="MODAL_KEY.PREVIEW_IMG" :url="url"></PreviewImg>
    <ExportScanModal
      :ref="MODAL_KEY.EXPORT_SCAN"
      @submit="doExport"
      :gameList="gameList"
    ></ExportScanModal>
  </div>
</template>

<script>
import {
  fetchCultivateReferee,
  addGameReferee,
  delGameReferee,
  updateGameReferee,
  audit,
  fetchCultivate,
} from '@/api/cultivate';
import EditModal from './component/EditModal';
import {
  IS_OPEN,
  GAME_SOURCE,
  CULTIVATE_REFEREE_STATUS_CODE,
  CULTIVATE_REFEREE_STATUS,
} from '@/const/index';
import {fetchUnitAll} from '@/api/unit';
import {exportAnchorFile} from '@/common/util';
import PreviewImg from '@/components/previewImg';
import ExportScanModal from './component/ExportScanModal';

export default {
  components: {EditModal, PreviewImg, ExportScanModal},
  data() {
    let userInfo = this.$store.getters.userInfo;
    return {
      url: '',
      userInfo: userInfo,
      CULTIVATE_REFEREE_STATUS: CULTIVATE_REFEREE_STATUS,
      CULTIVATE_REFEREE_STATUS_CODE: CULTIVATE_REFEREE_STATUS_CODE,
      MODAL_KEY: {
        PREVIEW_IMG: 'PREVIEW_IMG',
        EDIT_MODAL: 'EDIT_MODAL',
        EXPORT_SCAN: 'EXPORT_SCAN',
      },
      IS_OPEN: IS_OPEN,

      imgUrl: this.imgUrl,
      listQuery: {
        current: 1,
        size: 10,
        newsNoticeId: '',
        unitId: userInfo.unitType === 'ALL' ? '' : userInfo.unitId,
      },
      total: 0,
      gameList: [],
      dataSource: [],
      unitList: [],
      modalData: {},
      modalType: '',
      ids: [],
    };
  },
  methods: {
    doAudit(ids, type, auditExplain) {
      if (ids.length === 0) {
        this.$message.error(`请选择要操作的数据`);
        return;
      }
      this.$confirm(
        `是否${type === CULTIVATE_REFEREE_STATUS_CODE.FAIL ? '驳回申请' : '通过申请'}`,
        '提示',
        {type: 'warning'}
      ).then((res) => {
        if (type === CULTIVATE_REFEREE_STATUS_CODE.FAIL) {
          this.$prompt('请输入驳回理由', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
          }).then(({value}) => {
            this.audit(ids, type, value);
          });
        } else {
          this.audit(ids, type);
        }
      });
    },

    audit(ids, type, auditExplain) {
      let params = [];
      ids.map((item) => {
        params.push({id: item, state: type, auditExplain: auditExplain || ''});
      });
      audit(params).then((res) => {
        this.$message.success(`操作成功`);
        this.getList();
      });
    },

    preImg(path) {
      this.url = this.imgUrl + path;
      this.$refs[this.MODAL_KEY.PREVIEW_IMG].showModal();
    },

    selectionChange(selection) {
      this.ids = [];
      selection.map((item) => {
        this.ids.push(item.id);
      });
    },

    showAddGame() {
      this.modalData = {};
      this.modalType = 'add';
      this.$refs[this.MODAL_KEY.EDIT_MODAL].showModal();
    },

    doUpdate(row) {
      updateGameReferee({id: row.id, recommendNumLimit: row.recommendNumLimit}).then((res) => {
        this.$message.success('修改成功');
        this.$set(row, 'isEdit', false);
      });
    },

    showExport() {
      this.$refs[this.MODAL_KEY.EXPORT_SCAN].showModal();
    },

    doExport(data) {
      let token = this.$store.getters.access_token;
      exportAnchorFile(
        this.loadUrl +
          `/api/gameUnitReferee/downLoadZip?gameId=${
            data.gameId
          }&centerCheckStatus=${data.centerCheckStatus || ''}&token=${token}`
      );
      this.$refs[this.MODAL_KEY.EXPORT_SCAN].closeModal();
    },

    loadTemplate() {
      //下载模板
      exportAnchorFile(this.loadUrl + '/download/signup/report');
    },
    doDel(ids) {
      if (ids.length === 0) {
        this.$message.error('请选择要删除的数据');
        return;
      }
      this.$confirm('是否要删除裁判员报名', '提示', {type: 'warning'}).then((res) => {
        delGameReferee(ids).then((res) => {
          this.$message.success('删除成功');
          this.getList();
        });
      });
    },

    doSubmit(data) {
      addGameReferee(data).then((res) => {
        this.$message.success('添加成功');
        this.$refs[this.MODAL_KEY.EDIT_MODAL].closeModal();
        this.getList();
      });
    },

    getList(current) {
      if (!this.validatenull(current)) {
        this.listQuery.pageNo = current;
      }

      fetchCultivateReferee(this.listQuery).then((res) => {
        this.total = Number(res.data.data.total);
        this.dataSource = res.data.data.results.filter((item, index) => {
          item.isEdit = false;
          return true;
        });
      });
    },

    getUnitAll() {
      fetchUnitAll().then((res) => {
        this.unitList = res.data.data;
      });
    },

    getNotifyList() {
      fetchCultivate({pageNo: 1, pageSize: 10000}).then((res) => {
        this.newsList = res.data.data.results;
        if(!this.listQuery.newsNoticeId){}
      });
    },
  },

  mounted() {
    // 单位指定unitId
    this.listQuery.newsNoticeId = this.$router.history.current.query.id;
    // this.listQuery.unitId = this.$router.history.current.query.unitId
    //   ? this.$router.history.current.query.unitId
    //   : this.listQuery.unitId;
    if (this.listQuery.newsNoticeId) {
      this.getList();
    }
    this.getNotifyList();
    this.getUnitAll();
  },
};
</script>
