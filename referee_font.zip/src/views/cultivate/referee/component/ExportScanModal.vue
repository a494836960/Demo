<template>
    <el-dialog
            title="导出扫描件"
            :close-on-click-modal="isClickModalClose"
            :visible.sync="isShow"
            :width="defaultWidth"
            @close="closeModal"
    >

        <el-form :ref="formName" :model="modalData" :rules="ruleValidate" label-width="110px">
            <el-form-item label="培训活动：" prop="gameId">
                <el-select placeholder="请选择培训活动" v-model="modalData.gameId" filterable clearable>
                    <el-option v-for="(item,index) in gameList" :key="index" :value="item.id"
                               :label="item.gameNameCHN"></el-option>
                </el-select>
            </el-form-item>

            <el-form-item label="培训活动：" prop="centerCheckStatus">
                <el-select placeholder="审核状态" v-model="modalData.centerCheckStatus" filterable
                           clearable>
                    <el-option v-for="(item,index) in CULTIVATE_REFEREE_STATUS" :key="index" :value="item.value"
                               :label="item.name"></el-option>
                </el-select>
            </el-form-item>
        </el-form>

        <div slot="footer" class="text-r">
            <el-button @click="closeModal">
                取消
            </el-button>

            <el-button @click="submit" type="primary">
                确定
            </el-button>
        </div>
    </el-dialog>
</template>

<script>
    import modalMixin from '@/mixins/modalMixin';
    import {
        CULTIVATE_REFEREE_STATUS
    } from '@/const/index';

    export default {
        mixins: [modalMixin],
        props: ['gameList'],
        data() {
            return {
                CULTIVATE_REFEREE_STATUS: CULTIVATE_REFEREE_STATUS,
                formName: 'form',
                modalData: {},
                ruleValidate: {
                    gameId: [{
                        required: true,
                        message: '请选择培训'
                    }]
                },
            };
        },
        methods: {
            showModal() {
                this.isShow = true;
                this.modalData = {};
                this.$nextTick(() => {
                    this.$refs[this.formName].clearValidate();
                })

            },
            submit() {
                this.validateForm().then(res => {
                    this.$emit('submit', this.modalData);
                })
            },
        },
    }
</script>

<style lang="less">
    .item-close {
        margin-left: 20px;
        cursor: pointer;
        font-size: 24px;
    }
</style>
