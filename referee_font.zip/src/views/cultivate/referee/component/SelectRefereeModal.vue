<template>
    <el-dialog
            title="赛事信息"
            :close-on-click-modal="isClickModalClose"
            :visible.sync="isShow"
            width="950px"
            @close="closeModal"
    >
        <div v-if="step===1">
            <el-row :gutter="20" class="top-search">
                <el-col :span="6">
                    <el-select v-model="listQuery.unitId" placeholder="注册所属省市" clearable filterable
                               @change="getList(1)">
                        <el-option v-for="(item, index) in unitList" :key="index" :value="item.id"
                                   :label="item.cnName"></el-option>
                    </el-select>
                </el-col>

                <el-col :span="6">
                    <el-select v-model="listQuery.specialityCode" placeholder="特长" clearable filterable
                               @change="getList(1)">
                        <el-option v-for="(item, index) in specialityList" :key="index" :value="item.code"
                                   :label="item.name"></el-option>
                    </el-select>
                </el-col>

                <el-col :span="6">
                    <el-select v-model="listQuery.languageLevel" placeholder="外语等级" clearable filterable
                               @change="getList(1)">
                        <el-option v-for="(item, index) in LANGUAGE_LEVEL" :key="index" :value="item.value"
                                   :label="item.name"></el-option>
                    </el-select>
                </el-col>

                <el-col :span="6">
                    <el-input placeholder="姓名" v-model="listQuery.cnName" @change="getList(1)"></el-input>
                </el-col>

                <el-col :span="6">
                    <el-input placeholder="身份证" v-model="listQuery.idcard" @change="getList(1)"></el-input>
                </el-col>

                <el-col :span="6">
                    <el-input placeholder="手机号" v-model="listQuery.mobile" @change="getList(1)"></el-input>
                </el-col>
            </el-row>

            <el-table border :data="dataSource" class="page-top-space" row-class-name="table-row"
                      ref="multipleTable"
                      @selection-change="changeSelect">
                <el-table-column
                        type="selection">
                </el-table-column>

                <el-table-column
                        prop="cnName"
                        label="姓名">
                </el-table-column>

                <el-table-column
                        prop="sex"
                        width="50px"
                        label="性别">
                    <template slot-scope="scope">
                        <MyBadge :list="GENDER" :target="scope.row.sex"></MyBadge>
                    </template>
                </el-table-column>

                <el-table-column
                        prop="level"
                        label="等级">
                    <template slot-scope="scope">
                        <span><MyBadge :list="LEVEL_TYPE" :target="scope.row.level"></MyBadge></span>
                    </template>
                </el-table-column>

                <el-table-column
                        prop="birthday"
                        label="出生日期">
                    <template slot-scope="scope">
                        <span>{{scope.row.birthday|dateFormat(null,'YYYY-MM-DD')}}</span>
                    </template>
                </el-table-column>

                <el-table-column
                        prop="unitName"
                        label="注册所属省市">
                </el-table-column>
            </el-table>

            <el-pagination
                    class="page-top-space"
                    background
                    :total="total"
                    :page-size="listQuery.pageSize"
                    :current-page.sync="listQuery.pageNo"
                    @current-change="getList"
            >
            </el-pagination>

            <div slot="footer">
                <el-button @click="closeModal">
                    取消
                </el-button>

                <el-button @click="submit" type="primary">
                    确定
                </el-button>
            </div>
        </div>

        <div v-else>

        </div>
    </el-dialog>
</template>

<script>
    import modalMixin from '@/mixins/modalMixin';
    import {
        fetchRefereeList,
    } from '@/api/referee';
    import {LANGUAGE_LEVEL, LANGUAGE_TYPE, RECOMMEND_TYPE, GENDER, LEVEL_TYPE, ROLE} from '@/const/index';
    import {fetchRefereeLevel} from '@/api/common';
    import {fetchUnitAll} from '@/api/unit';

    export default {
        mixins: [modalMixin],
        props: ['positionList', 'positionName'],
        data() {
            return {
                formName: 'form',


                ROLE_CODE: ROLE,
                role: this.$store.getters.permissions[0],
                LEVEL_TYPE: LEVEL_TYPE,
                LANGUAGE_LEVEL: LANGUAGE_LEVEL,
                LANGUAGE_TYPE: LANGUAGE_TYPE,
                RECOMMEND_TYPE: RECOMMEND_TYPE,
                GENDER: GENDER,
                MODAL_KEY: {
                    UPLOAD_EXCEL: 'UPLOAD_EXCEL',
                    EDIT_MODAL: 'EDIT_MODAL',
                    RESET_MODAL: 'RESET_MODAL'
                },
                listQuery: {
                    pageNo: 1,
                    pageSize: 8,
                    unitId: '',
                },
                total: 0,
                dataSource: [],
                specialityList: [],
                unitList: [],
                specialityMap: {},
                levelList: [],
                ids: [],
            };
        },
        methods: {
            changeSelect(selection) {
                this.ids = [];
                selection.map(item => {
                    this.ids.push(item.id);
                })
            },

            getList(current) {
                if (!this.validatenull(current)) {
                    this.listQuery.pageNo = current;
                }
                fetchRefereeList(this.listQuery).then(res => {
                    this.dataSource = res.data.data.results;
                    this.total = res.data.data.total_record;
                })
            },

            //获取单位列表
            getUnit() {
                fetchUnitAll().then(res => {
                    this.unitList = res.data.data;
                })
            },

            // 获取裁判等级列表
            getRefereeLevelList() {
                fetchRefereeLevel().then(res => {
                    this.levelList = res.data.data;
                })
            },
            showModal() {
                this.isShow = true;
                this.$nextTick(() => {
                    this.$refs.multipleTable && this.$refs.multipleTable.clearSelection();
                })
            },
            submit() {
                if (this.validatenull(this.ids)) {
                    this.$message.error('请选择要选派的裁判');
                    return;
                }
                this.$emit('submit', this.ids);
            },
        },

        mounted() {
            this.getList();
            this.getUnit();
            this.getRefereeLevelList();
        }

    }
</script>
