<template>
    <el-dialog
            :title="type==='edit'?'编辑培训': '新增培训'"
            :close-on-click-modal="isClickModalClose"
            :visible.sync="isShow"
            :width="defaultWidth"
            @close="closeModal"
    >
        <el-form :ref="formName" :model="modalData" :rules="ruleValidate" label-width="110px">
            <el-form-item label="培训名称：" prop="gameNameCHN">
                <el-input v-model="modalData.gameNameCHN" placeholder="请输入培训名称" :maxLength="50"></el-input>
            </el-form-item>

            <el-form-item label="报名开始时间：" prop="signUpTime">
                <el-date-picker
                        @change="changeSign"
                        style="width: 100%;"
                        v-model="modalData.signUpTime"
                        value-format="timestamp"
                        type="datetimerange"
                        range-separator="至"
                        start-placeholder="开始日期"
                        end-placeholder="结束日期">
                </el-date-picker>
            </el-form-item>

            <el-form-item label="培训开始时间：" prop="time">
                <el-date-picker
                        style="width: 100%;"
                        :default-value="defaultTime"
                        v-model="modalData.time"
                        value-format="timestamp"
                        type="datetimerange"
                        range-separator="至"
                        start-placeholder="开始日期"
                        end-placeholder="结束日期">
                </el-date-picker>
            </el-form-item>

            <el-form-item label="培训须知：" prop="gameFile">
                <el-input v-model="modalData.gameFile" placeholder="请选择上传培训须知" :disabled="true">
                    <uploadFile slot="append" action='admin/referee/add/temp'
                                @success="uploadGameFile"></uploadFile>
                </el-input>
            </el-form-item>

            <el-form-item label="培训地址">
                <el-cascader
                        v-model="modalData.area"
                        :options="areasList"
                        :props="{value: 'name',label: 'name'}"></el-cascader>
            </el-form-item>

            <el-form-item label="详细地址" prop="gameLocationCHN">
                <el-input placeholder="请输入详细地址" v-model="modalData.gameLocationCHN"></el-input>
            </el-form-item>

            <el-form-item label="培训允许等级" prop="refereeLevel">
                <el-select placeholder="请选择允许哪些等级报名" v-model="modalData.refereeLevel" multiple clearable>
                    <el-option v-for="(item,index) in LEVEL_TYPE" :value="item.value+''" :label="item.name"
                               :key="index"></el-option>
                </el-select>
            </el-form-item>

            <el-form-item label="最大报名年龄" prop="maxAge">
                <fpl-input-number placeholder="请输入最大报名年龄" v-model="modalData.maxAge"></fpl-input-number>
            </el-form-item>

            <el-form-item label="最小证书年龄" porp="minCertificateAge">
                <fpl-input-number placeholder="请输入最小证书年龄" v-model="modalData.minCertificateAge"></fpl-input-number>
            </el-form-item>

            <el-form-item label="是否开放" porp="isOpen">
                <el-checkbox v-model="modalData.isOpen" :true-label="1" :false-label="0">开放</el-checkbox>
            </el-form-item>
        </el-form>

        <div slot="footer">
            <el-button @click="closeModal">
                取消
            </el-button>

            <el-button @click="submit" type="primary">
                确定
            </el-button>
        </div>
    </el-dialog>
</template>

<script>
    import modalMixin from '@/mixins/modalMixin';
    import {areas} from '@/common/area.js';
    import {ROLE, LEVEL_TYPE} from '@/const/index';

    export default {
        mixins: [modalMixin],
        props: ['modalData', 'type', 'unitList'],
        data() {
            let levelType = LEVEL_TYPE.slice(0, LEVEL_TYPE.length - 1);
            return {
                LEVEL_TYPE: levelType,
                ROLE: ROLE,
                defaultTime: new Date(),
                role: this.$store.getters.permissions[0],
                imgUrl: this.imgUrl,
                areasList: areas.provinces,
                unitArea: [],
                formName: 'form',
                ruleValidate: {
                    refereeLevel: [{
                        required: true,
                        message: '请选择培训允许报名等级',
                        trigger: 'change'
                    }],
                    signUpTime: [{
                        required: true,
                        message: '培训报名时间不能为空',
                        trigger: 'change'
                    }],
                    time: [{
                        required: true,
                        message: '培训开始时间不能为空',
                        trigger: 'change'
                    }],
                    area: [{
                        required: true,
                        message: '培训地址能为空',
                        trigger: 'change'
                    }],
                    gameNameCHN: [{
                        required: true,
                        message: '培训名称能为空',
                        trigger: 'blur'
                    }], //
                    minCertificateAge: [{
                        required: true,
                        message: '最小证书年龄能为空',
                        trigger: 'blur'
                    }],
                    maxAge: [{
                        required: true,
                        message: '最大报名年龄能为空',
                        trigger: 'blur'
                    }]
                }
            };
        },
        methods: {
            uploadGameFile(res) {
                this.$set(this.modalData, 'gameFile', res);
            },

            changeSign(time) {
                if (!this.validatenull(time)) {
                    this.defaultTime = time[1]
                }
            },

            submit() {
                this.validateForm().then(res => {
                    let obj = this.deepClone(this.modalData);
                    obj.refereeLevel = obj.refereeLevel.join(',')

                    if (!this.validatenull(obj.signUpTime)) {
                        obj.signUpEndTime = obj.signUpTime[1]
                        obj.signUpBeginTime = obj.signUpTime[0]
                    }

                    if (!this.validatenull(obj.time)) {
                        obj.endTime = obj.time[1];
                        obj.beginTime = obj.time[0];
                    }

                    if (!this.validatenull(obj.area)) {
                        obj.gameSiteCHN = obj.area[1];
                        obj.gameAreaCHN = obj.area[0];
                    }

                    this.$emit('submit', obj);
                })
            },
        },

    }
</script>
