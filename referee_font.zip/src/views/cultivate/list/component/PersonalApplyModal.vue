<!-- 个人报名 -->
<template>
    <el-dialog
            title="报名"
            :close-on-click-modal="isClickModalClose"
            :visible.sync="isShow"
            :width="defaultWidth"
            @close="closeModal"
    >
        <el-form :ref="formName" :model="modalData" :rules="ruleValidate" label-width="110px">
            <el-form-item :label="`报名表扫描件：`" prop="reportFile"
                          label-width="150px">
                <UploadImg
                        action="/admin/unitRefereeFile/add/temp"
                        :defaultUrl="item.reportFile?imgUrl+item.reportFile : ''"
                        @success="(res)=>{changeScan(index,res)}"></UploadImg>
            </el-form-item>
        </el-form>

        <div slot="footer" class="text-r">
            <el-button @click="closeModal">
                取消
            </el-button>

            <el-button @click="submit" type="primary">
                确定
            </el-button>
        </div>
    </el-dialog>
</template>

<script>
    import modalMixin from '@/mixins/modalMixin';

    export default {
        mixins: [modalMixin],
        props: ['gameList'],
        data() {
            return {
                formName: 'form',
                ruleValidate: {
                    reportFile: [{
                        required: true,
                        message: '请上传扫描件'
                    }]
                },
            };
        },
        methods: {
            changeScan(index, res) {
                this.$set(this.ids[index], 'reportFile', res);
            },


            submit() {
                    this.$emit('submit', this.modalData);
            },
        },

        mounted() {
            this.getList();
            this.getUnit();
            this.getRefereeLevelList();
        }

    }
</script>
