<template>
  <div>
    <el-row :gutter="20" class="search-box">
      <el-col :span="4">
        <el-input v-model="listQuery.gameName" placeholder="培训名称" @change="getList(1)" />
      </el-col>

      <el-col :span="4">
        <el-button type="primary" @click="getList(1)">查询</el-button>
      </el-col>
    </el-row>
    <div>
      <el-button class="but" type="primary" @click="showAddGame" v-auth="per.cultivate_add"
        >新增培训</el-button
      >
    </div>
    <el-table border :data="dataSource" class="page-top-space" row-class-name="table-row">
      <el-table-column type="selection"></el-table-column>
      <el-table-column label="序号" type="index"></el-table-column>
      <el-table-column label="名称" prop="titleName"></el-table-column>
      <el-table-column label="培训等级" prop="levelName"></el-table-column>
      <el-table-column label="培训最大人数" prop="maxNum" width="200px"></el-table-column>
      <el-table-column label="培训起止时间" prop="index">
        <template slot-scope="scope">
          {{ scope.row.beginTime | dateFormat(null, 'YYYY-MM-DD') }} ~
          {{ scope.row.endTime | dateFormat(null, 'YYYY-MM-DD') }}
        </template>
      </el-table-column>

      <el-table-column label="是否开放" prop="publishState">
        <template slot-scope="scope">
          <MyBadge :list="IS_OPEN" :target="scope.row.publishState"></MyBadge>
        </template>
      </el-table-column>

      <el-table-column label="操作">
        <template slot-scope="scope">
          <!-- <span
            class="option option-primary"
            @click="goUnit(scope.row)"
            v-auth="per.cultivate_unit_manage"
            >报名单位</span
          > -->
          <span
            class="option option-primary"
            @click="goReferee(scope.row)"
            v-auth="per.cultivate_referee_manage"
            >报名人员</span
          >
          <span
            class="option option-primary"
            @click="showEditGame(scope.row)"
            v-auth="per.cultivate_update"
            >编辑</span
          >
          <span
            class="option option-danger"
            @click="doDelGame(scope.row)"
            v-auth="per.cultivate_delete"
            >删除</span
          >
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      class="page-top-space"
      background
      :total="total"
      :page-size="listQuery.pageSize"
      :current-page.sync="listQuery.pageNo"
      @current-change="getList"
    ></el-pagination>

    <EditModal
      :ref="MODAL_KEY.EDIT_MODAL"
      :modal-data="modalData"
      :type="modalType"
      @submit="doSubmit"
    ></EditModal>
  </div>
</template>

<script>
import {
  fetchCultivate,
  addCultivate,
  updateCultivate,
  delCultivate,
  addGameReferee
} from '@/api/cultivate';
import EditModal from './component/EditModal';
import {IS_OPEN, LEVEL_TYPE, LEVEL_TYPE_CODE} from '@/const/index';
import {exportAnchorFile} from '@/common/util';

export default {
  components: {EditModal},
  data() {
    return {
      IS_OPEN: IS_OPEN,
      MODAL_KEY: {
        EDIT_MODAL: 'EDIT_MODAL'
      },
      imgUrl: this.imgUrl,
      listQuery: {
        pageNo: 1,
        pageSize: 10
      },
      total: 0,
      dataSource: [],
      modalData: {},
      modalType: ''
    };
  },
  methods: {
    goUnit(row) {
      this.$router.push({path: '/cultivate/unit', query: {id: row.id}});
    },
    goReferee(row) {
      this.$router.push({path: '/cultivate/referee', query: {id: row.id}});
    },
    showAddGame() {
      this.modalData = {
        refereeLevel: []
      };
      this.modalType = 'add';
      this.$refs[this.MODAL_KEY.EDIT_MODAL].showModal();
    },

    doDelGame(data) {
      this.$confirm('是否要删除赛事', '提示', {type: 'warning'}).then((res) => {
        delCultivate({id: data.id}).then((res) => {
          this.$message.success('删除成功');
          this.getList();
        });
      });
    },

    showEditGame(data) {
      this.modalData = {
        ...data,
        signUpTime: [data.signUpBeginTime, data.signUpBeginTime],
        time: [data.beginTime, data.endTime],
        area: [data.gameAreaCHN, data.gameSiteCHN],
        refereeLevel: data.refereeLevel && data.refereeLevel.split(',')
      };
      this.modalType = 'edit';
      this.$refs[this.MODAL_KEY.EDIT_MODAL].showModal();
    },

    doDownLoad(url) {
      exportAnchorFile(this.loadUrl + '/api/resource/respource?path=' + url + '&isDownload=true');
    },

    doSubmit(data) {
      let result = addCultivate;
      if (!this.validatenull(data.id)) {
        result = updateCultivate;
      }

      result(data).then((res) => {
        this.$message.success('操作成功');
        this.getList();
        this.$refs[this.MODAL_KEY.EDIT_MODAL].closeModal();
      });
    },

    getList(current) {
      if (!this.validatenull(current)) {
        this.listQuery.pageNo = current;
      }
      fetchCultivate(this.listQuery).then((res) => {
        this.dataSource = res.data.data.results;
        this.total = res.data.data.total_record;
        let levelName = [];
        this.dataSource.map((item) => {
          levelName = [];
          item.refereeLevel &&
            item.refereeLevel.split(',').map((level) => {
              levelName.push(LEVEL_TYPE_CODE[level]);
            });

          item.levelName = levelName.join('， ');
        });
      });
    },

    /************** 添加裁判报名 **************/
    doAddReferee(data) {
      addGameReferee(data).then((res) => {
        this.$message.success('添加成功');
        this.$refs[this.MODAL_KEY.EDIT_MODAL].closeModal();
        this.getList();
      });
    }
  },

  mounted() {
    this.getList();
  }
};
</script>
