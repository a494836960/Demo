<template>
  <div>
    <el-row :gutter="20" class="search-box">
      <el-col :span="4">
        <el-input v-model="listQuery.titleName" placeholder="新闻标题" @change="getList(1)" />
      </el-col>

      <el-col :span="4">
        <el-button type="primary" @click="getList(1)">查询</el-button>
      </el-col>
    </el-row>
    <div>
      <el-button class="but" type="primary" @click="goDetail">新增新闻</el-button>
    </div>
    <el-table border :data="dataSource" class="page-top-space" row-class-name="table-row">
      <el-table-column type="selection"></el-table-column>
      <el-table-column label="标题" prop="titleName"></el-table-column>
      <el-table-column label="类型" prop="newsType">
        <template slot-scope="scope">
          <MyBadge :list="NEWS_TYPE" :target="scope.row.newsType"></MyBadge>
        </template>
      </el-table-column>

      <el-table-column label="报名起止时间" prop="index">
        <template slot-scope="scope">
          <span v-if="scope.row.beginTime"
            >{{ scope.row.beginTime | dateFormat(null, 'YYYY-MM-DD') }} ~
            {{ scope.row.endTime | dateFormat(null, 'YYYY-MM-DD') }}</span
          >
          <span v-else>-</span>
        </template>
      </el-table-column>

      <el-table-column label="发布状态" prop="publishState">
        <template slot-scope="scope">
          <MyBadge :list="PUBLISH_STATE" :target="scope.row.publishState"></MyBadge>
        </template>
      </el-table-column>

      <el-table-column label="操作">
        <template slot-scope="scope">
          <span
            class="option option-primary"
            @click="goDetail(scope.row)"
            v-auth="per.cultivate_update"
            >编辑</span
          >
         
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      class="page-top-space"
      background
      :total="total"
      :page-size="listQuery.pageSize"
      :current-page.sync="listQuery.pageNo"
      @current-change="getList"
    ></el-pagination>
  </div>
</template>

<script>
import {fetchNewsList} from '@/api/news';
import {NEWS_TYPE, PUBLISH_STATE} from '@/const/index';

export default {
  data() {
    return {
      PUBLISH_STATE: PUBLISH_STATE,
      NEWS_TYPE: NEWS_TYPE,
      listQuery: {
        current: 1,
        size: 10
      },
      total: 0,
      dataSource: []
    };
  },
  methods: {
    goDetail(row){
      this.$router.push(`/news/detail/${row.id || ''}`)
    },
    getList(current) {
      if (!this.validatenull(current)) {
        this.listQuery.current = current;
      }
      fetchNewsList(this.listQuery).then((res) => {
        this.dataSource = res.data.data.records || [];
        this.total = Number(res.data.data.total);
      });
    },

    /************** 添加裁判报名 **************/
    doAddReferee(data) {
      addGameReferee(data).then((res) => {
        this.$message.success('添加成功');
        this.$refs[this.MODAL_KEY.EDIT_MODAL].closeModal();
        this.getList();
      });
    }
  },

  mounted() {
    this.getList();
  }
};
</script>
