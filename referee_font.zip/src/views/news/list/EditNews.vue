<template>
  <div>
    <el-form
      :ref="formName"
      :model="news"
      :rules="ruleValidate"
      label-width="120px"
    >
      <div style="width: 600px;">
        <el-form-item label="新闻类型" prop="newsType">
        <el-select placeholder="请选择新闻类型" v-model="news.newsType" filterable clearable>
          <el-option
            v-for="(item, index) in NEWS_TYPE"
            :key="index"
            :value="item.value"
            :label="item.name"
          ></el-option>
        </el-select>
      </el-form-item>

      <el-form-item label="标题" prop="titleName">
        <el-input placeholder="请输入标题" v-model="news.titleName"></el-input>
      </el-form-item>

      <el-form-item
        v-if="news.newsType === NEWS_TYPE_CODE.APPLY"
        label="允许报名裁判员等级"
        prop="refereeLevel"
      >
         <el-select placeholder="请选择报名裁判等级" v-model="news.refereeLevel" filterable clearable>
          <el-option
            v-for="(item, index) in levelType"
            :key="index"
            :value="item.value+''"
            :label="item.name"
          ></el-option>
        </el-select>
      </el-form-item>

      <el-form-item
        v-if="news.newsType === NEWS_TYPE_CODE.APPLY"
        label="最大报名人数"
        prop="maxNum"
      >
        <el-input placeholder="请输入最大报名人数" v-model="news.maxNum"></el-input>
      </el-form-item>

      <el-form-item v-if="news.newsType === NEWS_TYPE_CODE.APPLY" label="报名时间" prop="rangeTime">
        <el-date-picker
          @change="changeTime"
          style="width: 100%;"
          v-model="news.rangeTime"
          value-format="timestamp"
          type="datetimerange"
          range-separator="至"
          start-placeholder="报名开始日期"
          end-placeholder="报名结束日期"
        >
        </el-date-picker>
      </el-form-item>

      </div>
      <el-form-item label="文章" prop="contentHtml">
        <Editor ref="editor"></Editor>
      </el-form-item>

      <el-form-item label="立即发布" prop="publishState">
        <el-checkbox
          :true-label="PUBLISH_STATE_CODE.PUBLISH"
          :false-label="PUBLISH_STATE_CODE.UNPUBLISHED"
          v-model="news.publishState"
        ></el-checkbox>
      </el-form-item>
    </el-form>

    <el-button @click="save" type="primary">保存</el-button>
  </div>
</template>

<script>
import {findNews, updateNews} from '@/api/news';
import {NEWS_TYPE, NEWS_TYPE_CODE, PUBLISH_STATE_CODE,LEVEL_TYPE} from '@/const/index';
import Editor from '@/components/editor';

export default {
  components: {Editor},
  data() {
    let levelType = LEVEL_TYPE.concat([]);
    levelType.splice(-1,1);
    return {
      levelType:levelType,
      NEWS_TYPE_CODE: NEWS_TYPE_CODE,
      PUBLISH_STATE_CODE: PUBLISH_STATE_CODE,
      NEWS_TYPE: NEWS_TYPE,
      formName: 'form',
      news: {
        id: '',
        newsType: NEWS_TYPE_CODE.NEWS,
        endTime: '',
        beginTime: '',
        rangeTime: [],
        maxNum: undefined,
        publishState: PUBLISH_STATE_CODE.PUBLISH,
        contentHtml: '',
      },
      ruleValidate: {
        titleName:{required: true, message: '新闻标题不能为空'},
        maxNum:{required: true, message: '最大报名人数不能为空'},
        rangeTime:{required: true, message: '报名时间不能为空'},
      },
    };
  },
  methods: {
    loadData() {
      findNews({id: this.news.id}).then((res) => {
        this.news = res.data.data || {};
        this.$refs.editor.setContent(this.news.contentHtml);
        this.news.rangeTime = [this.news.beginTime, this.news.endTime]
      });
    },

    save() {
      let obj = Object.assign({}, this.news);
      obj.contentHtml = this.$refs.editor.getContent();
      updateNews(obj).then((res) => {
        this.$message.success('保存成功！');
        this.$router.push('/news/page');
      });
    },

    //修改报名时间
    changeTime(date) {
      date = date || [];
      if (date) {
        this.news.beginTime = date[0];
        this.news.endTime = date[1];
      }
    },
  },

  mounted() {
    this.news.id = this.$router.history.current.params.id;
    if (this.news.id) {
      this.loadData();
    }
  },
};
</script>
