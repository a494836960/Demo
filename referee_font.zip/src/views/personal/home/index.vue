<template>
  <div class="home">
    <div class="top">
      <el-row>
        <el-col :span="12">
          <div>
            <div class="avatar">
              <UpdateAvatar
                v-if="isShowAvatar"
                :action="`/admin/referee/uploadPhoto/${id}`"
                :defaultUrl="info.photo ? imgUrl + info.photo : ''"
                @success="changePhoto"
              ></UpdateAvatar>
            </div>
            <div class="top-left">
              <p class="title">您好,{{ info.cnName }}</p>
              <p style="color: #797979;">
                注册归属单位：{{ info.unitName }} | 田径
                <MyBadge :list="LEVEL_TYPE" :target="info.level"></MyBadge>
                裁判员
              </p>

              <p style="color: #797979; margin-top: 5px;">
                <span style="margin-right: 20px;"
                  >主管单位审核：
                  <span v-if="info.unitCheckStatus == 0" class="text-danger">待审核</span>
                  <span v-else class="text-success">已审核</span> </span
                >中国田协审核：
                <span v-if="info.centerCheckStatus == 0" class="text-danger">待审核</span>
                <span v-else class="text-success">已审核</span>
              </p>
            </div>
          </div>
        </el-col>

        <el-col :span="12" class="text-r">
          <el-button type="success" @click="doSave" v-if="isEdit">保存</el-button>
          <el-button type="primary" @click="goDetailInfo" v-else>修改</el-button>
          <el-button type="default" @click="doCancel" v-if="isEdit">取消</el-button>
        </el-col>
      </el-row>
    </div>

    <div class="section">
      <el-form label-width="115px" :model="info" :rules="ruleValidate">
        <el-row :gutter="20">
          <el-col :span="20">
            <el-divider content-position="left">基本信息</el-divider>
            <el-row :gutter="20">
              <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
                <el-form-item label="注册所属省市：" prop="unitId">
                  <el-select
                    v-if="isEdit"
                    v-model="info.unitId"
                    placeholder="请选择注册所属省市"
                    filterable
                  >
                    <el-option
                      v-for="(item, index) in unitList"
                      :value="item.id"
                      :label="item.cnName"
                      :key="index"
                    ></el-option>
                  </el-select>
                  <span v-else>{{ info.unitName }}</span>
                </el-form-item>
              </el-col>

              <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
                <el-form-item label="裁判归属地：" prop="area">
                  <el-cascader
                    v-if="isEdit"
                    v-model="info.area"
                    :options="areasList"
                    :props="{value: 'name', label: 'name'}"
                  ></el-cascader>
                  <span v-else>{{ info.province }}-{{ info.city }}</span>
                </el-form-item>
              </el-col>

              <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
                <el-form-item label="姓名(中文)：" prop="cnName">
                  <el-input
                    v-if="isEdit"
                    v-model="info.cnName"
                    placeholder="请输入姓名"
                    :maxLength="32"
                  ></el-input>
                  <span v-else>{{ info.cnName }}</span>
                </el-form-item>
              </el-col>

              <!-- <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
                <el-form-item label="身份证：" prop="idcard">
                  {{ info.idcard }}
                </el-form-item>
              </el-col> -->
              <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
                <el-form-item label="性别：" prop="sex">
                  <el-radio-group v-model="info.sex" v-if="isEdit">
                    <el-radio :label="0">男</el-radio>
                    <el-radio :label="1">女</el-radio>
                  </el-radio-group>
                  <MyBadge v-else :list="GENDER" :target="info.sex"></MyBadge>
                </el-form-item>
              </el-col>
              <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
                <el-form-item label="政治面貌：" prop="political">
                  <el-select v-model="info.political" placeholder="请输入政治面貌" v-if="isEdit">
                    <el-option
                      v-for="(item, index) in politicalList"
                      :value="item"
                      :label="item"
                      :key="index"
                    ></el-option>
                  </el-select>
                  <span v-else>{{ info.political }}</span>
                </el-form-item>
              </el-col>
              <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
                <el-form-item label="民族：" prop="ethnicity">
                  <el-select v-model="info.ethnicity" placeholder="请选择民族" v-if="isEdit">
                    <el-option
                      v-for="(item, index) in ethnicityList"
                      :value="item"
                      :label="item"
                      :key="index"
                    ></el-option>
                  </el-select>
                  <span v-else>{{ info.ethnicity }}</span>
                </el-form-item>
              </el-col>
              <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
                <el-form-item label="身高：" prop="height">
                  <el-input
                    v-model="info.height"
                    placeholder="请输入身高"
                    :maxLength="32"
                    v-if="isEdit"
                  >
                    <span slot="suffix">cm</span>
                  </el-input>
                  <span v-else>{{ info.height }} <span v-if="info.height">cm</span></span>
                </el-form-item>
              </el-col>
              <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs" v-if="isEdit">
                <el-row :gutter="20">
                  <el-col :span="15">
                    <el-form-item label="姓名(拼音)：" prop="enSurname">
                      <el-input
                        v-model="info.enSurname"
                        placeholder="姓"
                        :maxLength="32"
                      ></el-input>
                    </el-form-item>
                  </el-col>

                  <el-col :span="9">
                    <el-form-item prop="enName" label-width="0">
                      <el-input v-model="info.enName" placeholder="名" :maxLength="32"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
              </el-col>
              <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs" v-else>
                <el-form-item label="姓名(拼音)：" prop="enName">
                  {{ info.enSurname }} {{ info.enName }}
                </el-form-item>
              </el-col>

              <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
                <el-form-item label="出生日期：" prop="birthday">
                  <el-date-picker
                    v-if="isEdit"
                    style="width: 100%"
                    v-model="info.birthday"
                    value-format="timestamp"
                    type="date"
                    placeholder="选择日期"
                  >
                  </el-date-picker>

                  <span v-else>{{ info.birthday | dateFormat(null, 'YYYY-MM-DD') }}</span>
                </el-form-item>
              </el-col>

              <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
                <el-form-item label="QQ：" prop="qq">
                  <el-input
                    v-if="isEdit"
                    v-model="info.qq"
                    placeholder="请输入QQ"
                    :maxLength="32"
                  ></el-input>
                  <span v-else>{{ info.qq || '-' }}</span>
                </el-form-item>
              </el-col>

              <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
                <el-form-item label="体重：" prop="weight">
                  <el-input
                    v-if="isEdit"
                    v-model="info.weight"
                    placeholder="请输入体重"
                    :maxLength="32"
                  >
                    <span slot="suffix">kg</span>
                  </el-input>
                  <span v-else>{{ info.weight }} <span v-if="info.weight">kg</span></span>
                </el-form-item>
              </el-col>

              <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
                <el-form-item label="鞋码：" prop="shoeSize">
                  <el-select v-if="isEdit" v-model="info.shoeSize">
                    <el-option
                      v-for="(item, index) in SHOES_SIZE_LIST"
                      :value="item.value"
                      :label="item.name"
                      :key="index"
                    ></el-option>
                  </el-select>
                  <span v-else>{{ info.shoeSize || '-' }}</span>
                </el-form-item>
              </el-col>

              <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
                <el-form-item label="服装尺码：" prop="clothSize">
                  <el-select v-if="isEdit" v-model="info.clothSize">
                    <el-option
                      v-for="(item, index) in CLOTHES_SIZE_LIST"
                      :value="item.value"
                      :label="item.name"
                      :key="index"
                    ></el-option>
                  </el-select>
                  <span v-else>{{ info.clothSize || '-' }}</span>
                </el-form-item>
              </el-col>

              <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
                <el-form-item label="户籍地址：" prop="contactAddress">
                  <el-input
                    v-if="isEdit"
                    v-model="info.contactAddress"
                    placeholder="请输入户籍地址"
                    :maxLength="32"
                  ></el-input>
                  <span v-else>{{ info.contactAddress || '-' }}</span>
                </el-form-item>
              </el-col>

              <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
                <el-form-item label="健康状况：">
                  <el-input
                    v-if="isEdit"
                    type="textarea"
                    v-model="info.health"
                    placeholder="良好、一般、较差、如有疾病如实填写"
                    :maxLength="20"
                  ></el-input>
                  <span v-else>{{ info.health || '-' }}</span>
                </el-form-item>
              </el-col>
            </el-row>

            <el-divider content-position="left">工作情况</el-divider>
            <el-row :gutter="20">
              <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
                <el-form-item label="工作单位：" prop="inaugurationUnit">
                  <el-input
                    v-if="isEdit"
                    v-model="info.inaugurationUnit"
                    placeholder="请输入工作单位："
                    :maxLength="32"
                  ></el-input>
                  <span v-else>{{ info.inaugurationUnit || '-' }}</span>
                </el-form-item>
              </el-col>

              <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
                <el-form-item label="单位电话：" prop="inaugurationUnitTel">
                  <el-input
                    v-if="isEdit"
                    v-model="info.inaugurationUnitTel"
                    placeholder="请输入单位电话"
                    :maxLength="32"
                  ></el-input>
                  <span v-else>{{ info.inaugurationUnitTel || '-' }}</span>
                </el-form-item>
              </el-col>

              <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
                <el-form-item label="个人邮箱：" prop="inaugurationUnitEmail">
                  <el-input
                    v-if="isEdit"
                    v-model="info.inaugurationUnitEmail"
                    placeholder="请输入个人邮箱"
                    :maxLength="32"
                  ></el-input>
                  <span v-else>{{ info.inaugurationUnitEmail || '-' }}</span>
                </el-form-item>
              </el-col>

              <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
                <el-form-item label="联系地址：" prop="inaugurationUnitAddres">
                  <el-input
                    v-if="isEdit"
                    v-model="info.inaugurationUnitAddres"
                    placeholder="请输入单位联系地址"
                    :maxLength="32"
                  ></el-input>
                  <span v-else>{{ info.inaugurationUnitAddres || '-' }}</span>
                </el-form-item>
              </el-col>

              <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
                <el-form-item label="单位邮政编码：" prop="inaugurationUnitPasspot">
                  <el-input
                    v-if="isEdit"
                    v-model="info.inaugurationUnitPasspot"
                    placeholder="请输入单位邮政编码"
                    :maxLength="32"
                  ></el-input>
                  <span v-else>{{ info.inaugurationUnitPasspot || '-' }}</span>
                </el-form-item>
              </el-col>
            </el-row>

            <el-divider content-position="left">教育背景</el-divider>
            <el-row :gutter="20">
              <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
                <el-form-item label="教育背景：" prop="education">
                  <el-select v-model="info.education" placeholder="请选择学历" v-if="isEdit">
                    <el-option
                      v-for="(item, index) in educationList"
                      :value="item.value"
                      :label="item.name"
                      :key="index"
                    ></el-option>
                  </el-select>
                  <span v-else>{{ info.education || '-' }}</span>
                </el-form-item>
              </el-col>

              <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
                <el-form-item label="外语：" prop="language">
                  <el-select v-model="info.language" placeholder="请选择外语" v-if="isEdit">
                    <el-option
                      v-for="(item, index) in languageList"
                      :value="item.value"
                      :label="item.name"
                      :key="index"
                    ></el-option>
                  </el-select>
                  <span v-else>{{ info.language || '-' }}</span>
                </el-form-item>
              </el-col>

              <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
                <el-form-item label="外语等级：" prop="languageLevel" :rules="[{required: true, message: '请选择语言等级',trigger:'change'}]">
                  <el-select
                    v-model="info.languageLevel"
                    placeholder="请选择外语等级"
                    v-if="isEdit"
                  >
                    <el-option
                      v-for="(item, index) in languageLevel"
                      :value="item.value+''"
                      :label="item.name"
                      :key="index"
                    ></el-option>
                  </el-select>
                  <MyBadge v-else :list="languageLevel" :target="info.languageLevel"></MyBadge>
                </el-form-item>
              </el-col>

              <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
                <el-form-item label="职称：" prop="technicalTitle">
                  <el-input
                    v-if="isEdit"
                    v-model="info.technicalTitle"
                    placeholder="请输入职称"
                    :maxLength="32"
                  ></el-input>
                  <span v-else>{{ info.technicalTitle || '-' }}</span>
                </el-form-item>
              </el-col>
            </el-row>

            <el-divider content-position="left">执裁经历</el-divider>
            <el-row :gutter="40">
              <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
                <el-form-item label="裁判等级：" prop="level">
                  <el-select
                    v-model="info.level"
                    placeholder="请选择裁判等级"
                    filterable
                    v-if="isEdit"
                  >
                    <el-option
                      v-for="(item, index) in levelList"
                      :value="item.code"
                      :label="item.name"
                      :key="index"
                    ></el-option>
                  </el-select>
                  <MyBadge v-else :list="LEVEL_TYPE" :target="info.level"></MyBadge>
                </el-form-item>
              </el-col>

              <el-col
                :md="md"
                :xl="xl"
                :lg="lg"
                :sm="sm"
                :xs="xs"
                v-if="info.level == 4 || info.level == 5"
              >
                <el-form-item label="技术类型：" prop="technical">
                  <el-select
                    v-model="info.technical"
                    placeholder="请选择技术类型"
                    filterable
                    v-if="isEdit"
                  >
                    <el-option
                      v-for="(item, index) in positionList"
                      :value="item.code"
                      :label="item.name"
                      :key="index"
                    ></el-option>
                  </el-select>
                  <MyBadge
                    v-else
                    :list="positionList"
                    keys="code"
                    :target="info.technical"
                  ></MyBadge>
                </el-form-item>
              </el-col>

              <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
                <el-form-item label="发证时间：" prop="prejudgeda">
                  <el-date-picker
                    style="width: 100%"
                    v-if="isEdit"
                    v-model="info.prejudgeda"
                    value-format="timestamp"
                    type="month"
                    placeholder="选择时间"
                  ></el-date-picker>
                  <span v-else-if="info.prejudgeda">{{
                    info.prejudgeda | dateFormat(null, 'YYYY-MM')
                  }}</span>
                </el-form-item>
              </el-col>

              <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
                <el-form-item label="证书编号：" prop="certificateCode">
                  <el-input v-if="isEdit" v-model="info.certificateCode" />
                  <span v-else>{{ info.certificateCode || '-' }}</span>
                </el-form-item>
              </el-col>

              <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
                <el-form-item label="发证单位：" prop="certificateUnit">
                  <el-input v-if="isEdit" type="text" v-model="info.certificateUnit" />
                  <span v-else>{{ info.certificateUnit || '-' }}</span>
                </el-form-item>
              </el-col>

              <el-col :span="24">
                <el-form-item label="执裁经历：" prop="experience">
                  <el-input
                    v-if="isEdit"
                    type="textarea"
                    autosize
                    v-model="info.experience"
                    placeholder="请输入执裁经历"
                    :maxLength="32"
                  ></el-input>
                  <span v-else>{{ info.experience || '-' }}</span>
                </el-form-item>
              </el-col>

              <el-col :span="24">
                <el-form-item label="特长：" prop="spec">
                  <el-select
                    v-if="isEdit"
                    v-model="info.speciality"
                    placeholder="请选择特长最多3个"
                    clearable
                    :multiple-limit="3"
                    multiple
                  >
                    <el-option
                      v-for="(item, index) in specialityList"
                      :key="index"
                      :value="item.code"
                      :label="item.name"
                    ></el-option>
                  </el-select>

                  <span v-else>{{ info.specialityName && info.specialityName.join('、 ') }}</span>
                </el-form-item>
              </el-col>
            </el-row>
          </el-col>

          <el-col :span="4" style="text-align:center;">
            <el-divider content-position="left">证书上传</el-divider>

            <el-form-item prop="certificateCoverPath" label-width="0">
              <UploadImg
                class="img-size"
                :defaultUrl="info.certificateCoverPath ? imgUrl + info.certificateCoverPath : ''"
                action="/admin/referee/add/temp"
                :disabled="!isEdit"
                @success="
                  (e) => {
                    fileUpload(e, 'certificateCoverPath');
                  }
                "
              ></UploadImg>
              <span>等级证书封面</span>
            </el-form-item>
            <el-form-item prop="levelPhotoPath" label-width="0">
              <UploadImg
                class="img-size"
                :defaultUrl="info.levelPhotoPath ? imgUrl + info.levelPhotoPath : ''"
                action="/admin/referee/add/temp"
                :disabled="!isEdit"
                @success="
                  (e) => {
                    fileUpload(e, 'levelPhotoPath');
                  }
                "
              ></UploadImg>
              <span>等级证书内容面</span>
            </el-form-item>
            <el-form-item prop="certificateBackPath" label-width="0">
              <UploadImg
                class="img-size"
                :defaultUrl="info.certificateBackPath ? imgUrl + info.certificateBackPath : ''"
                action="/admin/referee/add/temp"
                :disabled="!isEdit"
                @success="
                  (e) => {
                    fileUpload(e, 'certificateBackPath');
                  }
                "
              ></UploadImg>
              <span>等级证书背面</span>
            </el-form-item>

            <el-form-item
              prop="technicalPath"
              label-width="0"
              v-if="info.level == 4 || info.level == 5"
            >
              <UploadImg
                class="img-size"
                :defaultUrl="info.technicalPath ? imgUrl + info.technicalPath : ''"
                action="/admin/referee/add/temp"
                :disabled="!isEdit"
                @success="
                  (e) => {
                    fileUpload(e, 'technicalPath');
                  }
                "
              ></UploadImg>
              <span>技术官员证</span>
            </el-form-item>
          </el-col>
        </el-row>

        <!-- <el-divider content-position="left">证书上传</el-divider>
        <el-row style="text-align:center;">
          <el-col :span="6">
            <el-form-item prop="levelPhotoPath" label-width="0">
              <UploadImg
                :defaultUrl="imgUrl + info.certificateCoverPath"
                action="/admin/referee/add/temp"
                :disabled="!isEdit"
                @success="
                  e => {
                    fileUpload(e, 'certificateCoverPath');
                  }
                "
              ></UploadImg>
              <span>等级证书封面</span>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item prop="levelPhotoPath" label-width="0">
              <UploadImg
                :defaultUrl="imgUrl + info.levelPhotoPath"
                action="/admin/referee/add/temp"
                :disabled="!isEdit"
                @success="
                  e => {
                    fileUpload(e, 'levelPhotoPath');
                  }
                "
              ></UploadImg>
              <span>等级证书内容面</span>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item prop="levelPhotoPath" label-width="0">
              <UploadImg
                :defaultUrl="imgUrl + info.certificateBackPath"
                action="/admin/referee/add/temp"
                :disabled="!isEdit"
                @success="
                  e => {
                    fileUpload(e, 'certificateBackPath');
                  }
                "
              ></UploadImg>
              <span>等级证书背面</span>
            </el-form-item>
          </el-col>

          <el-col :span="6" v-if="info.level == 4 || info.level == 5">
            <el-form-item prop="technicalPath" label-width="0">
              <UploadImg
                :defaultUrl="imgUrl + info.technicalPath"
                action="/admin/referee/add/temp"
                :disabled="!isEdit"
                @success="
                  e => {
                    fileUpload(e, 'technicalPath');
                  }
                "
              ></UploadImg>
              <span>技术官员证</span>
            </el-form-item>
          </el-col>
        </el-row> -->
      </el-form>
    </div>
    <AddModal ref="addModal" :positionList="positionList" :unitList="unitList"></AddModal>
    <ImgRotateModal
      ref="rotateModal"
      :url="rotateUrl"
      @success="handleRotateComplete"
    ></ImgRotateModal>
  </div>
</template>

<script>
import {fetchRefereeDetail, updateReferee, addReferee} from '@/api/referee';
import {fetchSpeciality, fetchRefereeLevel,rotateImg} from '@/api/common';
import {fetchPosition} from '@/api/position';
import ImgRotateModal from '@/components/ImgRotate';
import {
  LEVEL_TYPE,
  GENDER,
  EDUCATION_TYPE,
  LANGUAGE_LEVEL,
  LANGUAGE_TYPE,
  SHOES_SIZE_LIST,
  CLOTHES_SIZE_LIST,
} from '@/const/index';
import {fetchUnitAll} from '@/api/unit';
import {areas} from '@/common/area.js';
import political from '@/common/political';
import nation from '@/common/nation';
import AddModal from './components/AddModal';
import defaultAvatar from '@/assets/image/touxiang.png';
import UpdateAvatar from './components/UpdateAvatar';
import {refereeValidator} from '@/const/index'
export default {
  components: {AddModal, UpdateAvatar, ImgRotateModal},
  data() {
    return {
      id: '',
      rotateUrl: '',
      defaultAvatar: defaultAvatar,
      xl: 8,
      lg: 12,
      md: 12,
      xs: 24,
      sm: 12,
      info: {
        levelPhotoPath: [],
      },
      specialityList: [],
      isShowAvatar: true,
      isEdit: false,
      levelList: [],
      unitList: [],
      GENDER: GENDER,
      SHOES_SIZE_LIST: SHOES_SIZE_LIST,
      CLOTHES_SIZE_LIST: CLOTHES_SIZE_LIST,
      LEVEL_TYPE: LEVEL_TYPE,
      languageList: LANGUAGE_TYPE,
      languageLevel: LANGUAGE_LEVEL,
      educationList: EDUCATION_TYPE,
      areasList: areas.provinces,
      politicalList: political, // 政治面貌list
      ethnicityList: nation, // 民族list

      MODAL_KEY: {
        APPLY_MODAL: 'APPLY_MODAL',
      },
      specialityMap: {},
      imgUrl: this.imgUrl,
      positionList: [],
      ruleValidate: refereeValidator,
    };
  },

  methods: {
    handleRotateComplete(deg, path) {
      rotateImg({
        path,
        degree: deg,
      }).then((res) => {
        this.$refs.rotateModal.closeModal();
        this.isShowAvatar = false;
        this.$nextTick(() => {
          this.isShowAvatar = true;
        });
      });
    },

    changePhoto(res) {
      this.isShowAvatar = false;
      this.info.photo = res.photo;
      this.rotateUrl = res.photo;
      this.$refs.rotateModal.showModal();
      this.$nextTick(() => {
        this.isShowAvatar = true;
      });
    },
    getSpeciality(item) {
      fetchSpeciality().then((res) => {
        this.specialityList = res.data.data;
        res.data.data &&
          res.data.data.map((item) => {
            this.specialityMap[item.code] = item.name;
          });
        this.parseSpeciality();
      });
    },

    getPositionList() {
      fetchPosition({page_size: 1000}).then((res) => {
        this.positionList = res.data.data.results;
        this.$set(this.info, 'technical', this.info.technical);
      });
    },

    fileUpload(e, index) {
      this.$set(this.info, index, e);
    },

    getUnitList() {
      fetchUnitAll().then((res) => {
        this.unitList = res.data.data;
      });
    },

    // 获取裁判等级列表
    getRefereeLevelList() {
      fetchRefereeLevel().then((res) => {
        this.levelList = res.data.data;
      });
    },

    parseSpeciality() {
      if (!this.validatenull(this.info.speciality)) {
        let specialityName = [];
        specialityName = this.info.speciality.map((item) => {
          return this.specialityMap[item];
        });
        this.$set(this.info, 'specialityName', specialityName);
      }
    },

    getData() {
      fetchRefereeDetail(this.id).then((res) => {
        this.info = res.data.data || {};
        this.info.speciality = this.info.speciality
          ? this.info.speciality.replace(/[\[\]\s]/g, '').split(',')
          : [];
        this.getSpeciality();
      });
    },

    goDetailInfo() {
      this.isEdit = true;
    },

    doCancel() {
      this.getData();
      this.isEdit = false;
    },

    doSave() {
      let obj = this.deepClone(this.info);
      if (!this.validatenull(obj.area)) {
        obj.province = obj.area[0];
        obj.city = obj.area[1];
      }
      obj.speciality = _.compact(obj.speciality).join(',');
      let result = updateReferee;
      if (this.validatenull(obj.id)) {
        result = addReferee;
      }
      //添加之后、后台返回 refereeId 更新refereeId
      result(obj).then((res) => {
        this.$message.success('保存成功');
        this.isEdit = false;
      });
    },
  },

  mounted() {
    this.id = this.$store.getters.userInfo.unionId;
    if (Number(this.id) != -1) {
      this.getData();
    } else {
      // 新用户弹出框完善资料
      //去完善资料
      this.$refs.addModal.showModal();
    }
    this.getUnitList();
    this.getRefereeLevelList();
    this.getPositionList();
  },
};
</script>

<style lang="less" scoped>
.avatar {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  float: left;
}

.top-left {
  float: left;
  margin-left: 20px;

  .title {
    flex: auto;
    font-size: 20px;
    font-weight: 500;
    color: rgba(0, 0, 0, 0.85);
    margin-bottom: 16px;
  }
}

.home {
  background: #f1f1f1 !important;
  padding: 0px !important;
  .el-form-item {
    margin-bottom: 12px;
  }
}

.top {
  border-radius: 5px;
  background: #fff;
  padding: 20px;
}

.section {
  background: #fff;
  border-radius: 5px;
  padding: 20px;
  margin-top: 15px;
}

.none-img {
  border: 1px solid #e1e1e1;
  border-radius: 5px;
  width: 250px;
  height: 150px;
  display: inline-block;
  padding: 50px;
  text-align: center;
}
.home .img-size {
  width: initial;
  height: 175px;
  max-width: 100%;
  min-height: 108px;
}
</style>
