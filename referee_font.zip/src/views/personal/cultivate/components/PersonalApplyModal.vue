<!-- 个人报名 -->
<template>
    <el-dialog
            title="上传登记表"
            :close-on-click-modal="isClickModalClose"
            :visible.sync="isShow"
            :width="defaultWidth"
            @close="closeModal"
    >
        <el-form :ref="formName" :model="modalData" :rules="ruleValidate" label-width="110px">
            <el-form-item :label="`报名表扫描件：`" prop="reportFile"
                          label-width="150px">
                <UploadImg
                        action="/admin/unitRefereeFile/add/temp"
                        :defaultUrl="modalData.reportFile?imgUrl+modalData.reportFile : ''"
                        @success="(res)=>{changeScan(res)}"></UploadImg>
            </el-form-item>
        </el-form>

        <div slot="footer" class="text-r">
            <el-button @click="closeModal">
                取消
            </el-button>

            <el-button @click="submit" type="primary">
                确定
            </el-button>
        </div>
    </el-dialog>
</template>

<script>
    import modalMixin from '@/mixins/modalMixin';

    export default {
        mixins: [modalMixin],
        data() {
            return {
                formName: 'form',
                modalData: {},
                ruleValidate: {
                    reportFile: [{
                        required: true,
                        message: '请上传扫描件'
                    }]
                },
            };
        },
        methods: {
            showModal() {
                this.isShow = true;
                this.$nextTick(() => {
                    this.modalData = {};
                })
            },
            changeScan(res) {
                this.$set(this.modalData, 'reportFile', res);
            },


            submit() {
                this.$emit('submit', this.modalData);
            },
        },
    }
</script>
