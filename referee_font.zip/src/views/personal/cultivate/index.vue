<template>
  <div>
      <p class="text-r">
        <span @click="loadTemplate" class="option option-primary"
          >2019年全国报考田径国家级裁判员登记表模板下载</span
        >
      </p>
      <el-table :data="cultivateList" border class="page-top-space">
        <el-table-column label="序号" type="index"></el-table-column>
        <el-table-column label="名称" prop="gameNameCHN"></el-table-column>
        <el-table-column label="培训地点" prop="gameSiteCHN">
          <template slot-scope="scope">
            <span>
              {{ scope.row.gameAreaCHN }}
              {{ scope.row.gameSiteCHN }}
              {{ scope.row.gameLocationCHN }}
            </span>
          </template>
        </el-table-column>

        <el-table-column label="报名起止时间" prop="index">
          <template slot-scope="scope">
            <span v-if="scope.row.signUpBeginTime"
              >{{ scope.row.signUpBeginTime | dateFormat(null, "YYYY-MM-DD") }}
              ~
              {{
                scope.row.signUpEndTime | dateFormat(null, "YYYY-MM-DD")
              }}</span
            >
            <span v-else>-</span>
          </template>
        </el-table-column>

        <el-table-column label="培训起止时间" prop="index">
          <template slot-scope="scope">
            {{ scope.row.beginTime | dateFormat(null, "YYYY-MM-DD") }} ~
            {{ scope.row.endTime | dateFormat(null, "YYYY-MM-DD") }}
          </template>
        </el-table-column>

        <el-table-column label="是否开放" prop="isOpen" width="110px">
          <template slot-scope="scope">
            <MyBadge :list="IS_OPEN" :target="scope.row.isOpen"></MyBadge>
          </template>
        </el-table-column>
        <el-table-column
          width="110px"
          label="最大报名年纪"
          prop="maxAge"
        ></el-table-column>
        <el-table-column
          width="110px"
          label="最小证书年龄"
          prop="minCertificateAge"
        ></el-table-column>

         <el-table-column
          width="100px"
          label="登记表"
          prop="reportFile"
        >
        <template slot-scope="scope">
              <el-avatar  shape="square" :size="80" :src="imgUrl + scope.row.reportFile"></el-avatar>
        </template>
        </el-table-column>

        <el-table-column label="报名状态" prop="centerCheckStatus">
          <template slot-scope="scope">
            <span v-if="scope.row.isOpen === 1 && !scope.row.isApply"
              >可报名</span
            >
            <span v-else-if="scope.row.isApply">
              <MyBadge
                :list="CULTIVATE_REFEREE_STATUS"
                :target="scope.row.unitCheckStatus"
              ></MyBadge>
            </span>
            <span v-else>等待开放</span>
            <span
              v-if="
                scope.row.unitCheckStatus &&
                  scope.row.unitCheckStatus ===
                    CULTIVATE_REFEREE_STATUS_CODE.FAIL
              "
              >（{{ scope.row.auditExplain }}）</span
            >
          </template>
        </el-table-column>

        <el-table-column label="培训须知" prop="gameFile" width="100px">
          <template slot-scope="scope">
            <span
              v-if="scope.row.gameFile"
              class="option option-primary"
              @click="doDownLoad(scope.row.gameFile)"
              >下载</span
            >
          </template>
        </el-table-column>

        <el-table-column label="操作" prop="operation">
          <template slot-scope="scope">
            <span
              class="option option-primary"
              v-if="scope.row.isOpen === 1 && !scope.row.isApply"
              @click="
                () => {
                  curGameId = scope.row.id;
                  doApply({});
                }
              "
              >立即报名</span
            >

            <span
              class="option option-primary"
              v-if="scope.row.isOpen === 1"
              @click="showApplyModal(scope.row)"
              >上传登记表</span
            >
          </template>
        </el-table-column>
      </el-table>
    <PersonalApplyModal
      :ref="MODAL_KEY.APPLY_MODAL"
      @submit="updateRefereeApply"
    ></PersonalApplyModal>
  </div>
</template>

<script>
import { LEVEL_TYPE } from "@/const/index";
import {
  fetchRefereeDetail,
  fetchGameReferee,
  exportRegistryForm
} from "@/api/referee";
import { addGameReferee, updateGameReferee } from "@/api/cultivate";
import { fetchGameList } from "@/api/game";
import {
  GAME_SOURCE,
  IS_OPEN,
  CULTIVATE_REFEREE_STATUS,
  CULTIVATE_REFEREE_STATUS_CODE
} from "@/const";
import PersonalApplyModal from "./components/PersonalApplyModal";
import { apiDownLoadFile, exportAnchorFile } from "@/common/util";

export default {
  components: { PersonalApplyModal },
  data() {
    return {
      info: {},
      CULTIVATE_REFEREE_STATUS_CODE: CULTIVATE_REFEREE_STATUS_CODE,
      CULTIVATE_REFEREE_STATUS: CULTIVATE_REFEREE_STATUS,
      IS_OPEN: IS_OPEN,
      LEVEL_TYPE: LEVEL_TYPE,
      imgUrl: this.imgUrl,
      MODAL_KEY: {
        APPLY_MODAL: "APPLY_MODAL"
      },
      imgUrl: this.imgUrl,
      cultivateList: [],
      listQuery: {
        pageNo: 1,
        pageSize: 10000,
        dataSources: GAME_SOURCE.CULTIVATE_APPLY
      },
      curGameId: ""
    };
  },

  methods: {
    loadTemplate() {
      //下载模板
      exportRegistryForm(this.id).then(res => {
        apiDownLoadFile(
          res.data,
          "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
          "培训登记表"
        );
      });
    },

    doDownLoad(url) {
      exportAnchorFile(
        this.loadUrl +
          "/api/resource/respource?path=" +
          url +
          "&isDownload=true"
      );
    },

    showApplyModal(data) {
      this.curGameId = data.id;
      this.applyId = data.applyId;
      this.$refs[this.MODAL_KEY.APPLY_MODAL].showModal();
    },

    doApply(data) {
      let params = {
        gameId: this.curGameId,
        refereeId: this.id,
        reportFile: data.reportFile
      };
      addGameReferee(params).then(res => {
        this.$message.success("操作成功");
        this.$refs[this.MODAL_KEY.APPLY_MODAL].closeModal();
        this.getList();
      });
    },

    // 上传报名登记表
    updateRefereeApply(data) {
      let params = {
        gameId: this.curGameId,
        id: this.applyId,
        reportFile: data.reportFile
      };

      updateGameReferee(params).then(res => {
        this.$message.success("操作成功");
        this.$refs[this.MODAL_KEY.APPLY_MODAL].closeModal();
        this.getList();
      });
    },

    getData() {
      fetchRefereeDetail(this.id).then(res => {
        this.info = res.data.data || {};
        this.listQuery.refereeLevel = this.info.level;
        this.getList();
      });
    },

    goDetailInfo() {
      this.$router.push("/personal/detail");
    },

    getList(current) {
      if (!this.validatenull(current)) {
        this.listQuery.pageNo = current;
      }

      fetchGameReferee({ idcard: this.info.idcard }).then(resGames => {
        fetchGameList(this.listQuery).then(res => {
          let games = resGames.data.data;

          this.cultivateList = res.data.data.results || [];
          let flag = false;
          games.map(item => {
            this.cultivateList.map(culItem => {
              if (item.gameId === culItem.id) {
                if (
                  this.validatenull(item.reportFile) &&
                  item.unitCheckStatus === CULTIVATE_REFEREE_STATUS_CODE.SUCCESS
                ) {
                  this.flag = true;
                }
                culItem.isApply = true;
                culItem.reportFile = item.reportFile;
                culItem.unitCheckStatus = item.unitCheckStatus;
                culItem.auditExplain = item.auditExplain;
                culItem.applyId = item.id;
              }
            });
          });

          if (flag) {
            this.$alert("您有报名成功的培训尚未上传登记表，请及时上传！");
          }

        });
      });
    }
  },

  mounted() {
    this.id = this.$store.getters.userInfo.unionId;
    if (Number(this.id) != -1) {
      this.getData();
    } else {
      //去完善资料
      this.$router.push("/referee/edit");
    }
  }
};
</script>
