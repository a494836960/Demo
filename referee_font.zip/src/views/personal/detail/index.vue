<!-- 裁判员详细信息 
<template>
    <div>
        <div class="text-r">
            <el-button type="info" @click="goEdit">去编辑</el-button>
        </div>
        <RefereeDetail :id="id"></RefereeDetail>
    </div>
</template>

<script>
    import modalMixin from '@/mixins/modalMixin';
    import RefereeDetail from '@/components/refereeDetail';

    export default {
        mixins: [modalMixin],
        components: {RefereeDetail},
        data() {
            return {
                imgUrl: this.imgUrl,
                formName: 'form',
                referee: {},
                id: '',

            };
        },

        methods: {
            goEdit() {
                this.$router.push('/referee/edit');
            }
        },

        mounted() {
            this.id = this.$store.getters.userInfo.unionId;
        }
    }
</script>
-->