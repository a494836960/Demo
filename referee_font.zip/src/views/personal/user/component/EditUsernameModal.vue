<template>
    <el-dialog
            title="修改用户名"
            :close-on-click-modal="isClickModalClose"
            :visible.sync="isShow"
            :width="defaultWidth"
            @close="closeModal"
    >
        <el-form :ref="formName" :model="modalData" :rules="ruleValidate" label-width="90px">
            <el-form-item label="用户名：" prop="userName">
                <el-input v-model="modalData.userName" placeholder="请输入用户名" :maxLength="32"></el-input>
            </el-form-item>
        </el-form>

        <div slot="footer">
            <el-button @click="closeModal">
                取消
            </el-button>

            <el-button @click="submit" type="primary">
                确定
            </el-button>
        </div>
    </el-dialog>
</template>

<script>
    import modalMixin from '@/mixins/modalMixin';

    export default {
        mixins: [modalMixin],
        props: [
            'modalData',
        ],
        data() {
            return {
                formName: 'form',
                ruleValidate: {
                    userName: [
                        {
                            required: true,
                            type: 'string',
                            message: '用户名不能为空！',
                            trigger: 'blur'
                        }
                    ],
                }
            };
        },
        methods: {
            submit() {
                this.validateForm().then(res => {
                    this.$emit('submit', this.modalData);
                })
            },
        },

    }
</script>
