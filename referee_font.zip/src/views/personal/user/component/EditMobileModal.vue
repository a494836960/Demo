<template>
    <el-dialog
            title="修改手机号码"
            :close-on-click-modal="isClickModalClose"
            :visible.sync="isShow"
            :width="defaultWidth"
            @close="closeModal"
    >
        <el-form :ref="formName" :model="modalData" :rules="ruleValidate" label-width="90px">
            <el-form-item label="手机号码：" prop="oldMobile">
                <el-input v-model="modalData.oldMobile" :maxLength="32" :disabled="true"></el-input>
            </el-form-item>

            <el-form-item label="新号码：" prop="mobile">
                <el-input v-model="modalData.mobile" :maxLength="32" placeholder="请输入手机号码"></el-input>
            </el-form-item>

            <el-form-item label="验证码：" prop="code">
                <el-row :gutter="20">
                    <el-col :span="16">
                        <el-input v-model="modalData.code" :maxLength="32"></el-input>
                    </el-col>

                    <el-col :span="4">
                        <el-button type="primary" @click="getVerify" :disabled="count != 0">{{verifyText}}</el-button>
                    </el-col>
                </el-row>
            </el-form-item>
        </el-form>

        <div slot="footer">
            <el-button @click="closeModal">
                取消
            </el-button>

            <el-button @click="submit" type="primary">
                确定
            </el-button>
        </div>
    </el-dialog>
</template>

<script>
    import modalMixin from '@/mixins/modalMixin';
    import {fetchMobileVerify} from '@/api/user';
    import {validatorForm} from '@/common/util'

    export default {
        mixins: [modalMixin],
        props: [
            'modalData',
        ],
        data() {
            return {
                formName: 'form',
                verifyText: '获取验证码',
                timer: '',
                count: 0,
                ruleValidate: {
                    mobile: [
                        {
                            required: true,
                            type: 'string',
                            message: '手机号码不能为空！',
                            trigger: 'blur'
                        }, {
                            validator: validatorForm.phone
                        }
                    ],
                }
            };
        },
        methods: {
            getVerify() {
                this.$refs[this.formName].validateField('mobile', res => {
                    if (this.validatenull(res)) {
                        fetchMobileVerify({mobile: this.modalData.mobile}).then(res => {
                            this.startInterval(60);
                        })
                    }
                })
            },

            startInterval(time) {
                this.endInterVal();
                this.count = time;

                this.timer = setInterval(() => {
                    if (this.count > 0) {
                        this.count--;
                        this.verifyText = this.count;
                    } else {
                        this.verifyText = '获取验证码';
                        this.endInterVal();
                    }
                }, 1000)
            },

            endInterVal() {
                clearInterval(this.timer)
            },

            submit() {
                this.validateForm().then(res => {
                    this.$emit('submit', this.modalData);
                })
            },
        },

    }
</script>
