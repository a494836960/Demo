<template>
    <div>
        <el-form ref="form" label-width="110px">
            <!-- 区域设置 -->
            <el-divider content-position="left">基本信息</el-divider>
            <el-row :gutter="20">
                <el-col :span="12">
                    <el-form-item label="用户名：" prop="username">
                        <el-input v-model="userInfo.username" :disabled="!username">
                            <el-button slot="append" @click="showUsernameModal">修改</el-button>
                        </el-input>
                    </el-form-item>

                    <el-form-item label="手机号：" prop="mobile">
                        <el-input v-model="userInfo.mobile" :disabled="!editMobile">
                            <el-button slot="append" @click="showMobileModal">修改</el-button>
                        </el-input>
                    </el-form-item>

                    <el-form-item label="邮箱：" prop="email">
                        <el-input v-model="userInfo.email" :disabled="!editEmail">
                            <el-button slot="append" @click="showEmailModal">修改</el-button>
                        </el-input>
                    </el-form-item>
                </el-col>
            </el-row>
        </el-form>
        <EditUsernameModal :ref="MODAL_KEY.EDIT_USERNAME" :modalData="modalData"@submit="doUpdateUsername"></EditUsernameModal>
        <EditEmailModal :ref="MODAL_KEY.EDIT_EMAIL" :modalData="modalData"@submit="doUpdateEmail"></EditEmailModal>
        <EditMobileModal :ref="MODAL_KEY.EDIT_MOBILE" :modalData="modalData"@submit="doUpdateMobile"></EditMobileModal>
    </div>
</template>

<script>
    import EditUsernameModal from './component/EditUsernameModal';
    import EditEmailModal from './component/EditEmailModal';
    import EditMobileModal from './component/EditMobileModal';
    import {updateEmail, updateMobile, updateUsername, fetchMobileVerify, fetchUserInfo} from '@/api/user'

    export default {
        components: {EditUsernameModal,EditEmailModal,EditMobileModal},
        data() {
            return {
                MODAL_KEY: {
                    EDIT_USERNAME: 'EDIT_USERNAME',
                    EDIT_MOBILE: 'EDIT_MOBILE',
                    EDIT_EMAIL: 'EDIT_EMAIL',
                },
                modalData: {},
                editEmail: false,
                editMobile: false,
                username: false,
                userInfo: {},
            };
        },
        methods: {
            /******** 修改用户名 *********/
            showUsernameModal() {
                this.modalData = {
                    userName: this.userInfo.username
                }
                this.$refs[this.MODAL_KEY.EDIT_USERNAME].showModal();
            },

            doUpdateUsername(data) {
                updateUsername(data).then(res => {
                    this.$message.success('修改成功');
                    this.$refs[this.MODAL_KEY.EDIT_USERNAME].closeModal();
                    this.getUserInfo();
                })
            },

            /******** 修改邮箱 *********/
            showEmailModal() {
                this.modalData = {
                    email: this.userInfo.email
                }
                this.$refs[this.MODAL_KEY.EDIT_EMAIL].showModal();
            },

            doUpdateEmail(data) {
                updateEmail(data).then(res => {
                    this.$message.success('修改成功');
                    this.$refs[this.MODAL_KEY.EDIT_EMAIL].closeModal();
                    this.getUserInfo();
                })
            },

            showMobileModal() {
                this.modalData = {
                    oldMobile: this.userInfo.mobile
                }
                this.$refs[this.MODAL_KEY.EDIT_MOBILE].showModal();
            },

            doUpdateMobile(data){
                updateMobile(data).then(res => {
                    this.$message.success('修改成功');
                    this.$refs[this.MODAL_KEY.EDIT_MOBILE].closeModal();
                    this.getUserInfo();
                })
            },

            getUserInfo() {
                fetchUserInfo().then(res => {
                    this.userInfo = res.data.data;
                })
            }
        },

        mounted() {
            this.getUserInfo();
        }
    }
</script>
