<template>
    <div>
        <el-form ref="form" label-width="110px" :model="data" :rules="rules">
            <el-divider content-position="left">修改密码</el-divider>
            <el-row :gutter="20">
                <el-col :span="12">
                    <el-form-item label="原密码：" prop="oldPwd">
                        <el-input type="password" v-model="data.oldPwd" placeholder="请输入原密码"></el-input>
                    </el-form-item>

                    <el-form-item label="新密码：" prop="pwd">
                        <el-input type="password" v-model="data.pwd" placeholder="请输入新密码"></el-input>
                    </el-form-item>

                    <el-form-item label="确认密码：" prop="confirmPassword">
                        <el-input type="password" v-model="data.confirmPassword" placeholder="请确认密码"></el-input>
                    </el-form-item>

                    <el-form-item>
                        <el-button type="primary" @click="submit">提交</el-button>
                    </el-form-item>
                </el-col>
            </el-row>
        </el-form>
    </div>
</template>

<script>
    import {updatePwd} from '@/api/user'

    export default {
        data() {
            return {
                formName: 'form',
                data: {},
                rules: {
                    pwd: {
                        required: true,
                        message: '原始密码不能为空',
                        trigger: 'blur'
                    },
                    oldPwd: {
                        required: true,
                        message: '请输入新密码',
                        trigger: 'blur'
                    },
                    confirmPassword: {
                        trigger: 'blur',
                        validator: (rule, val, callback) => {
                            if (val != this.data.pwd) {
                                callback('两次密码输入不一致');
                            }
                            callback();
                        },
                    },
                },
            };
        },
        methods: {
            submit() {
                this.$refs.form.validate(res => {
                    if (res) {
                        updatePwd(this.data).then(res => {
                            this.$message.success('密码修改成功');
                            this.data = {};
                        })
                    }
                });
            }
        },
    }
</script>
