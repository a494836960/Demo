<template>
    <div>
        <MyBox title="执裁经历">
            <el-table border :data="experienceList" class="page-top-space">
                <el-table-column prop="beginTime" label="赛事开始时间">
                    <template slot-scope="scope">
                        {{scope.row.beginTime|dateFormat(null,'YYYY-MM-DD')}}
                    </template>
                </el-table-column>
                <el-table-column prop="gameNameCHN" label="赛事名称"></el-table-column>
                <el-table-column prop="gameSiteCHN" label="赛事地点"></el-table-column>
                <el-table-column prop="name" label="赛事岗位"></el-table-column>
            </el-table>
        </MyBox>
    </div>
</template>

<script>
    import {getGameListByReferee} from '@/api/game';

    export default {
        data() {
            return {
                experienceList: [],
                listQuery: {
                    pageNo: 1,
                    pageSize: 10000,
                },
            }
        },

        methods: {
            getList() {
                getGameListByReferee({refereeId: this.id}).then(res => {
                    this.experienceList = res.data.data;
                })
            },
        },

        mounted() {
            this.id = this.$store.getters.userInfo.unionId;
            this.getList();
        }
    }
</script>
