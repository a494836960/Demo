import {serialize} from '@/common/util'
import errorCode from '@/const/errorCode'
import store from '@/store'
import {Message, Loading} from 'element-ui'
import axios from 'axios'
import {baseUrl} from '@/config/env'
import {validatenull} from '../common/validate'

// 超时时间
//axios.defaults.timeout = 120000
// 返回其他状态吗
axios.defaults.validateStatus = function (status) {
    return status >= 200 && status <= 500 // 默认的
}
// 跨域请求，允许保存cookie
axios.defaults.withCredentials = true

let countRequest = 0
let loadingInstance;
// HTTPrequest拦截
axios.interceptors.request.use(config => {
    if (!config.unLoading) {
        countRequest++ //合并请求计数；
    }
    loadingInstance = Loading.service()
    config.url = baseUrl + config.url

    let token = store.getters.access_token
    if (token && validatenull(config.headers['Authorization'])) {
        config.headers['Authorization'] = 'Bearer ' + token// token
    }

    // headers中配置serialize为true开启序列化
    if (config.methods === 'post' && config.headers.serialize) {
        config.data = serialize(config.data)
        delete config.data.serialize
    }

    if (config.params) { // 清空为空的参数
        Object.keys(config.params).map(item => {
            if (validatenull(config.params[item])) {
                delete config.params[item]
            }
        })
    }
    return config
}, error => {
    return Promise.reject(error)
})

// HTTPresponse拦截
axios.interceptors.response.use(res => {
    if (!res.config.unLoading) {
        countRequest-- //合并请求计数；
    }
    if (countRequest === 0) {
        loadingInstance.close()
    }
    //LoadingBar.finish();
    const status = Number(res.status) || 200
    const message = res.data.msg || errorCode[status] || errorCode['default']
    //异常情况
    if (status !== 200 || ((res.data.code !== 0 || res.data.data === false) && !validatenull(res.data.code))) {
        Message({
            message: message,
            type: 'error'
        });
        return Promise.reject(new Error(message))
    }

    return res
}, error => {
    countRequest--
    if (countRequest === 0) {
        loadingInstance.close()
    }
    Message({
        message: '服务异常',
        type: 'error'
    });
    return Promise.reject(new Error(error))
})

export default axios
