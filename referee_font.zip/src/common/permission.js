/**
 * 全站权限配置
 *
 */
import router from '../router'
import store from '@/store'
import {LoadingBar} from 'iview'

const website = store.getters.website
const whiteList = website.whiteList

router.beforeEach((to, from, next) => {
    LoadingBar.start()
    if (store.getters.access_token) {
        if (to.path === '/login' || to.path === '/') {
            next()
        } else {
            if (store.getters.roles.length === 0) {
                store.dispatch('GetUserInfo').then(() => {
                    next({...to, replace: true})
                }).catch(() => {
                    next({path: '/login'})
                })
            } else {
                next()
            }
        }
    } else {
        if (whiteList.indexOf(to.path) !== -1) {
            next()
        } else {
            next('/login')
        }
    }
})

router.afterEach(() => {
    LoadingBar.finish()
})
