import '@babel/polyfill'
import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import ElementUI from 'element-ui';
import '@/assets/css/global.css';

import '@/components/index';
import '@/assets/css/global.css';
import '@/assets/element/index.css';
import '@/assets/font/iconfont.css';
import '@/assets/less/theme.less';
import * as urls from '@/config/env';
import {menuList} from '@/router/nav';
import {validatenull} from '@/common/validate';
import {deepClone, validateCurrentDataLen} from '@/common/util';
import '@/directives';
import '@/filter';
import {per} from '@/const/permission';

Vue.prototype.validatenull = validatenull;
Vue.prototype.per = per;
Vue.prototype.deepClone = deepClone;
Vue.prototype.validateCurrentDataLen = validateCurrentDataLen;

Object.keys(urls).forEach(key => {
    Vue.prototype[key] = urls[key]
})
Vue.use(ElementUI);
Vue.config.productionTip = false

new Vue({
    router,
    store,
    render: h => h(App),
    created() {
        store.commit('page/init', menuList)
        store.dispatch('page/openedLoad', null, {root: true})
    },
}).$mount('#app')
