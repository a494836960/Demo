<template>
  <el-container>
    <el-header height="90px">
      <el-row type="flex" align="middle" class="web-wrapper">
        <el-col :span="2"><img src="@/assets/image/logo.png" width="60" alt=""/></el-col>
        <el-col :span="20"
          ><h1 class="title">{{ $store.getters.getSetting.title }}</h1></el-col
        >
      </el-row>
    </el-header>

    <el-main>
      <div class="web-wrapper">
        <transition name="fadeTranslateY" mode="out-in">
          <router-view :key="keyPath" />
        </transition>
      </div>
    </el-main>

    <el-footer height="140px">
      <div class="web-wrapper">
        <div class="copyright">
          中国田径协会©版权所有 本系统由深圳市菲普莱体育发展有限公司提供技术支持
        </div>
        <div class="content">
          <div>
            官方网站：<a target="_blank" href="http://www.fairplay.com.cn">www.fairplay.com.cn</a>
          </div>
          <div>
            <span>QQ交流群：643884320</span>
            <span class="qq-btn">
              <a target="_blank" href="https://jq.qq.com/?_wv=1027&k=5CVbFHw">
                <img
                  border="0"
                  src="//pub.idqqimg.com/wpa/images/group.png"
                  alt="国家级裁判交流群"
                  title="国家级裁判交流群"
                />
              </a>
            </span>
          </div>
          <div>技术支持：15999681927</div>
          <div>请使用IE10以上浏览器</div>
          <div class="qq-code">
            <img src="@/assets/image/qq_code.png" width="90" alt="" />
            <p>扫码加入QQ群</p>
          </div>
        </div>
      </div>
    </el-footer>
  </el-container>
</template>

<script>
import {exportAnchorFile} from '@/common/util';

export default {
  name: 'WebLayout',
  computed: {
    keyPath() {
      return this.$route.fullPath;
    },
    toMode() {
      if (this.$route.query['t']) {
        return {
          title: '默认裁判管理入口',
          route: {path: '/login'},
        };
      }
      return {
        title: '录入赛事裁判管理入口',
        route: {path: '/login', query: {t: 'record'}},
      };
    },
  },
  methods: {},
  mounted() {
    document.title = this.$store.getters.getSetting.title;
  },
};
</script>

<style lang="less" scoped>
.web-wrapper {
  width: 1100px;
  height: 100%;
  margin: 0 auto;
}

.el-header {
  background-color: #deecfe;

  .title {
    font-size: 24px;
    color: #0098e6;
    font-weight: bold;
    line-height: 90px;
  }

  .r-link {
    margin-top: 50px;
    color: #e27718;
    cursor: pointer;

    &:hover {
      color: #e27718cf;
    }
  }
}

.el-footer {
  margin: 24px 50px;
  font-size: 12px;

  .copyright {
    margin-bottom: 8px;
    text-align: center;
  }

  .content {
    width: 422px;
    line-height: 28px;
    margin: 0 auto;
    position: relative;

    a:hover {
      text-decoration: underline;
    }

    .qq-btn {
      vertical-align: -5px;
      margin-left: 3px;
    }

    .qq-code {
      line-height: 15px;
      position: absolute;
      right: 0;
      top: 7px;
      text-align: center;
    }
  }
}

.el-main {
  min-height: 600px;
  padding: 2% 0;
  background-image: url('../../assets/image/forget-bg.jpg');
  background-repeat: no-repeat;
  background-size: 100% 100%;
}
</style>
