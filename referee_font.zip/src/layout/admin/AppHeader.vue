<template>
  <div class="top-container">
    <el-row type="flex" align="middle" class="header">
      <el-col :span="16">
        <div class="toggle pull-left" @click="toggleExpand">
          <i :class="toggleIcon"></i>
        </div>
        <h1 class="title">{{ $store.getters.getSetting.title }}</h1>
      </el-col>
      <el-col :span="8">
        <el-dropdown
          class="pull-right"
          style="display: inline-block;height: 100%;line-height:50px;cursor: pointer;"
          trigger="click"
        >
          <span style="display: inline-block;height: 100%; line-height: 50px;">
            <span slot="title">{{ userType }}：{{ userInfo.username }}</span>
            <i class="el-icon-arrow-down el-icon--right"></i>
          </span>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item @click.native="goto('/password')">修改密码</el-dropdown-item>
            <el-dropdown-item @click.native="goto('/user-set')">个人信息</el-dropdown-item>
            <el-dropdown-item @click.native="logout">退出</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </el-col>
    </el-row>

    <el-row type="flex" align="middle" class="screen-small">
      <el-col :span="8">
        <breadcrumb />
      </el-col>
      <el-col :span="16">
        <div class="pull-right" v-if="userInfo.unitId && isShowTips">
          您好！您的单位最多可推荐
          <span class="text-success"> {{ userInfo.recommendNumLimit }} </span>
          位裁判员，当前还可以推荐
          <span class="text-danger"> {{ userInfo.surplusRecommendNum }} </span> 位裁判员给中国田协！
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import {mapState, mapGetters} from 'vuex';
import Breadcrumb from '@/components/common/Breadcrumb.vue';
import {ROLE} from '@/const/index';

export default {
  name: 'AppHeader',
  components: {
    Breadcrumb,
  },
  data() {
    return {
      isShowTips: false,
    };
  },
  computed: {
    ...mapState({
      userType: (state) => {
        const role = state.user.userInfo.role[0];
        switch (role) {
          case ROLE.system:
            return '系统管理员';
          case ROLE.admin:
            return '后台管理员';
          case ROLE.unit:
            return '省级管理员';
          case ROLE.personal:
            return '裁判员';
          case ROLE.record:
            return '选派录入员';
          default:
            return '当前账户-' + state.user.userInfo.unitName;
        }
      },
      toggleIcon: (state) => {
        return state.sidebarOpened ? 'el-icon-s-fold' : 'el-icon-s-unfold';
      },
    }),
    ...mapGetters(['userInfo']),
  },
  methods: {
    logout() {
      this.$router.push('/login');
      this.$store.dispatch('LogOut');
    },
    goto(url) {
      this.$router.push(url);
    },
    toggleExpand() {
      this.$store.dispatch('toggleSideBar');
    },
    checkTips(route) {
      let list = ['referee-page', 'recommend'];
      this.isShowTips = list.indexOf(route.name) > -1;
    },
  },
  watch: {
    $route(route) {
      this.checkTips(route);
    },
  },
  mounted() {
    this.checkTips(this.$router.history.current);
  },
};
</script>

<style lang="less" scoped>
.top-container {
  margin: 0 -20px;

  .header {
    background-color: #fff;
    height: 50px;
    padding: 0 20px;
    overflow: hidden;
    position: relative;
    z-index: 20;
    box-shadow: 0 1px 4px rgba(0, 21, 41, 0.08);

    .title {
      font-size: 20px;
      color: #30a5ff;
    }
  }

  .screen-small {
    padding: 0 20px;
    height: 40px;
    background-color: #f1f1f1;
    border-top: 1px solid #d8dce5;
  }

  .toggle {
    font-size: 20px;
    margin-top: 5px;
    margin-right: 10px;
    cursor: pointer;
  }
}
</style>
