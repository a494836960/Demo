<template>
  <div>
    <transition name="fadeTranslateX" mode="out-in">
      <router-view :key="keyPath" />
    </transition>
  </div>
</template>

<script>
export default {
  name: 'AppMain',
  computed: {
    keyPath() {
      return this.$route.fullPath;
    }
  }
}
</script>
