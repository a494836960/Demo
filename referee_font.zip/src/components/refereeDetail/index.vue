<!-- 裁判员详细信息 -->
<template>
  <div>
    <el-form label-width="115px" :model="info">
      <el-divider content-position="left">基本信息</el-divider>
      <el-row :gutter="20">
        <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
          <el-form-item label="注册归属省市：" prop="unitId">
            <span>{{ info.unitName }}</span>
          </el-form-item>
        </el-col>
        <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
          <el-form-item label="姓名(中文)：" prop="cnName">
            <span>{{ info.cnName }}</span>
          </el-form-item>
        </el-col>

        <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
          <el-form-item label="性别：" prop="sex">
            <MyBadge :list="GENDER" :target="info.sex"></MyBadge>
          </el-form-item>
        </el-col>
        <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
          <el-form-item label="政治面貌：" prop="political">
            <span>{{ info.political }}</span>
          </el-form-item>
        </el-col>
        <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
          <el-form-item label="民族：" prop="ethnicity">
            <span>{{ info.ethnicity }}</span>
          </el-form-item>
        </el-col>
        <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
          <el-form-item label="身高：" prop="height">
            <span>{{ info.height }} <span v-if="info.height">cm</span></span>
          </el-form-item>
        </el-col>

        <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
          <el-form-item label="姓名(拼音)：" prop="enName">
            {{ info.enSurname }} {{ info.enName }}
          </el-form-item>
        </el-col>

        <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
          <el-form-item label="出生日期：" prop="birthday">
            <span>{{ info.birthday | dateFormat(null, 'YYYY-MM-DD') }}</span>
          </el-form-item>
        </el-col>

        <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
          <el-form-item label="籍贯：" prop="area">
            <span>{{ info.province }}-{{ info.city }}</span>
          </el-form-item>
        </el-col>

        <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
          <el-form-item label="QQ：" prop="qq">
            <span>{{ info.qq || '-' }}</span>
          </el-form-item>
        </el-col>

        <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
          <el-form-item label="体重：" prop="weight">
            <span>{{ info.weight }} <span v-if="info.weight">kg</span></span>
          </el-form-item>
        </el-col>

        <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
          <el-form-item label="鞋码：" prop="shoeSize">
            <span>{{ info.shoeSize || '-' }}</span>
          </el-form-item>
        </el-col>

        <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
          <el-form-item label="服装尺码：" prop="clothSize">
            <span>{{ info.clothSize || '-' }}</span>
          </el-form-item>
        </el-col>

        <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
          <el-form-item label="户籍地址：" prop="contactAddress">
            <span>{{ info.contactAddress || '-' }}</span>
          </el-form-item>
        </el-col>

        <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
          <el-form-item label="健康状况：">
            <span>{{ info.health || '-' }}</span>
          </el-form-item>
        </el-col>
      </el-row>

      <el-divider content-position="left">工作情况</el-divider>
      <el-row :gutter="20">
        <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
          <el-form-item label="就职单位：" prop="inaugurationUnit">
            <span>{{ info.inaugurationUnit || '-' }}</span>
          </el-form-item>
        </el-col>

        <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
          <el-form-item label="就职单位电话：" prop="inaugurationUnitTel">
            <span>{{ info.inaugurationUnitTel || '-' }}</span>
          </el-form-item>
        </el-col>

        <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
          <el-form-item label="就职单位邮箱：" prop="inaugurationUnitEmail">
            <span>{{ info.inaugurationUnitEmail || '-' }}</span>
          </el-form-item>
        </el-col>

        <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
          <el-form-item label="就职单位地址：" prop="inaugurationUnitAddres">
            <span>{{ info.inaugurationUnitAddres || '-' }}</span>
          </el-form-item>
        </el-col>

        <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
          <el-form-item label="就职单位邮编：" prop="inaugurationUnitPasspot">
            <span>{{ info.inaugurationUnitPasspot || '-' }}</span>
          </el-form-item>
        </el-col>
      </el-row>

      <el-divider content-position="left">教育背景</el-divider>
      <el-row :gutter="20">
        <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
          <el-form-item label="教育背景：" prop="education">
            <span>{{ info.education || '-' }}</span>
          </el-form-item>
        </el-col>

        <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
          <el-form-item label="外语：" prop="language">
            <span>{{ info.language || '-' }}</span>
          </el-form-item>
        </el-col>

        <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
          <el-form-item label="外语等级：" prop="languageLevel">
            <MyBadge :list="languageLevel" :target="info.languageLevel"></MyBadge>
          </el-form-item>
        </el-col>

        <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
          <el-form-item label="职称：" prop="technicalTitle">
            <span>{{ info.technicalTitle || '-' }}</span>
          </el-form-item>
        </el-col>
      </el-row>

      <el-divider content-position="left">执裁经历</el-divider>
      <el-row :gutter="40">
        <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
          <el-form-item label="裁判等级：" prop="level">
            <MyBadge :list="LEVEL_TYPE" :target="info.level"></MyBadge>
          </el-form-item>
        </el-col>

        <el-col
          :md="md"
          :xl="xl"
          :lg="lg"
          :sm="sm"
          :xs="xs"
          v-if="info.level == 4 || info.level == 5"
        >
          <el-form-item label="技术类型：" prop="technical">
            <MyBadge :list="positionList" keys="code" :target="info.technical"></MyBadge>
          </el-form-item>
        </el-col>

        <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
          <el-form-item label="发证时间：" prop="prejudgeda">
            <span v-if="info.prejudgeda">{{ info.prejudgeda | dateFormat(null, 'YYYY-MM') }}</span>
          </el-form-item>
        </el-col>

        <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
          <el-form-item label="证书编号：" prop="certificateCode">
            <span>{{ info.certificateCode || '-' }}</span>
          </el-form-item>
        </el-col>

        <el-col :md="md" :xl="xl" :lg="lg" :sm="sm" :xs="xs">
          <el-form-item label="发证单位：" prop="certificateUnit">
            <span>{{ info.certificateUnit || '-' }}</span>
          </el-form-item>
        </el-col>

        <el-col :span="24">
          <el-form-item label="执裁经历：" prop="experience">
            <span>{{ info.experience || '-' }}</span>
          </el-form-item>
        </el-col>

        <el-col :span="24">
          <el-form-item label="特长：" prop="spec">
            <span>{{ info.specialityName && info.specialityName.join('、 ') }}</span>
          </el-form-item>
        </el-col>
      </el-row>

      <div>
        <p style="font-weight: bold;">赛事历程</p>
        <el-table border :data="gameList" class="page-top-space">
          <el-table-column prop="beginTime" label="赛事开始时间">
            <template slot-scope="scope">
              {{ scope.row.beginTime | dateFormat(null, 'YYYY-MM-DD') }}
            </template>
          </el-table-column>
          <el-table-column prop="gameNameCHN" label="赛事名称"></el-table-column>
          <el-table-column prop="gameSiteCHN" label="赛事地点"></el-table-column>
          <el-table-column prop="name" label="赛事岗位"></el-table-column>
        </el-table>
      </div>

      <el-divider content-position="left">证书上传</el-divider>
      <el-row style="text-align:center;">
        <el-col :span="6">
          <el-form-item prop="levelPhotoPath" label-width="0">
            <img :src="imgUrl + info.certificateCoverPath" alt="" class="certificate-img" @click="showPreview(info.certificateCoverPath)"/>
            <div>等级证书封面</div>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item prop="levelPhotoPath" label-width="0">
            <img :src="imgUrl + info.levelPhotoPath" alt="" class="certificate-img" @click="showPreview(info.levelPhotoPath)"/>
            <div>等级证书内容面</div>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item prop="certificateBackPath" label-width="0">
            <img :src="imgUrl + info.certificateBackPath" alt="" class="certificate-img" @click="showPreview(info.certificateBackPath)"/>
            <div>等级证书背面</div>
          </el-form-item>
        </el-col>

        <el-col :span="6" v-if="info.level == 4 || info.level == 5">
          <el-form-item prop="technicalPath" label-width="0">
            <img :src="imgUrl + info.technicalPath" alt="" class="certificate-img" @click="showPreview(info.technicalPath)"/>
            <div>技术官员证</div>
          </el-form-item>
        </el-col>
      </el-row>

      <el-divider content-position="left">审核状态</el-divider>
      <el-row :gutter="40">
        <el-col :span="12">
          <el-form-item prop="unitCheckStatus" label="主管单位审核">
            <span v-if="info.unitCheckStatus == 0" class="text-danger">
              未审核
            </span>
            <span v-else class="text-success">
              已审核
            </span>
          </el-form-item>
        </el-col>

        <el-col :span="12">
          <el-form-item prop="centerCheckStatus" label="中国田协审核">
            <span v-if="info.centerCheckStatus == 0" class="text-danger">
              未审核
            </span>
            <span v-else class="text-success">
              已审核
            </span>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <PreviewImg ref="preview" :url="url"></PreviewImg>
  </div>
</template>

<script>
import {fetchRefereeDetail} from '@/api/referee';
import {getGameListByReferee} from '@/api/game';
import {fetchSpeciality} from '@/api/common';
import {fetchPosition} from '@/api/position';
import {areas} from '@/common/area.js';
import political from '@/common/political';
import nation from '@/common/nation';
import {EDUCATION_TYPE, LANGUAGE_LEVEL, LANGUAGE_TYPE, GENDER, LEVEL_TYPE} from '@/const/index';
import PreviewImg from '@/components/previewImg';
export default {
  props: ['id'],
  components: {PreviewImg},
  data() {
    return {
      xl: 6,
      lg: 8,
      md: 8,
      xs: 24,
      sm: 12,
      GENDER: GENDER,
      LEVEL_TYPE: LEVEL_TYPE,
      languageList: LANGUAGE_TYPE,
      languageLevel: LANGUAGE_LEVEL,
      educationList: EDUCATION_TYPE,
      areasList: areas.provinces,
      politicalList: political, // 政治面貌list
      ethnicityList: nation, // 民族list

      imgUrl: this.imgUrl,
      formName: 'form',
      info: {},
      specialityMap: {},
      specialityList: [],
      gameList: [],
      url: '',
      positionList: []
    };
  },
  methods: {
    getGameList() {
      getGameListByReferee({refereeId: this.id}).then(res => {
        this.gameList = res.data.data;
      });
    },
    getSpeciality() {
      fetchSpeciality().then(res => {
        this.specialityList = res.data.data;
        res.data.data &&
          res.data.data.map(item => {
            this.specialityMap[item.code] = item.name;
          });
        this.parseSpeciality(this.info);
      });
    },

    showPreview(url){
      if(url){
        this.url = this.imgUrl + url;
        this.$refs.preview.showModal();
      }
    },

    parseSpeciality(item) {
      if (!this.validatenull(item.speciality)) {
        item.specialityName = '';
        item.speciality = item.speciality.replace(/[\[\]\s]/g, '');
        item.specialityName = item.speciality.split(',').map(item => {
          return this.specialityMap[item];
        });
      }
    },
    getData() {
      fetchRefereeDetail(this.id).then(res => {
        this.info = res.data.data;
        if (this.specialityList.length === 0) {
          this.getSpeciality();
        } else {
          this.parseSpeciality(this.info);
        }
      });
    },
    getPositionList() {
      fetchPosition({page_size: 1000}).then(res => {
        this.positionList = res.data.data.results;
        this.$set(this.info, 'technical', this.info.technical);
      });
    }
  },
  mounted() {
    this.getSpeciality();
    this.getPositionList();
  },
  watch: {
    id: function(newId, oldId) {
      this.getData(newId);
      this.getGameList();
    }
  }
};
</script>

<style lang="less" scoped>
.certificate-img {
  border: 1px solid #e1e1e1;
  width: 300px;
  height: 400px;
  display: block;
  margin: auto;
  border-radius: 5px;
  cursor: pointer;
}
.img {
  max-width: 300px;
  max-height: 300px;
}

.none-img {
  border: 1px solid #e1e1e1;
  border-radius: 5px;
  width: 250px;
  height: 150px;
  display: inline-block;
  padding: 50px;
  text-align: center;
}
</style>
