<!-- 输入框只能输入正数 -->
<template>
    <el-input :value="curValue" @input="handleInput" @change="handleChange" :placeholder="placeholder"
              :maxLength="maxLength"></el-input>
</template>

<script>
    import {reg} from '@/common/validate';
    import {validatenull} from "../../common/validate";

    export default {
        /*
        * 'value', 'max', 'min', 'double'
        * */
        props: {
            placeholder: {
                type: String,
            },
            value: {
                type: [String, Number], // \d*
                default: ''
            },
            max: { //比较数值
                type: Number,
            },
            min: { // 比较数值
                type: Number,
            },
            maxLength: {//校验数的位数
                type: Number
            },
            minLength: {//校验数的位数
                type: Number
            },
            double: { //如果为true则支持输入小数
                type: Boolean,
            }
        },
        data() {
            return {
                curValue: this.value
            }
        },

        methods: {
            handleInput(e) {
                let flag = false;
                if (this.double && reg.unsignedFloat.test(e)) {
                    flag = true;
                } else if (/^(-?\d+$|\d*)$/.test(e)) { // 只能输入数字
                    flag = true;
                }

                let value = Number(e);
                if (!validatenull(this.max) && this.max < value) {
                    flag = false;
                }

                if (!validatenull(this.min) && this.min > value) {
                    flag = false;
                }
                if (flag || this.validatenull(e)) {
                    this.curValue = e;
                    this.$emit('input', e);
                }
            },

            handleChange() {
                this.$emit('change', this.curValue);
            }
        },
        watch: {
            value(val) {
                this.handleInput(val);
            }
        }
    }
</script>
