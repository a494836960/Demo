<template>
  <div class="loading">
    <div class="loading-content">
      <Icon type="ios-loading" size="36" class="demo-spin-icon-load"></Icon>
    </div>
  </div>
</template>

<script>
  //加载中...
  export default {
    data() {
      return {};
    },
  }

</script>

<style lang="less">
  .loading {
    width: 300px;
    height: 185px;
 /*   background: #eee;
    border-radius: 5px;
    border: 1px solid #e1e1e1;*/
  }

  .loading-content {
    padding-top: 80px;
    text-align: center;
  }

  .demo-spin-icon-load {
    animation: ani-demo-spin 1s linear infinite;
  }
</style>
