<template>
    <el-aside :width="isCollapse?'0': '200px'" class="side-animal" style="overflow-x:hidden;">
        <el-menu
                router
                :default-openeds="menuOpens"
                :default-active="menuActive"
                unique-opened
        >
            <template v-for="(item, index) in list">
                <el-submenu v-if="item.children.length> 1" :key="index" :index="item.name">
                    <template slot="title">
                        <!--<i class="el-icon-location"></i>-->
                        <i class="font_family" :class="item.icon"></i>
                        <span>{{item.title}}</span>
                    </template>
                    <el-menu-item :key="i" :index="child.name" v-for="(child,i) in item.children"
                                  :route="{path: child.path}">
                        <span slot="title">{{child.title}}</span>
                    </el-menu-item>
                </el-submenu>

                <el-menu-item v-else :index="child.name" v-for="(child,i) in item.children" :key="index"
                              :route="{path: child.path}">
                    <span slot="title"> <i class="font_family" :class="item.icon"></i>{{child.title}}</span>
                </el-menu-item>
            </template>
        </el-menu>
    </el-aside>
</template>

<script>
    import {menuList} from '@/router/nav';
    import {IGNORE} from '@/router/nav';
    import {deepClone} from '@/common/util';
    import {getStore} from '@/common/store';

    export default {
        props: ['isCollapse'],
        data() {
            let permission = this.$store.getters.permissions;
            let children = [];
            let menu = deepClone(menuList);
            let isHistory = getStore({name: 'isHistory'});

            menu && menu.map(item => {
                children = [];
                item.children && item.children.map((child, index) => {
                    if (child.isMenu && (child.permission == IGNORE || permission[child.permission])) {
                        if (this.validatenull(child.groupType) || child.groupType === this.$store.state.user.arrangeMode) {
                            children.push(child);
                        }
                    }
                })
                item.children = children;
            })

            return {
                list: menu,
                menuActive: '',
                menuOpens: [],
            }
        },
        methods: {
            change(name) {
                if (name === this.baseName) {
                    this.reload();
                } else {
                    this.baseName = name;
                }
            },
            initMenu() {
                let current = this.$router.history.current.name;
                let flag = false;
                this.list.map(item => {
                    item.children && item.children.map(child => {
                        if (current == child.name) {
                            this.menuActive = child.name;
                            this.baseName = this.baseName ? this.baseName : child.name
                            flag = true;
                        }
                        if (flag) {
                            this.menuOpens = [item.name];
                            flag = false;
                        }
                    })
                })
            }
        },
        created() {
            this.initMenu();
        },
        watch: {
            '$route'(to, from) {
                this.initMenu();
            },
        }
    }
</script>

<style lang="less">
    .side-animal {
        transition: width 0.5s;

        .font_family {
            font-size: 17px;
            margin-right: 5px;
        }
    }

    .el-submenu .el-menu-item {
        padding-left: 65px !important;
    }
</style>
