<template>
    <div>
        <el-form>
            <el-form-item v-for="(item, index) in queryForm" :label="item.label">
                <el-input v-if="item.type === FORM_TYPES.INPUT" :placeholder="item.placeholder || `请选择${item.label}`"></el-input>
                <el-select v-if="item.type=== FORM_TYPES.SELECT" :placeholder="item.placeholder || `请选择${item.label}`">
                    <el-Option v-for="(option, optionIndex) in item.options" :key="optionIndex" :label="option.name" :value="option.value"></el-Option>
                </el-select>
            </el-form-item>
        </el-form>
    </div>
</template>

<script>
    /*
    ******************** 查询form 配置 ************************
    * 封装基本接口请求 增删改查
    * @param queryForm 查询参数   Array，
    *  ---- queryForm 属性说明
    *  --------- key:  required  后端接受字段， 如果传了 defaultValue 会和此字段绑定
    *  --------- type：required 前端展示类型 ['input', 'select', 'date']  如果是 select 需要添加 options 字段{options: 具体值同 el-select options}
    *  --------- label：choose 如果 showLabel 为 true 展示用
    *  --------- placeholder： choose 表单里的占位符； 如果为空 label不为空 可以使用label作为placeholder， `请输入+${label}` or `请选择+${label}`
    *  --------- event  blur、change、click 暂时支持这三个
    *
    *
    * @param search-button    是否展示查询按钮 Boolean
    * @param defaultValue  默认值  Object   key 和 queryForm 的 key 绑定
    * @param showLabel 是否展示 label  Boolean, 如果 为 true 展示 queryForm 里的 label 字段
    *
    *
    * ***************** table 配置 其它 和 element 一样 ***************************
    *  @param editable: choose  可编辑 默认 false
    *  @param addible:  choose  可添加 默认 false
    *  @param deletable:  choose  可删除 默认 false
    *
    * ************************* 操作按钮配置 *********************************
    *
    * */
    export default {
        props: {
            FORM_TYPES: {
                INPUT: 'input',
                SELECT: 'select'
            },

            queryForm: {
                type: Object,
                default: []
            }
        },
        data() {

        }
    }
</script>
