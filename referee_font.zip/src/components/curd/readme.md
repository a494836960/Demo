curd参数说明
==========

| 参数 | 说明 |必填 | 值类型| 默认值|
| --- | --- | --- | --- | --- | 
| queryForm | 查询参数 | 否 | Object |
| search-button| 是否展示 查询按钮| 否| Boolean| false |
|defaultValue| 初始化的时候默认值| 否 | Object|
| showLabel| 是否展示 label  Boolean, 如果 为 true 展示 queryForm 里的 label 字段 | 否| Boolean| false

queryForm
------------
| 参数| 说明| 必填| 值类型| 默认值|
|---|---|---|----|----|
| key| 后端接受字段| 是| String|
|type| 前端展示类型| 是| ['input', 'select', 'date']|
|label| 如果 showLabel 为 true 展示用|否| String|
|placeholder| 表单里的占位符 |否| String|
