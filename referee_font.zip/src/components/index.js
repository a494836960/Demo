import Vue from 'vue'
import MyBox from '@/components/myBox'
import MyBadge from '@/components/myBadge'
import UploadExcel from '@/components/myUpload/uploadExcel'
import UploadBatImgModal from '@/components/myUpload/uploadBatImgModal'
import UploadImg from '@/components/myUpload/uploadImg'
import uploadFile from '@/components/myUpload/uploadFile'
import VerifyCode from '@/components/verifyCode/index'
import InputNumber from '@/components/fpl-input/inputNumber'

Vue.component('MyBox', MyBox)
Vue.component('icon', () => import('./d2-icon'))
Vue.component("MyBadge", MyBadge)
Vue.component("UploadExcel", UploadExcel)
Vue.component("UploadBatImgModal", UploadBatImgModal)
Vue.component("UploadImg", UploadImg)
Vue.component("uploadFile", uploadFile)
Vue.component("VerifyCode", VerifyCode)
Vue.component("fpl-input-number", InputNumber);


