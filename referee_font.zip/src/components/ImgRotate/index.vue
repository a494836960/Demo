<template>
  <el-dialog
    title="图片旋转"
    :close-on-click-modal="false"
    :visible.sync="isShow"
    width="750px"
    @close="closeModal"
  >
    <div class="img-wrapper">
      <img :src="imgUrl + url" alt="图片旋转" :style="`transform: rotate(${deg}deg)`" class="img" />
    </div>
    <div style="text-align:center">
      <el-button type="primary" @click="doRotate(90)">
        <i class="el-icon-refresh-right"></i>
        旋转
      </el-button>
    </div>

    <div slot="footer">
      <el-button type="default" @click="closeModal">取消</el-button>
      <el-button type="primary" @click="submit">确认</el-button>
    </div>
  </el-dialog>
</template>

<script>
import modalMixin from '@/mixins/modalMixin';
export default {
  props: ['url'],
  data() {
    return {
      imgUrl: this.imgUrl,
      deg: 0,
      isShow: false,
    };
  },
  methods: {
    showModal() {
      this.deg = 0;
      this.isShow = true;
    },

    closeModal() {
      this.isShow = false;
    },
    doRotate(deg) {
      this.deg = this.deg + deg;
    },

    submit() {
      this.$emit('success', this.deg, this.url);
    },
  },
};
</script>
<style lang="less" scoped>
.img {
  max-width: 300px;
  max-height: 200px;
}
.img-wrapper {
  padding-top: 50px;
  height: 300px;
  padding-bottom: 50px;
  text-align: center;
}
</style>
