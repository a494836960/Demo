import request from '@/common/axios'

export function fetchSetting(id) {
    return request({
        url: `/api/sysSetting/registerState`,
        method: 'GET',
    })
}

export function updateSetting(data){
    return request({
        url: `/admin/sysSetting/update`,
        method: 'POST',
        data: data
    })
}
