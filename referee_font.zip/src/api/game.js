import request from '@/common/axios'

//获取赛事列表
export function fetchGameList(params) {
    return request({
        url: '/admin/game/pageList',
        method: 'get',
        params: params
    })
}

// 同步赛事
export function syncGame(params) {
    return request({
        url: '/admin/game/sync',
        method: 'post',
        params: params
    })
}

// 删除赛事
export function delGame(params) {
    return request({
        url: '/admin/game/delete',
        method: 'post',
        data: params
    })
}

// 批量导出赛事选派名单
export function batExportGame(params) {
    return request({
        url: '/admin/game/download/gameNameListTable',
        method: 'get',
        data: params,
        responseType: 'blob'
    })
}

// 裁判员名单导出
export function exportGame(params) {
    return request({
        url: `/admin/game/download/gameNameList/${params.gameId}`,
        method: 'get',
        data: params,
        responseType: 'blob'
    })
}

// 获取赛事裁判
export function fetchGameReferee(params) {
    return request({
        url: '/admin/gamePosition/listRefereePage',
        method: 'get',
        params: params
    })
}

// 赛事添加岗位
export function gameAddPosition(params) {
    return request({
        url: '/admin/gamePosition/add',
        method: 'post',
        data: params
    })
}

//赛事岗位删除
export function gameDelPosition(params) {
    return request({
        url: '/admin/gamePosition/deleteByIds',
        method: 'POST',
        data: params
    })
}

//删除赛事裁判
export function gameDelReferee(params) {
    return request({
        url: '/admin/gameRefereee/deleteByIds',
        method: 'POST',
        data: params
    })
}

//一键确认
export function gameConfirm(params) {
    return request({
        url: '/admin/game/confirm',
        method: 'POST',
        params: params
    })
}

//移除岗位裁判员
export function delPositionReferee(id) {
    return request({
        url: `/admin/gameRefereee/deleteByGamePositionId/${id}`,
        method: 'POST',
    })
}

// 添加岗位裁判员
export function addPositionReferee(params) {
    return request({
        url: `/admin/gameRefereee/add`,
        method: 'POST',
        data: params
    })
}

// 编辑赛事
export function updateGame(params) {
    return request({
        url: `/admin/game/updateById`,
        method: 'POST',
        data: params
    })
}

// 添加赛事
export function addGame(params) {
    return request({
        url: `/admin/game/add`,
        method: 'POST',
        data: params
    })
}

// 赛事审核
export function gameAudit(data) {
    return request({
        url: '/admin/game/audit',
        method: 'POST',
        data: data
    })
}

//发送短信通知裁判员
export function sendMsg(params) {
    return request({
        url: `/admin/gameRefereee/inform`,
        method: 'POST',
        data: params
    })
}

/********************** 录入选派 *************************/
export function fetchRecordList(params) {
    return request({
        url: `/admin/detailUserGame/findByDetailUserId`,
        method: 'get',
        params: params
    })
}

//录入审核
export function recordAudit(params) {
    return request({
        url: `/admin/game/auditInput`,
        method: 'post',
        data: params
    })
}

//录入选派详细信息
export function fetchRecordDetail(id) {
    return request({
        url: `/admin/gameRefereeRecord/findByGameId/${id}`,
        method: 'get'
    })
}

export function fetchGameDetail(id) {
    return request({
        url: `/admin/game/findByGameId/${id}`,
        method: 'get'
    })
}

//录入添加岗位
export function addRecordPosition(params) {
    return request({
        url: `/admin/gamePositionRecord/adds`,
        method: 'post',
        data: params
    })
}

// 删除录入岗位
export function delRecordPosition(params) {
    return request({
        url: `/admin/gamePositionRecord/deleteByIds`,
        method: 'post',
        data: params
    })
}

//删除裁判
export function delRecordReferee(params) {
    return request({
        url: `/admin/gameRefereeRecord/deleteByIds`,
        method: 'post',
        data: params
    })
}

// 录入 添加/编辑裁判
export function editRecordReferee(params) {
    return request({
        url: `/admin/gameRefereeRecord/update`,
        method: 'post',
        data: params
    })
}

// 查询 按名称查询裁判员
export function fetchRefereeByName(params) {
    return request({
        url: '/admin/tempReferee/search',
        method: 'get',
        params: params
    })
}

// 根据RefereeId查询赛事列表
export function getGameListByReferee(params) {
    return request({
        url: '/admin/gameRefereee/findInfoBy',
        method: 'get',
        params: params
    })
}

//查询所有赛事
export function fetchGameAll(params) {
    return request({
        url: '/admin/game/listAll',
        method: 'post',
        data: params
    })
}

// 赛事重新提交审核
export function reapplyAudit(params){
    return request({
        url: '/admin/game/commitByIds',
        method: 'POST',
        data: params
    })
}