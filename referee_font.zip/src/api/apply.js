import request from '@/common/axios'

//查询list
export function fetchScanList(params) {
    return request({
        url: '/admin/unitRefereeFile/listPage',
        method: 'post',
        data: params
    })
}

// 添加裁判员扫描件
export function addRefereeScan(params) {
    return request({
        url: '/admin/unitRefereeFile/add',
        method: 'post',
        data: params
    })
}

// 上传裁判员临时文件
export function uploadRefereeScan(params) {
    return request({
        url: '/admin/unitRefereeFile/add',
        method: 'post',
        data: params
    })
}

//删除扫描件
export function delScan(params) {
    return request({
        url: '/admin/unitRefereeFile/deleteById',
        method: 'post',
        params: params
    })
}

//打包下载
export function downLoadPacket(params) {
    return request({
        url: '/admin/unitRefereeFile/downloadAll',
        method: 'get',
        data: params,
        responseType: 'arraybuffer'
    })
}
