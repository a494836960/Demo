import request from '@/common/axios';

//获取登录单位列表
export function getLoginUnitList() {
  return request({
    url: '/api/unit/list',
    method: 'POST',
  });
}

//特长列表
export function fetchSpeciality() {
  return request({
    url: '/api/specialityType/list',
    method: 'get',
  });
}

//获取 开放注册的裁判等级
export function fetchRefereeLevel() {
  return request({
    url: '/api/referee/level/list',
    method: 'get',
  });
}

//注册
export function register(params) {
  return request({
    url: '/api/user/register',
    method: 'POST',
    data: params,
  });
}

//是否开放注册
export function registerState() {
  return request({
    url: '/api/sysSetting/registerState',
    method: 'get',
  });
}

export function sendRegisterMsg(params) {
  return request({
    url: '/api/user/register/sendMsg',
    method: 'POST',
    params: params,
  });
}

// 忘记密码
export function forgetIsMobile(params) {
  return request({
    url: '/api/user/isMobile',
    method: 'POST',
    params: params,
  });
}

// 忘记密码 获取验证码
export function forgetSendMsg(params) {
  return request({
    url: '/api/user/sendCode',
    method: 'POST',
    params: params,
  });
}

// 忘记密码 获取验证码
export function forgetUpdatePwd(params) {
  return request({
    url: '/api/user/updatePwd',
    method: 'POST',
    params: params,
  });
}

// 文件旋转
export function rotateImg(params) {
  return request({
    url: '/api/resource/rotate',
    method: 'GET',
    params: params,
    responseType: 'arraybuffer',
  });
}
