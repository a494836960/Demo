import request from '@/common/axios'

export function delPosition(id) {
    return request({
        url: `/admin/position/deleteById/${id}`,
        method: 'POST',
    })
}

export function addPosition(params) {
    return request({
        url: `/admin/position/add`,
        method: 'POST',
        data: params
    })
}

export function updatePosition(params) {
    return request({
        url: `/admin/position/edit`,
        method: 'POST',
        data: params
    })
}

export function fetchPosition(params) {
    return request({
        url: `/admin/position/listPage`,
        method: 'GET',
        params: params
    })
}

export function moveUpPosition(id) {
    return request({
        url: `/admin/position/moveUp/${id}`,
        method: 'POST',
    })
}

export function moveDownPosition(id) {
    return request({
        url: `/admin/position/moveDown/${id}`,
        method: 'POST',
    })
}

