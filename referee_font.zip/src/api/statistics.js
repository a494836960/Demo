import request from '@/common/axios'

//裁判员等级统计
export function fetchRefereeLevel(params) {
    return request({
        url: '/admin/referee/countLevel',
        method: 'post',
        data: params
    })
}

//裁判员等级报表导出
export function exportRefereeLevel(params) {
    return request({
        url: '/admin/referee/exportCountLevel',
        method: 'GET',
        responseType: 'arraybuffer',
        params: params
    })
}


//裁判员特长统计
export function fetchRefereeSpeciality(params) {
    return request({
        url: '/admin/referee/countSpeciality',
        method: 'POST',
        data: params
    })
}

//裁判员特长报表导出
export function exportRefereeSpeciality(params) {
    return request({
        url: '/admin/referee/exportCountSpeciality',
        method: 'POST',
        responseType: 'arraybuffer',
        params: params
    })
}
