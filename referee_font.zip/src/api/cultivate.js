import request from '@/common/axios'
import {GAME_SOURCE} from '@/const/index'
export function fetchCultivate(params) {
    params.newsTypes = [3]; // 查询报名
    return request({
        url: '/admin/newsNotice/listPage',
        method: 'post',
        data: params
    })
}

// 获取培训报名人员
export function fetchCultivateReferee(params) {
    return request({
        url: '/admin/refereeSignup/listPage',
        method: 'post',
        data: params
    })
}

export function addCultivate(params) {
    return request({
        url: '/admin/game/add/signup',
        method: 'post',
        data: params
    })
}

export function updateCultivate(params) {
    return request({
        url: '/admin/game/updateById',
        method: 'post',
        data: params
    })
}

//删除培训
export function delCultivate(params) {
    return request({
        url: `/admin/game/deleteSignupById?id=${params.id}`,
        method: 'post',
        data: params
    })
}

/*************** 培训单位名称 ***************/
export function fetchUnit(data) {
    return request({
        url: `/admin/gameUnit/listPage`,
        method: 'post',
        data: data
    })
}

//批量添加培训单位
export function addUnit(data) {
    return request({
        url: `/admin/gameUnit/adds`,
        method: 'post',
        data: data
    })
}

//  修改报名单位报名人数
export function updateUnit(data) {
    return request({
        url: `/admin/gameUnit/updateById`,
        method: 'post',
        data: data
    })
}

// 删除报名单位
export function delUnit(data) {
    return request({
        url: `/admin/gameUnit/deleteByIds`,
        method: 'post',
        data: data
    })
}

/************* 报名名单 *************/
export function fetchGameReferee(data){
    return request({
        url: '/admin/gameUnitReferee/listPage',
        method: 'post',
        data:data
    })
}

// 添加个人报名
export function addGameReferee(data) {
    return request({
        url: '/admin/gameUnitReferee/add/signup',
        method: 'post',
        data:data
    })
}

export function delGameReferee(data) {
    return request({
        url: `/admin/gameUnitReferee/deleteById?id=${data}`,
        method: 'post',
    })
}

// 编辑裁判报名
export function updateGameReferee(data) {
    return request({
        url: `/admin/gameUnitReferee/updateById`,
        method: 'post',
        data:data
    })
}

// 培训审核
export function audit(params){
    return request({
        url: `/admin/gameUnitReferee/audit`,
        method: 'POST',
        data: params
    })
}
