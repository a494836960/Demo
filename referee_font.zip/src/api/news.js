import request from '@/common/axios';

//获取新闻列表
export function fetchNewsList(params) {
  return request({
    url: '/admin/newsNotice/listPage',
    method: 'POST',
    data: params
  });
}
// 添加修改新闻
export function updateNews(params) {
  return request({
    url: '/admin/newsNotice/update',
    method: 'POST',
    data: params
  });
}

// 查询文章详情
export function findNews(params) {
  return request({
    url: '/admin/newsNotice/findById',
    method: 'GET',
    params: params
  });
}
