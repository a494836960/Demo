import request from '@/common/axios'

export function fetchRefereeList(params) {
    return request({
        url: `/admin/referee/pageList`,
        method: 'GET',
        params: params
    })
}

export function resetPwd(data) {
    return request({
        url: `/admin/referee/reset`,
        method: 'POST',
        data: data
    })
}

//单位审核
export function unitAudit(data) {
    return request({
        url: `/admin/referee/updateUnitCheck`,
        method: 'POST',
        data: data
    })
}

//中心审核
export function centerAudit(data) {
    return request({
        url: `/admin/referee/updateCenterCheck`,
        method: 'POST',
        data: data
    })
}

//添加裁判
export function addReferee(data) {
    return request({
        url: `/admin/referee/add`,
        method: 'POST',
        data: data
    })
}

//修改裁判
export function updateReferee(data) {
    return request({
        url: `/admin/referee/update`,
        method: 'POST',
        data: data
    })
}

// 裁判推荐
export function RecommendReferee(data) {
    return request({
        url: `/admin/referee/isRecommend`,
        method: 'POST',
        data: data
    })
}

export function fetchRecommendTemplate() {
    return '/api/resource/recommend/templet';
}

// 导入推荐
export function importRecommend(params) {
    return request({
        url: '/admin/referee/import/recommend',
        method: 'post',
        data: params
    })
}

// 导出推荐
export function exportRecommend(params) {
    return request({
        url: `/admin/referee/export/recommend?unitId=${params.unitId || ''}`,
        method: 'POST',
        responseType: 'arraybuffer',
    })
}

//获取裁判详细信息
export function fetchRefereeDetail(id) {
    return request({
        url: `/admin/referee/${id}`,
        method: 'GET',
    })
}

// 获取裁判培训报名列表
export function fetchGameReferee(params){
    return request({
        url: `/admin/gameUnitReferee/findList`,
        method: 'POST',
        data: params
    })
}

// 导出裁判员报名登记表
export function exportRegistryForm(id){
    return request({
        url: `/admin/gameUnitReferee/exportSignupById?id=${id}`,
        method: 'GET',
        responseType: 'arraybuffer'
    })
}


























