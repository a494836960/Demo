import request from '@/common/axios'

/************ 角色管理 ************/

//获取角色列表
export function fetchRoleList(params) {
    return request({
        url: '/admin/authority/listPage',
        method: 'get',
        params: params
    })
}

//删除权限
export function delRole(params) {
    return request({
        url: '/admin/authority/deleteById',
        method: 'get',
        params: params
    })
}

//修改权限
export function updateRole(params) {
    return request({
        url: '/admin/authorityResources/update',
        method: 'POST',
        data: params
    })
}



//获取角色的权限  authorityId , resultType
export function fetchRolePermissionById(params) {
    return request({
        url: `/admin/resources/findByAuthorityId`,
        method: 'GET',
        params: params
    })
}

//获取当前用户的所有权限
export function fetchCurPermission(params) {
    return request({
        url: `/admin/resources/all`,
        method: 'GET',
        params: params
    })
}

//绑定资源
export function bandResource(params) {
    return request({
        url: '/admin/authorityResources/adds',
        method: 'post',
        data: params
    })
}

/********************** 资源管理 *********************/

// 添加资源
export function addResource(params) {
    return request({
        url: '/admin/resources/add',
        method: 'POST',
        data: params
    })
}

// 修改资源
export function updateResource(params) {
    return request({
        url: '/admin/resources/updateById',
        method: 'POST',
        data: params
    })
}

// 删除资源
export function delResource(params) {
    return request({
        url: '/admin/resources/deleteById',
        method: 'get',
        params: params
    })
}


export function fetchResourceList(params) {
    return request({
        url: '/admin/resources/list',
        method: 'get',
        params: params
    })
}

//上移动资源
export function moveUpResource(id) {
    return request({
        url: `/admin/resources/moveUp?id=${id}`,
        method: 'GET',
    })
}

//下移动资源
export function moveDownResource(id) {
    return request({
        url: `/admin/resources/moveDown?id=${id}`,
        method: 'GET',
    })
}
