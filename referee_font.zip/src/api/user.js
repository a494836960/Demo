import request from '@/common/axios'
import {base64EnCode} from "@/common/util";

//获取登录单位列表
export function login(data) {
    return request({
        url: '/oauth/token',
        method: 'POST',
        params: {
            ...data,
            grant_type: 'password'
        },
        headers: {
            Authorization: `Basic ${base64EnCode('web:secret')}`
        },
    })
}

// 登录手机验证码
export function loginVerify(params) {
    return request({
        url: '/api/user/send/loginCode',
        method: 'GET',
        params: params
    })
}


// 获取登录用户的 用户信息
export function fetchUserInfo(data) {
    return request({
        url: '/admin/user/get',
        method: 'GET',
    })
}

//获取手机验证码
export function fetchMobileVerify(data) {
    return request({
        url: '/admin/user/validate/mobile',
        method: 'POST',
        params: data,
    })
}

//  修改当前用户， 用户名
export function updateUsername(data) {
    return request({
        url: '/admin/user/update/userName',
        method: 'POST',
        params: data,
    })
}

//修改手机号码
export function updateMobile(data) {
    return request({
        url: '/admin/user/update/mobile',
        method: 'POST',
        params: data
    })
}

//修改邮箱
export function updateEmail(data) {
    return request({
        url: '/admin/user/update/email',
        method: 'POST',
        params: data
    })
}

//修改密码
export function updatePwd(data) {
    return request({
        url: '/admin/user/update/pwd',
        method: 'POST',
        data: data
    })
}

// 查询用户权限
export function fetchUserPermission(data) {
    return request({
        url: `/admin/resources/all`,
        method: 'get',
        params: {resultType: 1}
    })
}

/*************** 用户管理 ******************/

export function fetchUserPage(data) {
    return request({
        url: '/admin/user/list',
        method: 'POST',
        params: data,
    })
}

//新增、编辑用户
export function updateUser(data) {
    return request({
        url: '/admin/user/update',
        method: 'POST',
        data: data,
    })
}

//更新用户状态
export function updateUserStatus(data) {
    return request({
        url: '/admin/user/updateActiva',
        method: 'POST',
        data: data,
    })
}
