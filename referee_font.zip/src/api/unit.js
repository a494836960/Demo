import request from '@/common/axios'

export function fetchUnitPage(params) {
    return request({
        url: `/admin/unit/pageList`,
        method: 'POST',
        params: params
    })
}

export function updateUnit(params) {
    return request({
        url: `/admin/unit/update`,
        method: 'POST',
        data: params
    })
}


export function addUnit(params) {
    return request({
        url: `/admin/unit/add`,
        method: 'POST',
        data: params
    })
}

export function fetchUnitDetail(id){
    return request({
        url: `/admin/unit/getById/${id}`,
        method: 'GET',
    })
}

export function fetchUnitPeopleNumber(){
    return request({
        url: `/admin/unit/count`,
        method: 'GET',
    })
}

export function fetchUnitAll(){
    return request({
        url: `/api/unit/all`,
        method: 'GET',
    })
}
