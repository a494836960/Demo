export const ROLE = {
  system: 'ROLE_SYSTEM_ADMIN', //系统管理员
  admin: 'ROLE_ADMIN', // 超级管理员
  unit: 'ROLE_USER', //  单位用户
  personal: 'ROLE_PERSONAL', // 裁判员用户
  record: 'ROLE_DETAIL_INPUT', // 赛事选派录入
  APPLY: 'GAME_APPLE' // 赛事申报员登录
};
export const CLOTHES_SIZE_LIST = [
  {
    name: 'XS',
    value: 'XS'
  },
  {
    name: 'S',
    value: 'S'
  },
  {
    name: 'M',
    value: 'M'
  },
  {
    name: 'L',
    value: 'L'
  },
  {
    name: 'XL',
    value: 'XL'
  },
  {
    name: 'XXL',
    value: 'XXL'
  },
  {
    name: '3XL',
    value: '3XL'
  },
  {
    name: '4XL',
    value: '4XL'
  },
  {
    name: '5XL',
    value: '5XL'
  }
];

export const SHOES_SIZE_LIST = [
  {
    name: '34',
    value: '34'
  },
  {
    name: '35',
    value: '35'
  },
  {
    name: '36',
    value: '36'
  },
  {
    name: '37',
    value: '37'
  },
  {
    name: '38',
    value: '38'
  },
  {
    name: '39',
    value: '39'
  },
  {
    name: '40',
    value: '40'
  },
  {
    name: '40.5',
    value: '40.5'
  },
  {
    name: '41',
    value: '41'
  },
  {
    name: '42',
    value: '42'
  },
  {
    name: '43',
    value: '43'
  },
  {
    name: '44',
    value: '44'
  },
  {
    name: '45',
    value: '45'
  },
  {
    name: '46',
    value: '46'
  },
  {
    name: '47',
    value: '47'
  },
  {
    name: '48',
    value: '48'
  },
  {
    name: '49',
    value: '49'
  }
];
// 	用户类型：0.单位用户，1.个人用户，2.录入选派用户,查询多种类型用“，”分割
export const USER_TYPE = {
  UNIT: '0',
  PERSONAL: '1',
  RECORD: '2'
};

export const USER_ACTIVE = [
  {name: '已激活', value: true, style: 'success'},
  {name: '未激活', value: false, style: 'error'}
];

export const IS_OPEN = [
  {name: '未开放', value: 0, style: 'error'},
  {name: '报名中', value: 1, style: 'success'},
  {name: '报名结束', value: 2, style: 'default'}
];

//语言类别
export const LANGUAGE_TYPE = [
  {name: '英语', value: '英语'},
  {name: '日语', value: '日语'},
  {name: '俄语', value: '俄语'},
  {name: '韩语', value: '韩语'},
  {name: '西班牙语', value: '西班牙语'},
  {name: '意大利语', value: '意大利语'}
];
//语言等级
export const LANGUAGE_LEVEL = [
  {name: '一般', value: 1},
  {name: '良好', value: 2},
  {name: '熟练', value: 3},
  {name: '精通', value: 4}
];

// 教育背景
export const EDUCATION_TYPE = [
  {name: '专科', value: '专科'},
  {name: '本科', value: '本科'},
  {name: '研究生', value: '研究生'},
  {name: '硕士', value: '硕士'},
  {name: '博士', value: '博士'}
];

export const RECOMMEND_TYPE = [
  {name: '未推荐', value: 0, style: 'error'},
  {name: '已推荐', value: 1, style: 'success'}
];

// -2.拒绝，-1.已申请，0.待确认，1.待执行,2.待总结，3.完成
export const CONFIRM_TYPE_CODE = {
  UNCONFIRM: 0,
  CONFIRM: 1,
  LEAVE: -2,
  APPLY: -1,
  WAIT_SUMMARY: 2,
  COMPLETE: 3
};

export const CONFIRM_TYPE = [
  {name: '待确认', value: CONFIRM_TYPE_CODE.UNCONFIRM, style: 'progress'},
  {name: '已确认', value: CONFIRM_TYPE_CODE.CONFIRM, style: 'success'},
  {name: '已请假', value: CONFIRM_TYPE_CODE.LEAVE, style: 'error'},
  {name: '待总结', value: CONFIRM_TYPE_CODE.WAIT_SUMMARY, style: 'info'},
  {name: '已完成', value: CONFIRM_TYPE_CODE.COMPLETE, style: 'default'}
];

export const GENDER_CODE = {
  MALE: 0,
  FEMALE: 1
};

export const GENDER = [
  {name: '男', value: GENDER_CODE.MALE},
  {name: '女', value: GENDER_CODE.FEMALE}
];

export const LEVEL_TYPE_CODE = {
  '1': '一级',
  '2': '二级',
  '3': '三级',
  '4': '国家级',
  '5': '国际级'
};

export const LEVEL_TYPE = [
  {name: '一级', value: 1},
  {name: '二级', value: 2},
  {name: '三级', value: 3},
  {name: '国家级', value: 4},
  {name: '国际级', value: 5},
  {name: '无', value: ''}
];

export const AUDIT_TYPE_CODE = {
  AUDITED: true,
  UNAUDITED: false
};
export const AUDIT_TYPE = [
  {name: '未审核', value: false, style: 'error'},
  {name: '已审核', value: true, style: 'success'}
];

export const NOTIFY_STATUS = [
  {name: '未通知', value: 0, style: 'error'},
  {name: '已通知', value: 1, style: 'success'}
];

export const GAME_SOURCE = {
  SYNC: 1, //同步数据
  ADD_GAME: 2, //新增的普通赛事
  CULTIVATE_PLAN: 3, //培训计划
  CULTIVATE_APPLY: 4, //培训报名
  RECOMMEND_PLAN: 5 // 推荐计划
};

// 培训报名状态 -1.报名失败，0.待审核，1.报名成功

export const CULTIVATE_REFEREE_STATUS_CODE = {
  FAIL: -1,
  WAIT: 0,
  SUCCESS: 1
};
export const CULTIVATE_REFEREE_STATUS = [
  {name: '报名失败', value: CULTIVATE_REFEREE_STATUS_CODE.FAIL, style: 'error'},
  {name: '待审核', value: CULTIVATE_REFEREE_STATUS_CODE.WAIT, style: 'progress'},
  {name: '报名成功', value: CULTIVATE_REFEREE_STATUS_CODE.SUCCESS, style: 'success'}
];

//账号类型
export const ACCOUNT_TYPE_CODE = {
  PERSONAL: 1,
  UNIT: 0
};

export const ACCOUNT_TYPE = [
  {name: '个人', value: ACCOUNT_TYPE_CODE.PERSONAL},
  {name: '单位', value: ACCOUNT_TYPE_CODE.UNIT}
];

export const GAME_TYPE = [
  {name: '国际一般运动会', value: 0},
  {name: '国际室内运动会', value: 1},
  {name: '国际残疾人运动会', value: 2},
  {name: '国内一般运动会', value: 3},
  {name: '国内室内运动会', value: 4},
  {name: '国内残疾人运动会', value: 5}
];

// sortType	是	int	组别类型：0.标准，1.青年，2.少年，-1.其他
export const SORT_TYPE = [
  {name: '标准组', value: 0},
  {name: '青年组', value: 1},
  {name: '少年组', value: 2},
  {name: '其他组', value: -1}
];

// 赛事审核状态 -1.不通过，0.未审核，1.已审核
export const GAME_AUDIT_STATUS_CODE = {
  FAIL: -1,
  WAIT: 0,
  PASS: 1
};

export const GAME_AUDIT_STATUS = [
  {name: '驳回', value: GAME_AUDIT_STATUS_CODE.FAIL, style: 'error'},
  {name: '待审核', value: GAME_AUDIT_STATUS_CODE.WAIT, style: 'progress'},
  {name: '通过', value: GAME_AUDIT_STATUS_CODE.PASS, style: 'success'}
];

export const MATCH_LEVEL_LIST = [
  {name: 'OW', value: 'OW'},
  {name: 'DF', value: 'DF'},
  {name: 'GW', value: 'GW'},
  {name: 'GL', value: 'GL'},
  {name: 'A', value: 'A'},
  {name: 'B', value: 'B'},
  {name: 'C', value: 'C'},
  {name: 'D', value: 'D'},
  {name: 'E', value: 'E'},
  {name: 'F', value: 'F'}
];

/******* 新闻类型 *******/
export const NEWS_TYPE_CODE = {
  NEWS: 1,
  NOTIFY: 2,
  APPLY: 3
};
//1.新闻，2.通知，3.报名
export const NEWS_TYPE = [
  {name: '新闻', value: NEWS_TYPE_CODE.NEWS},
  {name: '通知', value: NEWS_TYPE_CODE.NOTIFY},
  {name: '报名', value: NEWS_TYPE_CODE.APPLY}
];
// 0.保存不发布，1.保存并发布
export const PUBLISH_STATE_CODE = {
  UNPUBLISHED: 0,
  PUBLISH: 1
};
export const PUBLISH_STATE = [
  {name: '未发布', value: PUBLISH_STATE_CODE.UNPUBLISHED, style: 'default'},
  {name: '已发布', value: PUBLISH_STATE_CODE.PUBLISH, style: 'success'}
];

// 裁判员必填字段校验
export const refereeValidator = {
  qq: [
    {
      required: true,
      message: '请输入QQ'
    }
  ],
  weight: [
    {
      required: true,
      message: '请输入体重'
    }
  ],
  height: [
    {
      required: true,
      message: '请输入身高'
    }
  ],
  health: [
    {
      required: true,
      message: '请输入健康状况'
    }
  ],
  idcardBackPath: [
    {
      required: true,
      message: '请上传身份证反面'
    }
  ],
  idcardFacePath: [
    {
      required: true,
      message: '请上传身份证正面'
    }
  ],
  clothSize: [
    {
      required: true,
      message: '请选择服装尺码'
    }
  ],
  enSurname: [
    {
      required: true,
      message: '请输入姓（拼音）'
    }
  ],
  enName: [
    {
      required: true,
      message: '请输入名（拼音）'
    }
  ],
  shoeSize: [
    {
      required: true,
      message: '请选择鞋码'
    }
  ],
  photo: [
    {
      required: true,
      message: '请上传头像',
      trigger: 'change'
    }
  ],

  inaugurationUnitEmail: [
    {
      required: true,
      message: '请完善邮箱地址',
      trigger: 'blur'
    }
  ],
  contactAddress: [
    {
      required: true,
      message: '户籍地址不能为空！',
      trigger: 'blur'
    }
  ],
  unitId: [
    {
      required: true,
      message: '注册所属省市不能为空！',
      trigger: 'change'
    }
  ],
  cnName: [
    {
      required: true,
      message: '中文姓名不能为空！',
      trigger: 'blur'
    }
  ],

  idcard: [
    {
      required: true,
      message: '身份证不能为空！',
      trigger: 'blur'
    }
  ],
  area: [
    {
      required: true,
      message: '裁判归属地不能为空！',
      trigger: 'change'
    }
  ],
  sex: [
    {
      required: true,
      message: '性别不能为空！',
      trigger: 'change'
    }
  ],
  political: [
    {
      required: true,
      message: '政治面貌不能为空！',
      trigger: 'change'
    }
  ],
  prejudgeda: [
    {
      required: true,
      message: '发证时间不能为空',
      trigger: 'change'
    }
  ],
  certificateUnit: [
    {
      required: true,
      message: '发证单位不能为空',
      trigger: 'change'
    }
  ],
  certificateCode: [
    {
      required: true,
      message: '证书编号不能为空',
      trigger: 'change'
    }
  ],
  inaugurationUnitTel: [
    {
      required: true,
      message: '工作单位电话不能为空',
      trigger: 'blur'
    }
  ],
  ethnicity: [
    {
      required: true,
      message: '民族不能为空！',
      trigger: 'change'
    }
  ],
  mobile: [
    {
      required: true,
      message: '电话号码不能为空！',
      trigger: 'blur'
    }
  ],
  firstName: [
    {
      required: true,
      message: '姓不能为空！',
      trigger: 'blur'
    }
  ],
  lastName: [
    {
      required: true,
      message: '名不能为空！',
      trigger: 'blur'
    }
  ],
  birthday: [
    {
      required: true,
      message: '出生日期不能为空！',
      trigger: 'change'
    }
  ],
  inaugurationUnit: {
    required: true,
    message: '请输入工作单位',
    trigger: 'blur'
  },
  education: {
    required: true,
    message: '请选择学历',
    trigger: 'change'
  },
  level: {
    required: true,
    message: '请选择裁判等级',
    trigger: 'change'
  },
  levelPhotoPath: {
    required: true,
    message: '请上传证书扫描件',
    trigger: 'change'
  },
  speciality: {
    required: true,
    message: '请选择特长',
    trigger: 'change'
  },
  spec: {
    required: true,
    message: '请选择特长',
    trigger: 'change'
  },
  
};
