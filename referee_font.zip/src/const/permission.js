//岗位管理权限
export const per = {
    referee_info: 'referee_info',//裁判个人信息
    personal_cultivate: 'personal_cultivate', // 培训报名
    personal_experience: 'personal_experience', // 执裁经历
    referee_info_update: 'referee_info_update',//修改个人信息
    referee_info_add: 'referee_info_add',//添加个人信息
    referee_info_detail: 'referee_info_detail',//裁判个人详情


    account_manage: 'account_manage',//个人账户
    account_base_info: 'account_base_info',//基本信息
    account_password_update: 'account_password_update',//修改密码

    system_manage: 'system_manage',//系统中心
    system_position_manage: 'system_position_manage',//岗位管理
    system_position_add: 'system_position_add',//新增岗位
    system_position_update: 'system_position_update',//修改岗位
    system_position_delete: 'system_position_delete',//删除岗位
    system_position_sort: 'system_position_sort',//岗位排序




    system_user_record: 'system_user_record', // 查看选派录入用户
    system_user_record_add: 'system_user_record_add', // 添加用户
    system_user_record_update: 'system_user_record_update', // 修改用户
    system_user_record_active: 'system_user_record_active', //激活用户

    system_user_unit: 'system_user_unit', // 查看单位用户
    system_user_unit_add: 'system_user_unit_add', // 添加用户
    system_user_unit_update: 'system_user_unit_update', // 修改用户
    system_user_unit_active: 'system_user_unit_active', //激活用户

    system_user_personal: 'system_user_personal', // 查看单位用户
    system_user_personal_add: 'system_user_personal_add', // 添加用户
    system_user_personal_update: 'system_user_personal_update', // 修改用户
    system_user_personal_active: 'system_user_personal_active', //激活用户

    system_setting: 'system_setting',//系统设置
    system_setting_update: 'system_setting_update',//修改系统设置

    unit_manage: 'unit_manage',//单位列表
    unit_add: 'unit_add',//新增单位
    unit_update: 'unit_update',//修改单位

    game_list_manage: 'game_list_manage',//赛事列表
    game_add: 'game_add', //添加赛事
    game_delete: 'game_delete',//删除赛事
    game_update: 'game_update',//赛事编辑
    game_list_audit: 'game_list_audit', //赛事审核
    



    game_dispatch_manage: 'game_dispatch_manage',// 查看赛事选派
    game_sync: 'game_sync',//赛事同步
    game_export: 'game_export',//赛事批量导出
    game_dispatch: 'game_dispatch',//赛事选派
    game_export_list: 'game_export_list',//导出名单
    game_dispatch_position_add: 'game_dispatch_position_add', //添加岗位
    game_dispatch_position_del: 'game_dispatch_position_del', //移除岗位
    game_dispatch_referee_del: 'game_dispatch_referee_del', //移除裁判员
    game_dispatch_send_msg: 'game_dispatch_send_msg',// 发送短信通知
    game_dispatch_confirm: 'game_dispatch_confirm',// 确认选派
    game_dispatch_referee_export: 'game_dispatch_referee_export',// 导出裁判选派名单
    game_dispatch_referee_add: 'game_dispatch_referee_add',// 添加岗位裁判员

    game_record_manage: 'game_record_manage',//录入选派
    game_audit: 'game_audit',//录入审核
    game_cancel_audit: 'game_cancel_audit',//取消审核
    game_record_dispatch: 'game_record_dispatch',//选派

    record_dispatch_position_add:'record_dispatch_position_add',//添加岗位
    record_dispatch_referee_add: 'record_dispatch_referee_add',// 录入裁判
    record_dispatch_referee_del: 'record_dispatch_referee_del',//移除裁判
    record_dispatch_position_del: 'record_dispatch_position_del',// 移除岗位

    referee_manage: 'referee_manage',//裁判列表
    referee_add: 'referee_add',//新增裁判
    referee_export_recommend: 'referee_export_recommend',//导出推荐
    referee_import_recommend: 'referee_import_recommend',// 导入裁判推荐
    referee_reset_pwd: 'referee_reset_pwd',//重置密码
    referee_update: 'referee_update',//编辑裁判
    referee_audit_unit: 'referee_audit_unit',//单位审核裁判
    referee_audit_center: 'referee_audit_center',//中心审核裁判
    referee_recommend: 'referee_recommend',//推荐裁判

    referee_recommend_manage: 'referee_recommend_manage', //裁判推荐列表
    referee_recommend_do: 'referee_recommend_do', //推荐裁判
    referee_recommend_export: 'referee_recommend_export', //导出推荐
    referee_recommend_import: 'referee_recommend_import', //导入推荐


    /**一二级裁判员管理 */
    referee_rookie_manage: 'referee_rookie_manage',
    referee_rookie_add: 'referee_rookie_add', // 裁判员添加
    referee_rookie_audit_center: 'referee_rookie_audit_center', //  田协审核
    referee_rookie_audit_unit: 'referee_rookie_audit_unit', // 单位审核
    referee_rookie_update: 'referee_rookie_update', // 编辑裁判员



    cultivate_manage: 'cultivate_manage',//培训管理
    cultivate_add: 'cultivate_add',//新增培训
    cultivate_update: 'cultivate_update',//编辑培训
    cultivate_delete: 'cultivate_delete',//删除培训

    cultivate_unit_manage: 'cultivate_unit_manage',//培训单位
    cultivate_unit_add: 'cultivate_unit_add',//新增培训单位
    cultivate_unit_delete: 'cultivate_unit_delete',//删除培训单位

    cultivate_referee_manage: 'cultivate_referee_manage',//培训名单
    cultivate_referee_add: 'cultivate_referee_add',//新增培训人员
    cultivate_referee_delete: 'cultivate_referee_delete',//删除培训人员
    cultivate_referee_audit: 'cultivate_referee_audit',
    cultivate_referee_load_package: 'cultivate_referee_load_package', //打包下载

    permission_resource_manage: 'permission_resource_manage', //资源管理
    permission_resource_add: 'permission_resource_add', //添加资源
    permission_resource_update: 'permission_resource_update', // 修改资源
    permission_resource_del: 'permission_resource_del', // 删除资源
    permission_resource_move: 'permission_resource_move', // 删除资源

    permission_role_manage: 'permission_role_manage', // 角色管理
    permission_role_add: 'permission_role_add', // 添加角色
    permission_role_update: 'permission_role_update', // 修改角色
    permission_role_del: 'permission_role_del', // 删除角色

    recommend_manange: 'recommend_manange', //推荐管理
    recommend_export: 'recommend_export', //推荐导出
    recommend_import: 'recommend_import', //推荐导入
    recommend_cancel: 'recommend_cancel', //取消推荐
    recommend_do: 'recommend_do', //推荐

    statistics_speciality_export: 'statistics_speciality_export', //统计报表导出
    statistics_speciality: 'statistics_speciality',

    statistics_level: 'statistics_level',
    statistics_level_export: 'statistics_level_export',

    // news
}
