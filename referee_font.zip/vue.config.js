let webpack = require('webpack')

module.exports = {
    transpileDependencies: ['element-ui'],
    chainWebpack: config => {
        config.plugin('provide').use(webpack.ProvidePlugin, [{
            'window.Quill': 'quill',
            'Quill': 'quill'
        }])
    },
    devServer: {
        disableHostCheck: true,
        proxy: {
            '^/(api|oauth|admin)': {
                target: 'http://119.23.41.66:31548', // 31548  32267 31248  32267
                pathRewrite: {'/': '/'}
            }
        }
    }
}
